/**
 * validation.test.js — tiny in-browser test runner.
 * Validates every mandated mathematical & architectural invariant.
 */

import {
  N_NODES, HALF_IDX, USER_N_INDEX, DELTA, DELTA_NUM, DELTA_DEN, FRACTAL_SEED_RATIO,
  xAt, nearestN, antisymmetricN, isEquilibrium, stepTowardEquilibrium,
  trajectoryToEquilibrium, triadicDecompose, verifyTriadicIdentityAll,
  verifyAntisymmetryAll, reconstructFromSeed, snapToLattice,
} from '../src/lattice/janet-lattice.js';
import {
  RelationshipType, REL_TYPE_LIST, REL_CATEGORIES, isValidRelType, typesInCategory,
} from '../src/family/family-taxonomy.js';
import {
  RESERVED_BAND_START, RESERVED_BAND_END, FAMILY_SLOTS,
  degreeAndTypeFor, nIndexFor, isReserved, batTierForDegree, pollingStepsForDegree,
  vouchThresholdForDegree, validateMember, assertMandates, SELF_ANCHOR,
} from '../src/family/family-graph.js';
import {
  projectLocationToNIndex, projectLanguageToNIndex, projectProfessionToNIndex,
  buildOverlayRecord, bindOverlayToHost,
} from '../src/domains/domain-overlays.js';
import {
  ensureIdentity, signUtf8, verifyUtf8, getPublicKeyHex,
  deriveChannelKey, aesGcmEncrypt, aesGcmDecrypt, sha256Hex,
} from '../src/crypto/ed25519-manager.js';
import { RelationshipFilter } from '../src/chat/relationship-filter.js';
import { reconstructLatticeFromTriple } from '../src/recovery/recovery-engine.js';
import { buildOnboardPayload, encodePayload, decodePayload, validatePayload } from '../src/qr/qr-onboard.js';
import { sendMessage, listMessages, ingestRemoteEnvelope, dmThreadId, decryptMessage } from '../src/chat/chat-engine.js';
import { Store, STORE_NAMES } from '../src/storage/indexeddb-store.js';
import {
  submitFeed, adoptFeed, removeFeed, listFeeds,
  applyFilters as applyFeedFilters, ingestRemoteFeedEvent,
} from '../src/feeds/feed-registry.js';
import { FEED } from '../src/sync/nostr-audit.js';
import {
  parseFeed, buildProxiedUrl, DEFAULT_PROXY_TEMPLATE,
} from '../src/feeds/feed-fetcher.js';

const cases = [];
function test(name, fn) { cases.push({ name, fn }); }
function assert(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }
function approx(a, b, eps = 1e-9) { return Math.abs(a - b) <= eps; }

// -------- mathematical mandates --------
test('7 × 31 = 217 factorisation', () => {
  assert(N_NODES === 217, 'N_NODES must be 217');
  assert(31 * 7 === N_NODES, 'taxonomy × tiers must equal lattice');
  assert(FAMILY_SLOTS === 6 * 31, 'family slots = 6×31');
  assert(RESERVED_BAND_END - RESERVED_BAND_START + 1 === 31, 'reserved band size = 31');
});

test('δ = 25/27 with exact integer ratio', () => {
  assert(DELTA_NUM === 25 && DELTA_DEN === 27, 'rational components');
  assert(approx(DELTA, 25 / 27), 'δ value');
});

test('Equilibrium x=0 at n=108', () => {
  assert(HALF_IDX === 108);
  assert(approx(xAt(HALF_IDX), 0), `x(108) = ${xAt(HALF_IDX)} not zero`);
  assert(isEquilibrium(108));
});

test('Lattice spans [-100, +100] exactly', () => {
  assert(approx(xAt(0), -100), `x(0) = ${xAt(0)}`);
  assert(approx(xAt(216), 100), `x(216) = ${xAt(216)}`);
});

test('Antisymmetry x_{216-n} = -x_n for all n', () => {
  const r = verifyAntisymmetryAll();
  assert(r.ok, 'antisymmetry violations: ' + JSON.stringify(r.failures.slice(0, 3)));
});

test('Triadic identity x = A+B+C with A,B,C in S (within δ/2)', () => {
  const r = verifyTriadicIdentityAll();
  assert(r.ok, 'triadic violations: ' + JSON.stringify(r.failures.slice(0, 3)));
});

test('Equilibrium decomposes to (108,108,108) exactly', () => {
  const t = triadicDecompose(HALF_IDX);
  assert(t.A === HALF_IDX && t.B === HALF_IDX && t.C === HALF_IDX);
});

test('Deterministic δ-step converges to equilibrium without loops', () => {
  for (const start of [0, 1, 50, 107, 109, 200, 216]) {
    const path = trajectoryToEquilibrium(start);
    assert(path[path.length - 1] === HALF_IDX);
    assert(new Set(path).size === path.length, 'path has loops at start ' + start);
  }
});

test('1.39% fractal seed reconstructs all 217 nodes', () => {
  assert(approx(FRACTAL_SEED_RATIO, 3 / 216, 1e-12));
  const r = reconstructFromSeed({ n: 0, A: 7, B: 31 });
  assert(r.complete, 'did not visit every node');
  assert(r.nodes.length === N_NODES);
});

test('reconstructLatticeFromTriple requires 2 audits and visits 217', () => {
  let threw = false;
  try { reconstructLatticeFromTriple({ n: 0, A: 7, B: 31 }, []); } catch (_) { threw = true; }
  assert(threw, 'should require audits');
  const r = reconstructLatticeFromTriple({ n: 0, A: 7, B: 31 }, [{}, {}]);
  assert(r.visited === N_NODES);
  assert(r.equilibrium_present);
});

// -------- family graph mandates --------
test('USER_N_INDEX self-anchor → (4, ADOPTIVE_CHILD)', () => {
  assertMandates();
  const sd = degreeAndTypeFor(USER_N_INDEX);
  assert(sd.degree === 4 && sd.rel_type === RelationshipType.ADOPTIVE_CHILD);
  assert(SELF_ANCHOR.degree === 4);
});

test('degreeAndTypeFor / nIndexFor are inverse on family band', () => {
  for (let d = 1; d <= 6; d++) {
    for (let t = 1; t <= 31; t++) {
      const idx = nIndexFor(d, t);
      if (idx === USER_N_INDEX) continue; // self-anchor is special
      const dt = degreeAndTypeFor(idx);
      assert(dt.degree === d && dt.rel_type === t,
        `inverse mismatch for (${d},${t}) → ${idx} → (${dt.degree},${dt.rel_type})`);
    }
  }
});

test('Reserved band 186..216 marked reserved, never key-bound by validateMember', () => {
  for (let i = RESERVED_BAND_START; i <= RESERVED_BAND_END; i++) {
    assert(isReserved(i));
    const v = validateMember({ n_index: i });
    assert(!v.ok && v.error === 'reserved_band');
  }
});

test('BAT tier routing per degree', () => {
  assert(batTierForDegree(1) === 'hot');
  assert(batTierForDegree(2) === 'hot');
  assert(batTierForDegree(3) === 'warm');
  assert(batTierForDegree(4) === 'warm');
  assert(batTierForDegree(5) === 'cold');
  assert(batTierForDegree(6) === 'cold');
  assert(pollingStepsForDegree(1) === 27);
  assert(pollingStepsForDegree(3) === 54);
  assert(pollingStepsForDegree(6) === 108);
  assert(vouchThresholdForDegree(1) === 0);
  assert(vouchThresholdForDegree(3) === 1);
  assert(vouchThresholdForDegree(5) === 2);
});

// -------- taxonomy mandates --------
test('31 relationship types, 4 preset categories cover all', () => {
  assert(REL_TYPE_LIST.length === 31);
  let total = 0;
  for (const k of Object.keys(REL_CATEGORIES)) total += typesInCategory(k).length;
  assert(total === 31);
  for (let i = 1; i <= 31; i++) assert(isValidRelType(i));
});

test('RelationshipFilter selects only matching members', () => {
  const f = new RelationshipFilter().setPreset('lateral');
  const members = [
    { pubkeyHex: 'a', rel_type: 21 }, // SIBLING (lateral)
    { pubkeyHex: 'b', rel_type: 11 }, // CHILD (descendants)
    { pubkeyHex: 'c', rel_type: 30 }, // in-laws
  ];
  const out = f.filterMembers(members);
  assert(out.length === 1 && out[0].pubkeyHex === 'a');
});

// -------- domain overlays --------
test('Domain projections snap to S; never create new nodes', () => {
  const a = projectLocationToNIndex(0, 0);
  const b = projectLocationToNIndex(45, 90);
  const c = projectLanguageToNIndex('en');
  const d = projectProfessionToNIndex('healthcare');
  for (const n of [a, b, c, d]) {
    assert(Number.isInteger(n) && n >= 0 && n < N_NODES);
  }
  const ov = buildOverlayRecord({ kind: 'profession', host_n_index: 1, payload: { label: 'science' } });
  assert(ov.tier && ov.polling, 'overlay inherits tier+polling');
  // binding to reserved band yields null tier
  const ov2 = bindOverlayToHost(200, 50);
  assert(ov2.tier === null);
});

// -------- crypto round-trip --------
test('Ed25519 ensureIdentity + sign/verify', async () => {
  const id = await ensureIdentity();
  assert(/^[0-9a-f]{64}$/i.test(id.pubkeyHex), 'pubkey hex');
  const sig = await signUtf8('hello janet');
  const ok = await verifyUtf8('hello janet', sig, id.pubkeyHex);
  assert(ok, 'signature should verify');
  const bad = await verifyUtf8('hello janet!', sig, id.pubkeyHex);
  assert(!bad, 'tampered should fail');
});

test('AES-GCM channel key round-trip', async () => {
  await ensureIdentity();
  const me = getPublicKeyHex();
  const peer = me; // self-channel for test
  const k = await deriveChannelKey(me, peer);
  const pt = new TextEncoder().encode('JANET equilibrium message');
  const { iv, ct } = await aesGcmEncrypt(k, pt);
  const out = await aesGcmDecrypt(k, iv, ct);
  assert(new TextDecoder().decode(out) === 'JANET equilibrium message');
});

// -------- QR onboarding --------
test('QR payload encode/decode/validate round-trip', async () => {
  await ensureIdentity();
  const me = getPublicKeyHex();
  const p = buildOnboardPayload({
    rel_type: RelationshipType.SIBLING,
    degree_band: 2,
    pubkey: me,
    domain_hints: { language: 'en' },
  });
  const enc = encodePayload(p);
  const dec = decodePayload(enc);
  assert(dec.pubkey === me);
  const v = validatePayload(dec);
  assert(v.ok, 'validation: ' + JSON.stringify(v));
  assert(v.tier === 'hot');
});

// -------- chat envelope sync (cross-device path) --------
test('sendMessage persists locally and yields a routable envelope', async () => {
  await ensureIdentity();
  const me = getPublicKeyHex();
  const peer = me; // self-DM is enough to exercise the envelope path
  const env = await sendMessage({ threadKind: 'dm', target: peer, text: 'hello self' });
  assert(env && env.id && env.threadId === dmThreadId(me, peer), 'envelope shape');
  assert(env.payload && /^[0-9a-f]+$/i.test(env.payload.iv), 'iv hex');
  assert(env.payload && /^[0-9a-f]+$/i.test(env.payload.ct), 'ct hex');
  const back = await Store.get(STORE_NAMES.messages, env.id);
  assert(back && back.id === env.id, 'persisted to IDB');
  // Decrypts cleanly when the receiver has the same identity.
  const pt = await decryptMessage(env, { threadKind: 'dm', peerHex: peer });
  assert(pt === 'hello self', 'decrypted plaintext mismatch: ' + pt);
});

test('ingestRemoteEnvelope inserts once, then dedupes by id', async () => {
  await ensureIdentity();
  const me = getPublicKeyHex();
  const env = await sendMessage({ threadKind: 'dm', target: me, text: 'pretend remote' });
  // Wipe local copy so ingest has to insert it back, then attempt twice.
  await Store.delete(STORE_NAMES.messages, env.id);
  const first = await ingestRemoteEnvelope(env);
  const second = await ingestRemoteEnvelope(env);
  assert(first === 'inserted', 'first ingest: ' + first);
  assert(second === 'duplicate', 'second ingest must dedupe: ' + second);
  const all = await listMessages(env.threadId);
  const count = all.filter((m) => m.id === env.id).length;
  assert(count === 1, 'exactly one stored copy, found ' + count);
});

test('ingestRemoteEnvelope rejects malformed envelopes', async () => {
  assert(await ingestRemoteEnvelope(null) === 'invalid');
  assert(await ingestRemoteEnvelope({}) === 'invalid');
  // Missing payload.iv
  assert(await ingestRemoteEnvelope({
    id: 'x', threadId: 't', senderHex: 'a', ts: 1, sig: 's',
    triadic: { A_hex: 'x', B_hex: 'y', C_hex: 'z' },
    payload: { ct: 'ff' },
  }) === 'invalid');
});

// -------- feed registry (cross-device family feeds) --------
test('submitFeed persists, returns a signed entry, idempotent on URL', async () => {
  await ensureIdentity();
  await Store.clear(STORE_NAMES.feedRegistry);
  const url = 'https://example.com/test-feed.xml';
  const e1 = await submitFeed({ url, title: 'Example' });
  assert(e1.id && /^[0-9a-f]+$/.test(e1.sig), 'signed entry');
  assert(e1.feed_url === url && e1.title === 'Example', 'fields');
  const all1 = await listFeeds();
  assert(all1.length === 1, 'one entry');
  // Re-submit same URL -> same id, no duplicate.
  const e2 = await submitFeed({ url, title: 'Different label' });
  assert(e2.id === e1.id, 'idempotent on url');
  const all2 = await listFeeds();
  assert(all2.length === 1, 'still one entry');
});

test('adoptFeed records caller and is idempotent', async () => {
  await ensureIdentity();
  await Store.clear(STORE_NAMES.feedRegistry);
  const e = await submitFeed({ url: 'https://example.com/a', title: 'A' });
  // Submitter is auto-listed as the first adopter.
  assert(e.adopters.length === 1);
  await adoptFeed(e.id);
  await adoptFeed(e.id);
  const after = (await listFeeds())[0];
  assert(after.adopters.length === 1, 'no double adoption by same key');
});

test('removeFeed only by original submitter; tombstones entry', async () => {
  await ensureIdentity();
  await Store.clear(STORE_NAMES.feedRegistry);
  const e = await submitFeed({ url: 'https://example.com/b', title: 'B' });
  // Tamper to simulate "someone else" submitter, then attempt removal.
  const me = (await listFeeds())[0].addedByHex;
  const fake = { ...e, addedByHex: 'a'.repeat(64) };
  await Store.put(STORE_NAMES.feedRegistry, fake);
  const denied = await removeFeed(e.id);
  assert(denied === false, 'non-submitter cannot remove');
  // Restore real submitter then remove.
  fake.addedByHex = me;
  await Store.put(STORE_NAMES.feedRegistry, fake);
  const ok = await removeFeed(e.id);
  assert(ok === true);
  const visible = await listFeeds();
  assert(visible.length === 0, 'tombstoned out of default list');
  const incl = await listFeeds({ includeRemoved: true });
  assert(incl.length === 1 && incl[0].removed === true);
});

test('applyFilters honours focus (any-of) and exclude (none-of)', () => {
  const entries = [
    { feed_url: 'https://x.test/a', title: 'AI weekly', adopters: [], addedAt: 1 },
    { feed_url: 'https://x.test/b', title: 'Politics today', adopters: [], addedAt: 1 },
    { feed_url: 'https://x.test/math', title: 'Discrete math notes', adopters: [], addedAt: 1 },
  ];
  // Empty filters -> all pass.
  assert(applyFeedFilters(entries, {}).length === 3);
  // Focus on "math" -> only the math entry.
  let r = applyFeedFilters(entries, { focus: ['math'] });
  assert(r.length === 1 && r[0].title.includes('math'));
  // Exclude "politics" alone keeps two.
  r = applyFeedFilters(entries, { exclude: ['politics'] });
  assert(r.length === 2 && !r.some((e) => /politics/i.test(e.title)));
  // Focus + exclude combine: focus on "x.test" but exclude politics -> two.
  r = applyFeedFilters(entries, { focus: ['x.test'], exclude: ['politics'] });
  assert(r.length === 2);
});

test('ingestRemoteFeedEvent rejects unknown senders and dedupes', async () => {
  await ensureIdentity();
  await Store.clear(STORE_NAMES.feedRegistry);
  // Stranger pubkey not in members store.
  const stranger = 'b'.repeat(64);
  const evt = {
    kind: FEED.SUBMITTED,
    pubkey: stranger,
    content: JSON.stringify({
      id: 'feed_test1', feed_url: 'https://x.test/feed',
      addedByHex: stranger, addedAt: 1,
    }),
  };
  let st = await ingestRemoteFeedEvent(evt);
  assert(st === 'unauthorised', 'unknown sender must be rejected: ' + st);
  // Now register stranger as a member, retry, expect insert then duplicate.
  await Store.put(STORE_NAMES.members, {
    pubkeyHex: stranger, n_index: 1, rel_type: 1, degree: 1,
    displayName: 'stranger', addedAt: Date.now(),
  });
  st = await ingestRemoteFeedEvent(evt);
  assert(st === 'inserted', 'first ingest after membership: ' + st);
  st = await ingestRemoteFeedEvent(evt);
  assert(st === 'duplicate', 'second ingest must dedupe: ' + st);
  // Cleanup.
  await Store.delete(STORE_NAMES.members, stranger);
});

// -------- feed fetcher / parser --------
test('buildProxiedUrl substitutes {url} or appends', () => {
  const u = 'https://x.test/feed';
  const a = buildProxiedUrl(u, 'https://corsproxy.io/?{url}');
  assert(a === 'https://corsproxy.io/?' + encodeURIComponent(u), 'substitution: ' + a);
  const b = buildProxiedUrl(u, 'https://api.allorigins.win/raw?url=');
  assert(b === 'https://api.allorigins.win/raw?url=' + encodeURIComponent(u), 'fallback: ' + b);
  // Default template uses {url}.
  assert(DEFAULT_PROXY_TEMPLATE.includes('{url}'));
});

test('parseFeed: RSS 2.0 round-trip', () => {
  const xml = `<?xml version="1.0"?>
<rss version="2.0"><channel>
<title>Example RSS</title>
<link>https://example.com</link>
<item>
  <title>First Post</title>
  <link>https://example.com/1</link>
  <description>&lt;p&gt;Hello world.&lt;/p&gt;</description>
  <pubDate>Mon, 15 Jan 2024 12:00:00 GMT</pubDate>
</item>
<item>
  <title>Second Post</title>
  <guid isPermaLink="true">https://example.com/2</guid>
  <description>About politics.</description>
  <pubDate>Tue, 16 Jan 2024 09:00:00 GMT</pubDate>
</item>
</channel></rss>`;
  const items = parseFeed(xml, 'https://example.com/feed');
  assert(items.length === 2, 'two items, got ' + items.length);
  assert(items[0].title === 'First Post' && items[0].link === 'https://example.com/1');
  assert(items[0].summary === 'Hello world.', 'html stripped: ' + items[0].summary);
  assert(items[0].sourceTitle === 'Example RSS');
  assert(items[0].ts > 0, 'pubDate parsed');
  // GUID-as-link fallback.
  assert(items[1].link === 'https://example.com/2', 'guid fallback: ' + items[1].link);
  // Stable id is content-derived, so re-parse yields same id.
  const items2 = parseFeed(xml, 'https://example.com/feed');
  assert(items2[0].id === items[0].id, 'stable id');
});

test('parseFeed: Atom round-trip', () => {
  const xml = `<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
<title>Example Atom</title>
<link rel="self" href="https://example.com/atom"/>
<entry>
  <title>Atom Entry One</title>
  <link rel="alternate" href="https://example.com/a/1"/>
  <updated>2024-02-01T08:00:00Z</updated>
  <summary>Summary text.</summary>
</entry>
</feed>`;
  const items = parseFeed(xml, 'https://example.com/atom');
  assert(items.length === 1, 'one entry');
  assert(items[0].title === 'Atom Entry One');
  assert(items[0].link === 'https://example.com/a/1');
  assert(items[0].summary === 'Summary text.');
  assert(items[0].sourceTitle === 'Example Atom');
  assert(items[0].ts > 0, 'updated parsed');
});

test('parseFeed: rejects malformed XML', () => {
  let threw = false;
  try { parseFeed('<not really xml<', 'https://x.test/'); }
  catch (_) { threw = true; }
  assert(threw, 'must throw on parse error');
});

// -------- runner --------
async function run() {
  const summary = document.getElementById('summary');
  const wrap = document.getElementById('cases');
  let pass = 0, fail = 0;
  for (const c of cases) {
    const div = document.createElement('div');
    div.className = 'case';
    const name = document.createElement('div'); name.className = 'name'; name.textContent = c.name;
    const status = document.createElement('div'); status.className = 'status'; status.textContent = '…';
    div.appendChild(name); div.appendChild(status);
    wrap.appendChild(div);
    try {
      await c.fn();
      status.textContent = 'PASS'; status.classList.add('pass'); pass++;
    } catch (e) {
      status.textContent = 'FAIL'; status.classList.add('fail'); fail++;
      const pre = document.createElement('pre'); pre.textContent = e.stack || String(e);
      div.appendChild(pre);
    }
  }
  summary.textContent = `${pass}/${pass + fail} passed${fail ? ' — FAILURES PRESENT' : ' ✓'}`;
  summary.style.color = fail ? 'var(--err)' : 'var(--ok)';
}

run();
