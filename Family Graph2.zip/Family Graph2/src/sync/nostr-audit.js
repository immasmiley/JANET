/**
 * nostr-audit.js
 * --------------
 * Local Nostr-style audit trail for chat & recovery state transitions.
 * All events are signed with the local Ed25519 key and appended to IndexedDB.
 * Optional relay sync is fire-and-forget and only ever transmits *signed* events.
 *
 *   Kinds:
 *     38010 — start (group created / recovery start)
 *     38011 — vouch / member joined
 *     38012 — message sent / recovery complete
 *     38013 — member left / key rotated
 */

import { Store, STORE_NAMES } from '../storage/indexeddb-store.js';
import { signUtf8, getPublicKeyHex, sha256Hex, bytesToHex } from '../crypto/ed25519-manager.js';
import { publishAll, subscribeAll, unsubscribeAll } from './nostr-relay.js';

export const KIND = Object.freeze({
  START:      38010,
  VOUCH_JOIN: 38011,
  MESSAGE_OK: 38012,
  LEAVE_ROT:  38013,
});

// Invite handshake kinds (extension of the audit family).
export const INVITE = Object.freeze({
  PUBLISHED:  38020,
  ATTEMPT:    38021,
  COMPLETED:  38022,
  REVOKED:    38023,
});

// Chat envelope broadcast kinds.
// 38030 carries an already-E2E-encrypted message envelope (see chat-engine.js)
// so the relay only ever sees ciphertext + the recipient pubkeys it must route to.
export const CHAT = Object.freeze({
  ENVELOPE: 38030,
});

// Family feed registry kinds. Plaintext metadata only — no PII or secret
// payloads. Each event is signed by the submitter's Ed25519 key and routed
// via `['p', recipient]` tags to every family member except the sender.
export const FEED = Object.freeze({
  SUBMITTED: 38040,
  ADOPTED:   38041,
  REMOVED:   38042,
});

/** Build a Nostr-shaped event (no real network needed for local-first usage). */
async function buildEvent(kind, content, tags = []) {
  const pubkey = getPublicKeyHex() || '';
  const created_at = Math.floor(Date.now() / 1000);
  const baseStr = JSON.stringify([0, pubkey, created_at, kind, tags, content]);
  const idHex = await sha256Hex(new TextEncoder().encode(baseStr));
  const sig = await signUtf8(idHex);
  return {
    id: idHex,
    pubkey,
    created_at,
    kind,
    tags,
    content,
    sig: bytesToHex(sig),
  };
}

/**
 * Build, sign, store, and (optionally) broadcast a Nostr event.
 *  - When broadcast=true, the event is published to every configured relay.
 *  - Local audit log is always written so offline-first stays intact.
 */
export async function emit(kind, payload, tags = [], { broadcast = false } = {}) {
  const evt = await buildEvent(kind, JSON.stringify(payload), tags);
  await Store.put(STORE_NAMES.audit, evt);
  if (broadcast) {
    try { publishAll(evt); } catch (_) { /* non-fatal */ }
  }
  return evt;
}

/** Re-export the relay subscription helpers for callers that need raw access. */
export { subscribeAll as subscribeRelays, unsubscribeAll as unsubscribeRelays, publishAll as publishToRelays };

export async function listByKind(kind) {
  return Store.byIndex(STORE_NAMES.audit, 'by_kind', kind);
}
export async function listAll() {
  return Store.getAll(STORE_NAMES.audit);
}

// ---- helpers for chat events ----
export const Audit = {
  groupCreated: (groupId, filter, members) =>
    emit(KIND.START, { sub: 'group_created', groupId, filter, members },
        [['e', groupId], ['t', 'group']]),
  memberJoined: (groupId, memberHex, vouchedBy = []) =>
    emit(KIND.VOUCH_JOIN, { sub: 'member_joined', groupId, memberHex, vouchedBy },
        [['e', groupId], ['p', memberHex]]),
  messageSent: (threadId, msgId, hash) =>
    emit(KIND.MESSAGE_OK, { sub: 'message_sent', threadId, msgId, hash },
        [['e', threadId]]),
  memberLeft: (groupId, memberHex, reason = '') =>
    emit(KIND.LEAVE_ROT, { sub: 'member_left', groupId, memberHex, reason },
        [['e', groupId], ['p', memberHex]]),

  /**
   * Broadcast a fully-formed (already encrypted) chat envelope to every recipient.
   * The envelope itself stays end-to-end encrypted; the relay only sees the
   * ciphertext payload, the sender pubkey, and the routing `#p` tags.
   */
  chatEnvelope: (env, recipients) => {
    const tags = [['e', env.threadId]];
    for (const hex of recipients || []) {
      if (hex && typeof hex === 'string') tags.push(['p', hex]);
    }
    return emit(CHAT.ENVELOPE, env, tags, { broadcast: true });
  },

  // ---- recovery ----
  recoveryStart: (oldHex, requestId) =>
    emit(KIND.START, { sub: 'recovery_start', oldHex, requestId },
        [['p', oldHex]]),
  recoveryVouch: (requestId, voucherHex) =>
    emit(KIND.VOUCH_JOIN, { sub: 'recovery_vouch', requestId, voucherHex },
        [['p', voucherHex]]),
  recoveryComplete: (requestId, newHex) =>
    emit(KIND.MESSAGE_OK, { sub: 'recovery_complete', requestId, newHex },
        [['p', newHex]]),
  keyRotated: (oldHex, newHex) =>
    emit(KIND.LEAVE_ROT, { sub: 'key_rotated', oldHex, newHex },
        [['p', oldHex], ['p', newHex]]),
};
