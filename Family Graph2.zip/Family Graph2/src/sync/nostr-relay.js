/**
 * nostr-relay.js
 * --------------
 * Minimal NIP-01 WebSocket relay client.
 *
 *   Outbound: ["EVENT", evt], ["REQ", subId, ...filters], ["CLOSE", subId]
 *   Inbound : ["EVENT", subId, evt], ["EOSE", subId], ["NOTICE", msg],
 *             ["OK", evt_id, accepted, msg]
 *
 *   Multiple relay URLs run in parallel; subscriptions and publishes are
 *   broadcast to every connected relay. Auto-reconnect with exponential
 *   backoff (capped at 60s).
 *
 *   Defaults to two well-known public relays. Replace via setRelays().
 */

const DEFAULT_RELAYS = [
  'wss://relay.damus.io',
  'wss://nos.lol',
];

class Relay {
  constructor(url) {
    this.url = url;
    this.ws = null;
    this.queue = [];
    this.subs = new Map(); // subId -> { filters, onEvent, onEose }
    this.listeners = new Set();
    this._reconnectDelay = 1500;
    this._closed = false;
    this._connect();
  }

  _connect() {
    if (this._closed) return;
    let ws;
    try { ws = new WebSocket(this.url); } catch (_) { return this._scheduleReconnect(); }
    this.ws = ws;
    ws.onopen = () => {
      this._reconnectDelay = 1500;
      // flush queued
      const q = this.queue; this.queue = [];
      for (const m of q) ws.send(m);
      // re-subscribe
      for (const [subId, s] of this.subs) {
        ws.send(JSON.stringify(['REQ', subId, ...s.filters]));
      }
      this._notify({ type: 'open', url: this.url });
    };
    ws.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch (_) { return; }
      if (!Array.isArray(msg) || msg.length === 0) return;
      const op = msg[0];
      if (op === 'EVENT') {
        const subId = msg[1], evt = msg[2];
        const sub = this.subs.get(subId);
        if (sub && sub.onEvent) { try { sub.onEvent(evt, this.url); } catch (_) {} }
      } else if (op === 'EOSE') {
        const sub = this.subs.get(msg[1]);
        if (sub && sub.onEose) { try { sub.onEose(this.url); } catch (_) {} }
      } else if (op === 'NOTICE') {
        this._notify({ type: 'notice', url: this.url, message: msg[1] });
      } else if (op === 'OK') {
        this._notify({ type: 'ok', url: this.url, id: msg[1], accepted: !!msg[2], message: msg[3] });
      }
    };
    ws.onerror = () => { /* will close */ };
    ws.onclose = () => {
      this.ws = null;
      this._notify({ type: 'close', url: this.url });
      this._scheduleReconnect();
    };
  }

  _scheduleReconnect() {
    if (this._closed) return;
    setTimeout(() => this._connect(), this._reconnectDelay);
    this._reconnectDelay = Math.min(this._reconnectDelay * 2, 60_000);
  }

  _send(s) {
    if (this.ws && this.ws.readyState === 1) this.ws.send(s);
    else this.queue.push(s);
  }

  publish(evt) { this._send(JSON.stringify(['EVENT', evt])); }

  subscribe(subId, filters, onEvent, onEose) {
    this.subs.set(subId, { filters, onEvent, onEose });
    this._send(JSON.stringify(['REQ', subId, ...filters]));
  }

  unsubscribe(subId) {
    if (!this.subs.delete(subId)) return;
    this._send(JSON.stringify(['CLOSE', subId]));
  }

  addListener(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  _notify(ev) { for (const l of this.listeners) { try { l(ev); } catch (_) {} } }

  close() {
    this._closed = true;
    try { this.ws && this.ws.close(); } catch (_) {}
  }
}

const _relays = [];
const _globalListeners = new Set();

export function getRelayUrls() { return _relays.map((r) => r.url); }

export function setRelays(urls) {
  for (const r of _relays) r.close();
  _relays.length = 0;
  for (const u of urls) {
    const r = new Relay(u);
    r.addListener((ev) => { for (const l of _globalListeners) { try { l(ev); } catch (_) {} } });
    _relays.push(r);
  }
}

export function ensureDefaultRelays() {
  if (_relays.length === 0) setRelays(DEFAULT_RELAYS);
}

export function publishAll(evt) {
  ensureDefaultRelays();
  for (const r of _relays) r.publish(evt);
}

export function subscribeAll(subId, filters, onEvent, onEose) {
  ensureDefaultRelays();
  for (const r of _relays) r.subscribe(subId, filters, onEvent, onEose);
}

export function unsubscribeAll(subId) {
  for (const r of _relays) r.unsubscribe(subId);
}

export function addRelayListener(fn) {
  _globalListeners.add(fn);
  return () => _globalListeners.delete(fn);
}

export const RelayDefaults = Object.freeze({ DEFAULT_RELAYS });
