/**
 * domain-overlays.js
 * ------------------
 * Project location, language, culture, and professional domains onto the
 * SAME 217-node JANET ring via δ-quantisation + nearest-neighbor lookup.
 *
 *  Universal projection rule (no row expansion, no new nodes):
 *      coord_real = scale(domain_value) ∈ [-100, +100]
 *      n_index    = nearestN(coord_real)
 *
 * Overlays attach to existing n_index entries; they NEVER create rows.
 * They INHERIT batTier / pollingSteps from the host node's degree.
 */

import { nearestN, xAt, N_NODES } from '../lattice/janet-lattice.js';
import { degreeAndTypeFor, batTierForDegree, pollingStepsForDegree } from '../family/family-graph.js';

// ----- Location -----
// Quantize lat/lon into JANET coordinate via simple equirectangular scaling.
// lat: [-90, +90] -> [-100, +100] via lat * (100/90)
// lon: [-180, +180] -> [-100, +100] via lon * (100/180)
// We combine into a single coordinate using deterministic projection
//   coord = (lat_scaled + lon_scaled) / 2
// then snap to S.
export function projectLocationToNIndex(lat, lon) {
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    throw new TypeError('lat,lon must be finite numbers');
  }
  const latScaled = (lat * 100) / 90;
  const lonScaled = (lon * 100) / 180;
  const coord = (latScaled + lonScaled) / 2;
  return nearestN(coord);
}

// ----- Language (ISO 639-1) -----
// Map ISO-639 code to a deterministic coord by hashing the code into [-100, +100].
// VOTH-style triple: (Ground=consonant_count, Figure=vowel_count, Relation=length)
// coord = (g + f + r) / 3 mapped via δ.
export function projectLanguageToNIndex(isoCode) {
  if (typeof isoCode !== 'string' || isoCode.length === 0) {
    throw new TypeError('isoCode must be non-empty string');
  }
  const code = isoCode.toLowerCase();
  let g = 0, f = 0, r = code.length;
  const vowels = 'aeiouy';
  for (const ch of code) {
    if (vowels.includes(ch)) f++;
    else if (ch >= 'a' && ch <= 'z') g++;
  }
  // VOTH triple average, scaled across [-100,100]:
  // typical (g,f,r) ranges 0..6; map to [-100,100] linearly
  const avg = (g + f + r) / 3;        // ~0..6
  const coord = ((avg / 6) * 200) - 100; // [-100,100]
  return nearestN(coord);
}

// ----- Profession / Interest -----
// Caller supplies a domain coordinate already in [-100,+100], or a label that we hash.
const DOMAIN_LABEL_TABLE = Object.freeze({
  // a small, deterministic, well-known set; extend without breaking ring
  healthcare: -80,
  education:  -60,
  engineering:-40,
  arts:       -20,
  science:      0,
  agriculture: 20,
  service:     40,
  craft:       60,
  governance:  80,
});

export function projectProfessionToNIndex(label) {
  if (typeof label !== 'string') throw new TypeError('label must be string');
  const k = label.toLowerCase();
  let coord = DOMAIN_LABEL_TABLE[k];
  if (coord === undefined) {
    // hash into [-100, +100]
    let h = 5381;
    for (let i = 0; i < k.length; i++) h = ((h << 5) + h + k.charCodeAt(i)) >>> 0;
    coord = ((h % 20001) - 10000) / 100;
  }
  return nearestN(coord);
}

/**
 * Bind an overlay to an existing host node. Throws if the host index doesn't exist.
 * Returns { overlay_n_index, host_n_index, tier, polling, x }.
 */
export function bindOverlayToHost(host_n_index, overlay_n_index) {
  if (!Number.isInteger(host_n_index) || host_n_index < 0 || host_n_index >= N_NODES) {
    throw new RangeError('host_n_index out of range');
  }
  if (!Number.isInteger(overlay_n_index) || overlay_n_index < 0 || overlay_n_index >= N_NODES) {
    throw new RangeError('overlay_n_index out of range');
  }
  const dt = degreeAndTypeFor(host_n_index);
  const degree = dt.reserved ? null : dt.degree;
  const tier = degree == null ? null : batTierForDegree(degree);
  const polling = degree == null ? null : pollingStepsForDegree(degree);
  return {
    host_n_index,
    overlay_n_index,
    x_overlay: xAt(overlay_n_index),
    tier, polling,
  };
}

// ----- Convenience: full overlay record with kind tag -----
export function buildOverlayRecord({ kind, host_n_index, payload }) {
  let overlay_n_index;
  switch (kind) {
    case 'location':
      overlay_n_index = projectLocationToNIndex(payload.lat, payload.lon); break;
    case 'language':
      overlay_n_index = projectLanguageToNIndex(payload.iso); break;
    case 'profession':
      overlay_n_index = projectProfessionToNIndex(payload.label); break;
    default:
      throw new Error(`unknown overlay kind: ${kind}`);
  }
  return {
    id: `${kind}:${host_n_index}:${overlay_n_index}:${Date.now()}`,
    kind,
    ...bindOverlayToHost(host_n_index, overlay_n_index),
    payload,
    createdAt: Date.now(),
  };
}
