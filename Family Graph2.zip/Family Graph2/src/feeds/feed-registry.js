/**
 * feed-registry.js
 * ----------------
 * Family-shared RSS feed registry. Local-first (IndexedDB), cross-device via
 * Nostr relays using the same transport as the invite handshake and chat
 * envelopes. Trust comes from the existing family graph: an incoming event is
 * only ingested when its signer is in `STORE_NAMES.members`.
 *
 *   Schema (STORE_NAMES.feedRegistry):
 *     {id, feed_url, title, addedByHex, addedAt, adopters:[hex,...], removed?, sig}
 *
 *   Schema (STORE_NAMES.feedFilters):
 *     {pubkeyHex, focus:[term,...], exclude:[term,...]}
 *
 *   Wire kinds: FEED.SUBMITTED / FEED.ADOPTED / FEED.REMOVED (see nostr-audit.js).
 */

import { Store, STORE_NAMES } from '../storage/indexeddb-store.js';
import { getPublicKeyHex, signUtf8, bytesToHex, randomBytes } from '../crypto/ed25519-manager.js';
import { emit, FEED, subscribeRelays, unsubscribeRelays } from '../sync/nostr-audit.js';

// ---------- helpers ----------

function newFeedId() {
  return `feed_${bytesToHex(randomBytes(8))}`;
}

function nowSec() {
  return Math.floor(Date.now() / 1000);
}

function normaliseTerms(arr) {
  const seen = new Set();
  const out = [];
  for (const raw of arr || []) {
    const t = String(raw || '').trim().toLowerCase();
    if (t && !seen.has(t)) { seen.add(t); out.push(t); }
  }
  return out;
}

function normaliseUrl(u) {
  return String(u || '').trim();
}

async function recipientsForBroadcast(meHex) {
  const members = await Store.getAll(STORE_NAMES.members);
  const out = [];
  for (const m of members) {
    if (m && m.pubkeyHex && m.pubkeyHex !== meHex) out.push(m.pubkeyHex);
  }
  return out;
}

function broadcastTags(recipients) {
  const tags = [['t', 'feed']];
  for (const hex of recipients || []) {
    if (hex && typeof hex === 'string') tags.push(['p', hex]);
  }
  return tags;
}

// ---------- public API ----------

/**
 * Submit a new feed URL. Persists locally and broadcasts to all family members.
 * Returns the created entry. Idempotent on (feed_url, addedByHex): re-submitting
 * the same URL returns the existing record without creating a duplicate.
 */
export async function submitFeed({ url, title }) {
  const me = getPublicKeyHex();
  if (!me) throw new Error('identity not initialised');
  const feed_url = normaliseUrl(url);
  if (!/^https?:\/\//i.test(feed_url)) throw new Error('URL must be http(s)://...');

  // Idempotency check: any entry with the same URL we already own counts as the same.
  const byUrl = await Store.byIndex(STORE_NAMES.feedRegistry, 'by_url', feed_url);
  const existing = byUrl.find((e) => e.addedByHex === me && !e.removed);
  if (existing) return existing;

  const entry = {
    id: newFeedId(),
    feed_url,
    title: String(title || '').trim(),
    addedByHex: me,
    addedAt: nowSec(),
    adopters: [me],
    removed: false,
    sig: '',
  };
  // Sign canonical body so other devices can verify integrity if they wish.
  const body = JSON.stringify({
    id: entry.id, feed_url: entry.feed_url, title: entry.title,
    addedByHex: entry.addedByHex, addedAt: entry.addedAt,
  });
  entry.sig = bytesToHex(await signUtf8(body));

  await Store.put(STORE_NAMES.feedRegistry, entry);

  const recipients = await recipientsForBroadcast(me);
  if (recipients.length) {
    try {
      await emit(FEED.SUBMITTED, entry, broadcastTags(recipients), { broadcast: true });
    } catch (_) { /* offline; local copy is saved */ }
  }
  return entry;
}

/**
 * Adopt a feed: append self to `adopters` (idempotent) and broadcast.
 * Returns the updated entry, or null if the entry id is unknown.
 */
export async function adoptFeed(id) {
  const me = getPublicKeyHex();
  if (!me) throw new Error('identity not initialised');
  const entry = await Store.get(STORE_NAMES.feedRegistry, id);
  if (!entry) return null;
  if (!Array.isArray(entry.adopters)) entry.adopters = [];
  if (entry.adopters.includes(me)) return entry;

  entry.adopters.push(me);
  await Store.put(STORE_NAMES.feedRegistry, entry);

  const recipients = await recipientsForBroadcast(me);
  if (recipients.length) {
    try {
      await emit(FEED.ADOPTED, { id, feed_url: entry.feed_url, adopterHex: me },
                 broadcastTags(recipients), { broadcast: true });
    } catch (_) { /* offline */ }
  }
  return entry;
}

/**
 * Remove a feed. Only the original `addedByHex` may remove. Returns true on success.
 * Marks the entry as removed (tombstone) and broadcasts.
 */
export async function removeFeed(id) {
  const me = getPublicKeyHex();
  if (!me) throw new Error('identity not initialised');
  const entry = await Store.get(STORE_NAMES.feedRegistry, id);
  if (!entry) return false;
  if (entry.addedByHex !== me) return false;
  entry.removed = true;
  await Store.put(STORE_NAMES.feedRegistry, entry);

  const recipients = await recipientsForBroadcast(me);
  if (recipients.length) {
    try {
      await emit(FEED.REMOVED, { id, feed_url: entry.feed_url, removedByHex: me },
                 broadcastTags(recipients), { broadcast: true });
    } catch (_) { /* offline */ }
  }
  return true;
}

/** List feed entries, newest first. Tombstones excluded by default. */
export async function listFeeds({ includeRemoved = false } = {}) {
  const all = await Store.getAll(STORE_NAMES.feedRegistry);
  const filtered = includeRemoved ? all : all.filter((e) => !e.removed);
  filtered.sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
  return filtered;
}

/** Per-user focus/exclude filter terms. */
export async function getFilters() {
  const me = getPublicKeyHex();
  if (!me) return { focus: [], exclude: [] };
  const rec = await Store.get(STORE_NAMES.feedFilters, me);
  return {
    focus: normaliseTerms(rec && rec.focus),
    exclude: normaliseTerms(rec && rec.exclude),
  };
}

export async function setFilters({ focus, exclude }) {
  const me = getPublicKeyHex();
  if (!me) throw new Error('identity not initialised');
  const rec = {
    pubkeyHex: me,
    focus: normaliseTerms(focus),
    exclude: normaliseTerms(exclude),
  };
  await Store.put(STORE_NAMES.feedFilters, rec);
  return { focus: rec.focus, exclude: rec.exclude };
}

/**
 * Pure filter function: returns the subset of entries that match the focus/exclude rules.
 *  - focus terms: an entry passes only if at least one focus term occurs in its
 *    combined (title + url) text. Empty focus list ⇒ no focus restriction.
 *  - exclude terms: an entry fails if any exclude term occurs in the same text.
 */
export function applyFilters(entries, filters) {
  const focus = normaliseTerms(filters && filters.focus);
  const exclude = normaliseTerms(filters && filters.exclude);
  if (!focus.length && !exclude.length) return entries.slice();
  return entries.filter((e) => {
    const text = `${e.title || ''} ${e.feed_url || ''}`.toLowerCase();
    if (exclude.length && exclude.some((t) => text.indexOf(t) >= 0)) return false;
    if (focus.length && !focus.some((t) => text.indexOf(t) >= 0)) return false;
    return true;
  });
}

/**
 * Ingest a Nostr event of kind FEED.SUBMITTED / ADOPTED / REMOVED.
 * Returns one of: 'inserted' | 'merged' | 'duplicate' | 'invalid' | 'unauthorised'.
 *
 *   - SUBMITTED: insert if unknown id; otherwise dedupe.
 *   - ADOPTED:   merge sender pubkey into entry.adopters (no double-add).
 *   - REMOVED:   tombstone iff sender is original submitter.
 *
 * Trust gate: every event's `pubkey` must already exist in `STORE_NAMES.members`,
 * otherwise it's dropped as `'unauthorised'`. We do not try to verify the
 * Schnorr signature here because our Ed25519 events don't carry a real Nostr
 * sig (the relay accepts them as-is). The membership check is the bouncer.
 */
export async function ingestRemoteFeedEvent(evt) {
  if (!evt || typeof evt !== 'object') return 'invalid';
  if (![FEED.SUBMITTED, FEED.ADOPTED, FEED.REMOVED].includes(evt.kind)) return 'invalid';
  if (typeof evt.pubkey !== 'string' || !evt.pubkey) return 'invalid';

  // Membership trust gate.
  const sender = await Store.get(STORE_NAMES.members, evt.pubkey);
  if (!sender) return 'unauthorised';

  let body;
  try { body = JSON.parse(evt.content); } catch (_) { return 'invalid'; }
  if (!body || typeof body !== 'object') return 'invalid';

  if (evt.kind === FEED.SUBMITTED) {
    const required = ['id', 'feed_url', 'addedByHex', 'addedAt'];
    for (const k of required) if (body[k] === undefined || body[k] === null) return 'invalid';
    if (body.addedByHex !== evt.pubkey) return 'invalid'; // submitter must match signer
    const existing = await Store.get(STORE_NAMES.feedRegistry, body.id);
    if (existing) return 'duplicate';
    const entry = {
      id: body.id,
      feed_url: normaliseUrl(body.feed_url),
      title: String(body.title || '').trim(),
      addedByHex: body.addedByHex,
      addedAt: Number(body.addedAt) || nowSec(),
      adopters: Array.isArray(body.adopters) && body.adopters.length
        ? Array.from(new Set(body.adopters.filter((h) => typeof h === 'string')))
        : [body.addedByHex],
      removed: !!body.removed,
      sig: typeof body.sig === 'string' ? body.sig : '',
    };
    await Store.put(STORE_NAMES.feedRegistry, entry);
    return 'inserted';
  }

  if (evt.kind === FEED.ADOPTED) {
    if (typeof body.id !== 'string') return 'invalid';
    const entry = await Store.get(STORE_NAMES.feedRegistry, body.id);
    if (!entry) return 'invalid'; // we don't know the underlying entry yet
    if (!Array.isArray(entry.adopters)) entry.adopters = [];
    if (entry.adopters.includes(evt.pubkey)) return 'duplicate';
    entry.adopters.push(evt.pubkey);
    await Store.put(STORE_NAMES.feedRegistry, entry);
    return 'merged';
  }

  // FEED.REMOVED
  if (typeof body.id !== 'string') return 'invalid';
  const entry = await Store.get(STORE_NAMES.feedRegistry, body.id);
  if (!entry) return 'invalid';
  if (entry.addedByHex !== evt.pubkey) return 'unauthorised';
  if (entry.removed) return 'duplicate';
  entry.removed = true;
  await Store.put(STORE_NAMES.feedRegistry, entry);
  return 'merged';
}

/**
 * Subscribe to FEED.* events addressed to *meHex*. Returns an unsubscribe fn.
 * `onIngested(evt, status)` fires for every event we processed (status is the
 * ingestRemoteFeedEvent return value).
 */
export function startFeedRegistryListener(meHex, onIngested) {
  const subId = `feeds-${(meHex || '').slice(0, 8)}`;
  const since = Math.floor(Date.now() / 1000) - 30 * 24 * 3600; // 30-day catch-up
  subscribeRelays(subId, [{
    kinds: [FEED.SUBMITTED, FEED.ADOPTED, FEED.REMOVED],
    '#p': [meHex],
    since,
  }], async (evt) => {
    const status = await ingestRemoteFeedEvent(evt);
    if (typeof onIngested === 'function') {
      try { onIngested(evt, status); } catch (_) { /* swallow */ }
    }
  });
  return () => unsubscribeRelays(subId);
}
