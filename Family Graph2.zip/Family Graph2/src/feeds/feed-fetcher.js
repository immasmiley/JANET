/**
 * feed-fetcher.js
 * ----------------
 * Browser-side RSS/Atom fetcher for the Feeds panel.
 *
 * Browsers cannot fetch arbitrary `https://*\/feed.xml` directly because of
 * CORS. We sidestep that with a *configurable* HTTP proxy: the user picks any
 * proxy that accepts `?url=<encoded>`-style requests and returns the upstream
 * body with permissive CORS headers (e.g. `corsproxy.io`, `allorigins.win`,
 * or one they self-host). Default is `https://corsproxy.io/?{url}`.
 *
 *   Parser supports RSS 2.0 (<rss><channel><item>) and Atom (<feed><entry>).
 *   Items returned: { id, sourceUrl, sourceTitle, title, link, summary, ts }.
 */
const LS_KEY = 'janet_feed_proxy_template_v1';
// Public CORS proxies are flaky by their nature; we keep two layers of defence:
// a configurable primary (this default) and a built-in fallback chain tried
// when the primary times out / refuses connection / 5xx's.
export const DEFAULT_PROXY_TEMPLATE = 'https://api.allorigins.win/raw?url={url}';
export const FALLBACK_PROXY_TEMPLATES = [
  'https://corsproxy.io/?{url}',
  'https://api.codetabs.com/v1/proxy/?quest={url}',
];
const FETCH_TIMEOUT_MS = 22000;
const ITEM_LIMIT_PER_FEED = 30;
const PROBE_FEED_URL = 'https://hnrss.org/frontpage?count=1'; // small, well-formed RSS

function shortHost(tmpl) {
  try { return new URL(String(tmpl).replace('{url}', 'x')).host; }
  catch (_) { return String(tmpl || '').slice(0, 32); }
}

export function getProxyTemplate() {
  try { return localStorage.getItem(LS_KEY) || DEFAULT_PROXY_TEMPLATE; }
  catch (_) { return DEFAULT_PROXY_TEMPLATE; }
}

export function setProxyTemplate(t) {
  const v = String(t || '').trim() || DEFAULT_PROXY_TEMPLATE;
  try { localStorage.setItem(LS_KEY, v); } catch (_) {}
  return v;
}

export function buildProxiedUrl(url, template) {
  const tmpl = template || getProxyTemplate();
  if (tmpl.includes('{url}')) return tmpl.replace('{url}', encodeURIComponent(url));
  // Fallback: append the encoded URL when no placeholder is present.
  return tmpl + encodeURIComponent(url);
}

/**
 * Fetch a feed URL through the configured proxy with automatic fallback to
 * built-in alternates. Returns parsed items on the first proxy that succeeds.
 * If every candidate fails, throws with a `→`-joined trace so the caller can
 * tell which proxy hosts were tried.
 */
export async function fetchFeed(url, { template, signal } = {}) {
  if (!/^https?:\/\//i.test(url || '')) throw new Error('feed URL must be http(s)://...');
  const primary = template || getProxyTemplate();
  const seen = new Set();
  const candidates = [primary, ...FALLBACK_PROXY_TEMPLATES].filter((t) => {
    const k = (t || '').trim();
    if (!k || seen.has(k)) return false;
    seen.add(k); return true;
  });
  const errors = [];
  for (const tmpl of candidates) {
    try {
      const text = await fetchProxiedRaw(url, tmpl, signal);
      return parseFeed(text, url);
    } catch (e) {
      errors.push(`${shortHost(tmpl)}: ${e && e.message ? e.message : String(e)}`);
    }
  }
  throw new Error(errors.join(' → '));
}

/** Single-shot proxy fetch (no fallback). Returns the raw response body. */
async function fetchProxiedRaw(url, template, signal) {
  const proxied = buildProxiedUrl(url, template);
  const ctl = new AbortController();
  const onUserAbort = () => ctl.abort(signal && signal.reason ? signal.reason : 'cancelled');
  if (signal) signal.addEventListener('abort', onUserAbort, { once: true });
  const timer = setTimeout(() => ctl.abort('timeout'), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(proxied, { signal: ctl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
    if (signal) signal.removeEventListener('abort', onUserAbort);
  }
}

/**
 * Verify a proxy template by fetching a feed and parsing it. Returns
 * `{ ok, host, probe, tookMs, itemCount? error? }`.
 *
 * If `probeUrl` is provided, that URL is used (so the caller can test against
 * a real feed they care about). Otherwise falls back to a canned small feed.
 * The timing makes it possible to distinguish "slow but reachable" from
 * "completely broken".
 */
export async function testProxy(template, probeUrl) {
  const tmpl = (template || getProxyTemplate()).trim();
  const host = shortHost(tmpl);
  const probe = (probeUrl && /^https?:\/\//i.test(probeUrl)) ? probeUrl : PROBE_FEED_URL;
  const t0 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  try {
    const text = await fetchProxiedRaw(probe, tmpl);
    const items = parseFeed(text, probe);
    const t1 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    return { ok: true, host, probe, itemCount: items.length, tookMs: Math.round(t1 - t0) };
  } catch (e) {
    const t1 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    return {
      ok: false,
      host,
      probe,
      error: e && e.message ? e.message : String(e),
      tookMs: Math.round(t1 - t0),
    };
  }
}

/**
 * Parse an XML string as an RSS 2.0 or Atom feed and return an array of items.
 * Pure function; no I/O. Exported so tests can verify against canned XML.
 */
export function parseFeed(xmlText, sourceUrl) {
  if (typeof xmlText !== 'string' || !xmlText.trim()) {
    throw new Error('empty feed body');
  }
  // Catch the common case where an HTML page (URL is wrong, paywall, login,
  // captcha, etc.) is served instead of XML. Saves time vs the generic
  // "feed parse error" because the user immediately knows it's not a parser bug.
  const head = xmlText.slice(0, 600).toLowerCase().replace(/^\s*<\?xml[^?]*\?>/, '');
  if (/<!doctype html|<html[\s>]/i.test(head)) {
    throw new Error('response is HTML, not a feed (wrong URL or paywall page?)');
  }
  const doc = new DOMParser().parseFromString(xmlText, 'application/xml');
  const root = doc.documentElement;
  if (!root || root.getElementsByTagName('parsererror').length) {
    throw new Error('feed parse error');
  }
  const local = (root.localName || '').toLowerCase();
  if (local === 'feed') return parseAtom(doc, sourceUrl);
  if (local === 'rss' || doc.getElementsByTagName('channel').length) return parseRss(doc, sourceUrl);
  // Some feeds wrap RSS in RDF (RSS 1.0). Treat as RSS-shaped.
  if (doc.getElementsByTagName('item').length) return parseRss(doc, sourceUrl);
  throw new Error('unrecognised feed shape');
}

// ---------- internals ----------

function firstChildText(parent, name) {
  if (!parent) return '';
  const els = parent.getElementsByTagName(name);
  for (const el of els) {
    if (el.parentNode === parent) return (el.textContent || '').trim();
  }
  return els.length ? (els[0].textContent || '').trim() : '';
}

function parseRss(doc, sourceUrl) {
  const channel = doc.getElementsByTagName('channel')[0] || doc.documentElement;
  const sourceTitle = firstChildText(channel, 'title');
  const items = Array.from(doc.getElementsByTagName('item')).slice(0, ITEM_LIMIT_PER_FEED);
  return items.map((it) => {
    const title = firstChildText(it, 'title');
    let link = firstChildText(it, 'link');
    if (!link) {
      const guid = it.getElementsByTagName('guid')[0];
      if (guid && /^https?:\/\//i.test(guid.textContent || '')) link = (guid.textContent || '').trim();
    }
    const description = firstChildText(it, 'description') || firstChildText(it, 'content:encoded');
    const pub = firstChildText(it, 'pubDate') || firstChildText(it, 'dc:date');
    const ts = pub ? Date.parse(pub) || 0 : 0;
    return makeItem({ sourceUrl, sourceTitle, title, link, summary: description, ts });
  });
}

function parseAtom(doc, sourceUrl) {
  const root = doc.documentElement;
  const sourceTitle = firstChildText(root, 'title');
  const entries = Array.from(doc.getElementsByTagName('entry')).slice(0, ITEM_LIMIT_PER_FEED);
  return entries.map((e) => {
    const title = firstChildText(e, 'title');
    let link = '';
    const links = e.getElementsByTagName('link');
    for (const l of links) {
      const rel = (l.getAttribute('rel') || 'alternate').toLowerCase();
      if (rel === 'alternate') { link = l.getAttribute('href') || ''; break; }
    }
    if (!link && links.length) link = links[0].getAttribute('href') || '';
    const summary = firstChildText(e, 'summary') || firstChildText(e, 'content');
    const updated = firstChildText(e, 'updated') || firstChildText(e, 'published');
    const ts = updated ? Date.parse(updated) || 0 : 0;
    return makeItem({ sourceUrl, sourceTitle, title, link, summary, ts });
  });
}

function makeItem({ sourceUrl, sourceTitle, title, link, summary, ts }) {
  return {
    id: hashId(sourceUrl + '|' + (link || title || '')),
    sourceUrl,
    sourceTitle: sourceTitle || sourceUrl,
    title: (title || '(untitled)').slice(0, 280),
    link: link || '',
    summary: stripHtml(summary).slice(0, 500),
    ts: Number(ts) || 0,
  };
}

function stripHtml(s) {
  if (!s) return '';
  return String(s)
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function hashId(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return 'item_' + (h >>> 0).toString(16).padStart(8, '0');
}
