/**
 * qr-encoder.js
 * -------------
 * Compact QR Code generator. Port of Project Nayuki's QR Code generator
 * (https://www.nayuki.io/page/qr-code-generator-library — BSD-2-Clause).
 * Restricted to byte mode (UTF-8); supports versions 1..40 and ECC L/M/Q/H.
 *
 * Public API:
 *   makeQRMatrix(text, ecl='M')  -> { size, modules: boolean[][] , version }
 *   renderQRSvg(matrix, { scale=8, margin=4, dark='#000', light='#fff' })
 */

const ECC = Object.freeze({ L: 0, M: 1, Q: 2, H: 3 });

// EC codewords per block, indexed [ecl][version] (version starts at 1)
const ECC_CODEWORDS_PER_BLOCK = [
  [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],   // L
  [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28], // M
  [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30], // Q
  [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30], // H
];
const NUM_ERROR_CORRECTION_BLOCKS = [
  [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],          // L
  [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49], // M
  [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68], // Q
  [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81], // H
];

// Number of raw data modules in the symbol minus function/format/version overhead.
function getNumRawDataModules(ver) {
  if (ver < 1 || ver > 40) throw new RangeError('version out of range');
  let result = (16 * ver + 128) * ver + 64;
  if (ver >= 2) {
    const numAlign = Math.floor(ver / 7) + 2;
    result -= (25 * numAlign - 10) * numAlign - 55;
    if (ver >= 7) result -= 36;
  }
  return result;
}
function getNumDataCodewords(ver, ecl) {
  return Math.floor(getNumRawDataModules(ver) / 8) - ECC_CODEWORDS_PER_BLOCK[ecl][ver] * NUM_ERROR_CORRECTION_BLOCKS[ecl][ver];
}

// ------------------ GF(256) and Reed-Solomon ------------------
const GF_EXP = new Uint8Array(512);
const GF_LOG = new Uint8Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11D;
  }
  for (let i = 255; i < 512; i++) GF_EXP[i] = GF_EXP[i - 255];
})();
function gfMul(a, b) { return (a === 0 || b === 0) ? 0 : GF_EXP[GF_LOG[a] + GF_LOG[b]]; }
function rsGenerator(degree) {
  const result = new Uint8Array(degree);
  result[degree - 1] = 1;
  let root = 1;
  for (let i = 0; i < degree; i++) {
    for (let j = 0; j < degree; j++) {
      result[j] = gfMul(result[j], root) ^ (j + 1 < degree ? result[j + 1] : 0);
    }
    root = gfMul(root, 2);
  }
  return result;
}
function rsRemainder(data, generator) {
  const result = new Uint8Array(generator.length);
  for (const b of data) {
    const factor = b ^ result[0];
    result.copyWithin(0, 1);
    result[result.length - 1] = 0;
    for (let i = 0; i < result.length; i++) result[i] ^= gfMul(generator[i], factor);
  }
  return result;
}

// ------------------ Bit buffer ------------------
class BitBuffer {
  constructor() { this.bits = []; }
  appendBits(val, len) {
    if (len < 0 || len > 31 || val >>> len !== 0) throw new RangeError('appendBits invalid');
    for (let i = len - 1; i >= 0; i--) this.bits.push((val >>> i) & 1);
  }
}

// ------------------ Mask penalty + selection ------------------
function applyMask(modules, isFunction, mask) {
  const size = modules.length;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (isFunction[y][x]) continue;
      let invert;
      switch (mask) {
        case 0: invert = (x + y) % 2 === 0; break;
        case 1: invert = y % 2 === 0; break;
        case 2: invert = x % 3 === 0; break;
        case 3: invert = (x + y) % 3 === 0; break;
        case 4: invert = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
        case 5: invert = (x * y) % 2 + (x * y) % 3 === 0; break;
        case 6: invert = ((x * y) % 2 + (x * y) % 3) % 2 === 0; break;
        case 7: invert = ((x + y) % 2 + (x * y) % 3) % 2 === 0; break;
        default: throw new Error('mask');
      }
      if (invert) modules[y][x] = !modules[y][x];
    }
  }
}
function getPenaltyScore(modules) {
  const size = modules.length;
  let result = 0;
  // adjacent same-color rows/cols of length >= 5
  for (let y = 0; y < size; y++) {
    let runColor = false, runLen = 0, runHistory = [0,0,0,0,0,0,0];
    for (let x = 0; x < size; x++) {
      if (modules[y][x] === runColor) {
        runLen++;
        if (runLen === 5) result += 3;
        else if (runLen > 5) result++;
      } else {
        finderPenalty(runHistory, runLen);
        if (!runColor) result += finderPenaltyCount(runHistory) * 40;
        runColor = modules[y][x];
        runLen = 1;
      }
    }
    finderPenaltyTerminate(runHistory, runLen, runColor, size);
    result += finderPenaltyCount(runHistory) * 40;
  }
  for (let x = 0; x < size; x++) {
    let runColor = false, runLen = 0, runHistory = [0,0,0,0,0,0,0];
    for (let y = 0; y < size; y++) {
      if (modules[y][x] === runColor) {
        runLen++;
        if (runLen === 5) result += 3;
        else if (runLen > 5) result++;
      } else {
        finderPenalty(runHistory, runLen);
        if (!runColor) result += finderPenaltyCount(runHistory) * 40;
        runColor = modules[y][x];
        runLen = 1;
      }
    }
    finderPenaltyTerminate(runHistory, runLen, runColor, size);
    result += finderPenaltyCount(runHistory) * 40;
  }
  // 2x2 blocks of same color
  for (let y = 0; y < size - 1; y++) {
    for (let x = 0; x < size - 1; x++) {
      const c = modules[y][x];
      if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) result += 3;
    }
  }
  // dark/light balance
  let dark = 0;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (modules[y][x]) dark++;
  const total = size * size;
  const k = Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1;
  result += k * 10;
  return result;
}
function finderPenalty(history, runLen) {
  history.pop();
  history.unshift(runLen);
}
function finderPenaltyCount(history) {
  const n = history[1];
  const core = n > 0 && history[2] === n && history[3] === n * 3 && history[4] === n && history[5] === n;
  return (core && history[0] >= n * 4 && history[6] >= n ? 1 : 0)
       + (core && history[6] >= n * 4 && history[0] >= n ? 1 : 0);
}
function finderPenaltyTerminate(history, runLen, runColor, size) {
  if (runColor) { finderPenalty(history, runLen); runLen = 0; }
  runLen += size;
  finderPenalty(history, runLen);
}

// ------------------ Module placement ------------------
function getAlignmentPatternPositions(ver) {
  if (ver === 1) return [];
  const numAlign = Math.floor(ver / 7) + 2;
  const step = (ver === 32) ? 26 : Math.ceil((ver * 4 + 4) / (numAlign * 2 - 2)) * 2;
  const result = [6];
  for (let pos = ver * 4 + 10; result.length < numAlign; pos -= step) result.splice(1, 0, pos);
  return result;
}
function setFunctionModule(modules, isFunction, x, y, isDark) {
  modules[y][x] = isDark;
  isFunction[y][x] = true;
}
function drawFinder(modules, isFunction, x, y) {
  for (let dy = -4; dy <= 4; dy++) {
    for (let dx = -4; dx <= 4; dx++) {
      const xx = x + dx, yy = y + dy;
      if (xx < 0 || xx >= modules.length || yy < 0 || yy >= modules.length) continue;
      const dist = Math.max(Math.abs(dx), Math.abs(dy));
      setFunctionModule(modules, isFunction, xx, yy, dist !== 2 && dist !== 4);
    }
  }
}
function drawAlignment(modules, isFunction, x, y) {
  for (let dy = -2; dy <= 2; dy++) {
    for (let dx = -2; dx <= 2; dx++) {
      setFunctionModule(modules, isFunction, x + dx, y + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }
  }
}
function drawTimingPatterns(modules, isFunction) {
  const size = modules.length;
  for (let i = 0; i < size; i++) {
    setFunctionModule(modules, isFunction, 6, i, i % 2 === 0);
    setFunctionModule(modules, isFunction, i, 6, i % 2 === 0);
  }
}
function drawFunctionPatterns(modules, isFunction, ver) {
  const size = modules.length;
  drawTimingPatterns(modules, isFunction);
  drawFinder(modules, isFunction, 3, 3);
  drawFinder(modules, isFunction, size - 4, 3);
  drawFinder(modules, isFunction, 3, size - 4);
  const align = getAlignmentPatternPositions(ver);
  const n = align.length;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === n - 1) || (i === n - 1 && j === 0)) continue;
      drawAlignment(modules, isFunction, align[i], align[j]);
    }
  }
  // reserve format info area; will be filled later
  for (let i = 0; i < 9; i++) setFunctionModule(modules, isFunction, 8, i, false);
  for (let i = 0; i < 8; i++) setFunctionModule(modules, isFunction, i, 8, false);
  for (let i = size - 8; i < size; i++) setFunctionModule(modules, isFunction, 8, i, false);
  for (let i = size - 8; i < size; i++) setFunctionModule(modules, isFunction, i, 8, false);
  setFunctionModule(modules, isFunction, 8, size - 8, true); // dark module
  if (ver >= 7) {
    for (let i = 0; i < 18; i++) {
      const a = size - 11 + i % 3;
      const b = Math.floor(i / 3);
      setFunctionModule(modules, isFunction, a, b, false);
      setFunctionModule(modules, isFunction, b, a, false);
    }
  }
}
function drawFormatBits(modules, isFunction, ecl, mask) {
  // 5-bit data: ecl(2) + mask(3); 10-bit BCH; xor with 0x5412
  const data = (ecl << 3) | mask;
  let rem = data;
  for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
  const bits = ((data << 10) | rem) ^ 0x5412;
  // place around top-left finder
  for (let i = 0; i <= 5; i++) modules[8][i] = ((bits >>> i) & 1) !== 0;
  modules[8][7] = ((bits >>> 6) & 1) !== 0;
  modules[8][8] = ((bits >>> 7) & 1) !== 0;
  modules[7][8] = ((bits >>> 8) & 1) !== 0;
  for (let i = 9; i < 15; i++) modules[14 - i][8] = ((bits >>> i) & 1) !== 0;
  // place around top-right and bottom-left
  const size = modules.length;
  for (let i = 0; i < 8; i++) modules[size - 1 - i][8] = ((bits >>> i) & 1) !== 0;
  for (let i = 8; i < 15; i++) modules[8][size - 15 + i] = ((bits >>> i) & 1) !== 0;
  modules[size - 8][8] = true;
}
function drawVersionBits(modules, ver) {
  if (ver < 7) return;
  let rem = ver;
  for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
  const bits = (ver << 12) | rem;
  const size = modules.length;
  for (let i = 0; i < 18; i++) {
    const bit = ((bits >>> i) & 1) !== 0;
    const a = size - 11 + i % 3;
    const b = Math.floor(i / 3);
    modules[a][b] = bit;
    modules[b][a] = bit;
  }
}

// ------------------ Codeword build ------------------
function buildCodewords(textBytes, ver, ecl) {
  const bb = new BitBuffer();
  bb.appendBits(0b0100, 4); // byte mode
  const charCountBits = ver < 10 ? 8 : 16;
  bb.appendBits(textBytes.length, charCountBits);
  for (const b of textBytes) bb.appendBits(b, 8);
  const dataCapacity = getNumDataCodewords(ver, ecl) * 8;
  bb.appendBits(0, Math.min(4, dataCapacity - bb.bits.length));
  while (bb.bits.length % 8 !== 0) bb.bits.push(0);
  // pad bytes
  for (let pad = 0xEC; bb.bits.length < dataCapacity; pad ^= 0xEC ^ 0x11) {
    bb.appendBits(pad, 8);
  }
  // pack to bytes
  const data = new Uint8Array(bb.bits.length / 8);
  for (let i = 0; i < bb.bits.length; i++) data[i >>> 3] |= bb.bits[i] << (7 - (i & 7));
  return data;
}
function addEcAndInterleave(data, ver, ecl) {
  const numBlocks = NUM_ERROR_CORRECTION_BLOCKS[ecl][ver];
  const blockEccLen = ECC_CODEWORDS_PER_BLOCK[ecl][ver];
  const rawCodewords = Math.floor(getNumRawDataModules(ver) / 8);
  const numShortBlocks = numBlocks - rawCodewords % numBlocks;
  const shortBlockLen = Math.floor(rawCodewords / numBlocks);

  const blocks = [];
  const generator = rsGenerator(blockEccLen);
  let k = 0;
  for (let i = 0; i < numBlocks; i++) {
    const dataLen = shortBlockLen - blockEccLen + (i < numShortBlocks ? 0 : 1);
    const block = data.slice(k, k + dataLen);
    k += dataLen;
    const ecc = rsRemainder(block, generator);
    const full = new Uint8Array(block.length + ecc.length);
    full.set(block); full.set(ecc, block.length);
    blocks.push(full);
  }
  // interleave
  const result = new Uint8Array(rawCodewords);
  let idx = 0;
  for (let i = 0; i < blocks[blocks.length - 1].length; i++) {
    for (let j = 0; j < blocks.length; j++) {
      // for data part, skip the missing byte in short blocks
      if (i !== shortBlockLen - blockEccLen || j >= numShortBlocks) {
        result[idx++] = blocks[j][i];
      }
    }
  }
  return result;
}
function drawCodewords(modules, isFunction, codewords) {
  const size = modules.length;
  let i = 0;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) {
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const upward = ((right + 1) & 2) === 0;
        const y = upward ? size - 1 - vert : vert;
        if (!isFunction[y][x] && i < codewords.length * 8) {
          modules[y][x] = ((codewords[i >>> 3] >>> (7 - (i & 7))) & 1) !== 0;
          i++;
        }
      }
    }
  }
}

// ------------------ Public API ------------------
export function makeQRMatrix(text, eclName = 'M') {
  const ecl = ECC[eclName];
  if (ecl === undefined) throw new RangeError('eclName must be L, M, Q or H');
  const textBytes = new TextEncoder().encode(text);
  let ver;
  for (ver = 1; ver <= 40; ver++) {
    const cap = getNumDataCodewords(ver, ecl);
    const charCountBits = ver < 10 ? 8 : 16;
    const bitsNeeded = 4 + charCountBits + textBytes.length * 8;
    if (bitsNeeded <= cap * 8) break;
  }
  if (ver > 40) throw new Error('data too long for QR (max version 40)');
  const size = ver * 4 + 17;
  const modules = Array.from({ length: size }, () => new Array(size).fill(false));
  const isFunction = Array.from({ length: size }, () => new Array(size).fill(false));
  drawFunctionPatterns(modules, isFunction, ver);
  drawVersionBits(modules, ver);

  const data = buildCodewords(textBytes, ver, ecl);
  const allCodewords = addEcAndInterleave(data, ver, ecl);
  drawCodewords(modules, isFunction, allCodewords);

  // Try all 8 masks, pick best (lowest penalty)
  let bestMask = 0, bestPenalty = Infinity;
  for (let m = 0; m < 8; m++) {
    applyMask(modules, isFunction, m);
    drawFormatBits(modules, isFunction, ecl, m);
    const p = getPenaltyScore(modules);
    if (p < bestPenalty) { bestPenalty = p; bestMask = m; }
    applyMask(modules, isFunction, m);  // unmask
  }
  applyMask(modules, isFunction, bestMask);
  drawFormatBits(modules, isFunction, ecl, bestMask);

  return { size, modules, version: ver, mask: bestMask };
}

export function renderQRSvg(matrix, opts = {}) {
  const { scale = 8, margin = 4, dark = '#000', light = '#fff' } = opts;
  const sz = matrix.size;
  const pixels = (sz + margin * 2) * scale;
  const parts = [];
  parts.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${sz + margin * 2} ${sz + margin * 2}" width="${pixels}" height="${pixels}" shape-rendering="crispEdges">`);
  parts.push(`<rect width="100%" height="100%" fill="${light}"/>`);
  parts.push(`<path fill="${dark}" d="`);
  for (let y = 0; y < sz; y++) {
    for (let x = 0; x < sz; x++) {
      if (matrix.modules[y][x]) parts.push(`M${x + margin},${y + margin}h1v1h-1z`);
    }
  }
  parts.push(`"/></svg>`);
  return parts.join('');
}
