/**
 * qr-onboard.js
 * -------------
 * QR onboarding payload encode/decode + verification.
 *
 *  Schema:
 *    {
 *      v: 1,
 *      rel_type: 1..31,
 *      degree_band: 1..6,
 *      pubkey: hexString,
 *      challenge_nonce: hexString,
 *      domain_hints: { location?: {lat,lon}, language?: ISO_639 }
 *    }
 *
 *  Encoding: JSON, base64url. (CBOR optional — we keep zero-deps.)
 */

import { isValidRelType } from '../family/family-taxonomy.js';
import { nIndexFor, validateMember } from '../family/family-graph.js';
import { randomBytes, bytesToHex } from '../crypto/ed25519-manager.js';

function b64url(bytes) {
  let s = btoa(String.fromCharCode(...bytes));
  return s.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function b64urlDecode(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function buildOnboardPayload({ rel_type, degree_band, pubkey, domain_hints = {} }) {
  if (!isValidRelType(rel_type)) throw new RangeError('invalid rel_type');
  if (!Number.isInteger(degree_band) || degree_band < 1 || degree_band > 6) {
    throw new RangeError('invalid degree_band');
  }
  if (!/^[0-9a-f]{64}$/i.test(pubkey)) throw new RangeError('invalid pubkey hex');
  const nonce = bytesToHex(randomBytes(16));
  return {
    v: 1,
    rel_type,
    degree_band,
    pubkey: pubkey.toLowerCase(),
    challenge_nonce: nonce,
    domain_hints,
  };
}

/** Encode an onboarding payload to a compact base64url string suitable for QR. */
export function encodePayload(p) {
  const json = JSON.stringify(p);
  const bytes = new TextEncoder().encode(json);
  const prefix = p && p.v === 2 ? 'janet2:' : 'janet1:';
  return prefix + b64url(bytes);
}

/** Parse an incoming QR payload string. Accepts v:1 (direct bind) or v:2 (invite). */
export function decodePayload(s) {
  if (typeof s !== 'string') throw new Error('not a janet payload');
  let body, version;
  if (s.startsWith('janet2:')) { body = s.slice(7); version = 2; }
  else if (s.startsWith('janet1:')) { body = s.slice(7); version = 1; }
  else throw new Error('not a janet payload');
  const bytes = b64urlDecode(body);
  const obj = JSON.parse(new TextDecoder().decode(bytes));
  if (obj.v !== version) throw new Error(`payload version mismatch (header=${version}, body=${obj.v})`);
  return obj;
}

/**
 * Build a v:2 *invite* QR payload. PIN is intentionally absent — it travels
 * out-of-band (phone/email). The invite is identified by `invite_id`, sealed
 * by `commitment`, and bound to a specific `(rel_type, degree_band)` pair that
 * the inviter expects the joiner to know AND confirm.
 */
export function buildInvitePayload({
  invite_id,
  inviter_pubkey,
  commitment,
  salt,
  rel_type,
  degree_band,
  ttl,
  relays = [],
  inviter_name = null,
}) {
  if (!/^[0-9a-f]+$/i.test(invite_id)) throw new RangeError('invalid invite_id');
  if (!/^[0-9a-f]{64}$/i.test(inviter_pubkey)) throw new RangeError('invalid inviter_pubkey');
  if (!/^[0-9a-f]{64}$/i.test(commitment)) throw new RangeError('invalid commitment');
  if (!/^[0-9a-f]+$/i.test(salt)) throw new RangeError('invalid salt');
  if (!isValidRelType(rel_type)) throw new RangeError('invalid rel_type');
  if (!Number.isInteger(degree_band) || degree_band < 1 || degree_band > 6) {
    throw new RangeError('invalid degree_band');
  }
  return {
    v: 2,
    invite_id: invite_id.toLowerCase(),
    inviter_pubkey: inviter_pubkey.toLowerCase(),
    commitment: commitment.toLowerCase(),
    salt: salt.toLowerCase(),
    rel_type,
    degree_band,
    ttl,
    relays,
    inviter_name,
  };
}

/** Validate an incoming v:2 invite payload (shape only; PIN-check is separate). */
export function validateInvitePayload(p) {
  if (!p || p.v !== 2) return { ok: false, error: 'not_v2' };
  if (!isValidRelType(p.rel_type)) return { ok: false, error: 'invalid_rel_type' };
  if (!Number.isInteger(p.degree_band) || p.degree_band < 1 || p.degree_band > 6) {
    return { ok: false, error: 'invalid_degree_band' };
  }
  if (!/^[0-9a-f]{64}$/i.test(p.commitment)) return { ok: false, error: 'invalid_commitment' };
  if (!/^[0-9a-f]{64}$/i.test(p.inviter_pubkey)) return { ok: false, error: 'invalid_inviter_pubkey' };
  if (typeof p.invite_id !== 'string' || p.invite_id.length < 8) {
    return { ok: false, error: 'invalid_invite_id' };
  }
  if (typeof p.ttl !== 'number' || p.ttl <= 0) return { ok: false, error: 'invalid_ttl' };
  return { ok: true };
}

/** Validate the payload against family graph + taxonomy mandates. */
export function validatePayload(p) {
  const n_index = nIndexFor(p.degree_band, p.rel_type);
  const v = validateMember({ n_index, rel_type: p.rel_type, degree: p.degree_band });
  if (!v.ok) return { ok: false, error: v.error || 'invalid binding' };
  return { ok: true, n_index, ...v };
}
