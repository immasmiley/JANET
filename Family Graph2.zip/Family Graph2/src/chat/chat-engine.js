/**
 * chat-engine.js
 * --------------
 * Group + DM chat. End-to-end encryption per channel; messages decompose
 * into JANET triadic components (A=content hash, B=sender pubkey, C=ts+auth proof).
 *
 *   Group membership rules:
 *     - Creator picks a relationship filter (4 presets + custom).
 *     - Each invitee's (n_index, rel_type, degree) must validate.
 *     - Tier-based vouch policy is enforced:
 *         hot  → instant
 *         warm → 1 vouch from existing member required
 *         cold → 2 vouches from existing members required
 *
 *   Message envelope (stored per-message in IDB):
 *     {
 *       id, threadId, senderHex, ts,
 *       triadic: { A_hex, B_hex, C_hex },     // the three components
 *       payload: { iv:hex, ct:hex },          // AES-GCM ciphertext
 *       sig: hex,                             // Ed25519 signature over payload
 *     }
 */

import { Store, STORE_NAMES } from '../storage/indexeddb-store.js';
import {
  signUtf8, getPublicKeyHex,
  deriveChannelKey, aesGcmEncrypt, aesGcmDecrypt,
  sha256Hex, bytesToHex, hexToBytes, randomBytes,
} from '../crypto/ed25519-manager.js';
import { validateMember, batTierForDegree, vouchThresholdForDegree, reservedBridgeIndex } from '../family/family-graph.js';
import { RelationshipFilter } from './relationship-filter.js';
import { Audit, CHAT, subscribeRelays, unsubscribeRelays } from '../sync/nostr-audit.js';

// ---------- helpers ----------
function newId(prefix) {
  return `${prefix}_${bytesToHex(randomBytes(8))}`;
}
function aadFor(threadId, senderHex, ts) {
  return new TextEncoder().encode(`${threadId}|${senderHex}|${ts}`);
}

/** Group channel key — derived from a sorted concat of all member pubkeys. */
async function deriveGroupKey(memberHexList, salt = 'janet-fc-group') {
  const sorted = [...memberHexList].sort();
  const concat = sorted.join('|');
  const ikm = new TextEncoder().encode(concat);
  // Use HKDF-SHA-256 via WebCrypto by going through a base ImportKey.
  const baseKey = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: new TextEncoder().encode(salt),
      info: new Uint8Array(),
    },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );
}

// ---------- group lifecycle ----------
/**
 * Create a new group.
 *  - filter: RelationshipFilter
 *  - candidates: array of member objects {pubkeyHex, n_index, rel_type, degree}
 *  - existingForVouch: map<degree, count> of approving existing members for cold/warm tiers
 *
 *  Returns the persisted group record.
 */
export async function createGroup({ name, filter, candidates, existingForVouch = {} }) {
  if (!(filter instanceof RelationshipFilter)) throw new TypeError('filter required');
  const filterIds = filter.selectedIds();

  const validated = [];
  for (const m of candidates) {
    const v = validateMember({ n_index: m.n_index, rel_type: m.rel_type, degree: m.degree });
    if (!v.ok) continue;                    // silently drop invalid bindings
    if (!filterIds.has(v.rel_type)) continue;
    const need = vouchThresholdForDegree(v.degree);
    const have = existingForVouch[m.pubkeyHex] || 0;
    if (have < need) {
      validated.push({ ...m, vouchStatus: 'pending', need, have });
    } else {
      validated.push({ ...m, vouchStatus: 'ok', need, have });
    }
  }

  const id = newId('grp');
  const creatorHex = getPublicKeyHex();
  const memberHexes = validated.filter(v => v.vouchStatus === 'ok').map(v => v.pubkeyHex);
  if (creatorHex && !memberHexes.includes(creatorHex)) memberHexes.unshift(creatorHex);

  const bridge = reservedBridgeIndex(id);   // store group metadata in reserved band

  const group = {
    id,
    name: name || `Group ${id.slice(0, 6)}`,
    filter: filter.toJSON(),
    members: memberHexes,
    pending: validated.filter(v => v.vouchStatus === 'pending'),
    creatorHex,
    n_index_bridge: bridge,
    createdAt: Date.now(),
  };
  await Store.put(STORE_NAMES.groups, group);
  await Audit.groupCreated(id, group.filter, memberHexes);
  for (const m of memberHexes) {
    if (m !== creatorHex) await Audit.memberJoined(id, m, []);
  }
  return group;
}

export async function listGroups() {
  return Store.getAll(STORE_NAMES.groups);
}

export async function leaveGroup(groupId, reason = '') {
  const g = await Store.get(STORE_NAMES.groups, groupId);
  if (!g) throw new Error('group not found');
  const me = getPublicKeyHex();
  g.members = g.members.filter(h => h !== me);
  await Store.put(STORE_NAMES.groups, g);
  await Audit.memberLeft(groupId, me, reason);
  return g;
}

// ---------- messaging ----------
/**
 * Send a text message into a thread (group or DM).
 *  threadKind: 'group' | 'dm'
 *  groupOrPeer: group object (group) or peer pubkey hex (dm)
 */
export async function sendMessage({ threadKind, target, text }) {
  if (typeof text !== 'string' || !text.length) throw new Error('empty message');
  const senderHex = getPublicKeyHex();
  const ts = Date.now();
  const threadId = threadKind === 'group' ? target.id : `dm_${[senderHex, target].sort().join('_')}`;

  // Derive channel key
  let channelKey;
  if (threadKind === 'group') {
    channelKey = await deriveGroupKey(target.members);
  } else {
    channelKey = await deriveChannelKey(senderHex, target);
  }

  const pt = new TextEncoder().encode(text);
  const aad = aadFor(threadId, senderHex, ts);
  const { iv, ct } = await aesGcmEncrypt(channelKey, pt, aad);

  const A_hex = await sha256Hex(pt);                                   // content integrity
  const B_hex = senderHex;                                             // authentication
  const cBytes = new TextEncoder().encode(`${ts}|${threadId}`);
  const C_hex = await sha256Hex(cBytes);                               // authorization proof

  const payload = { iv: bytesToHex(iv), ct: bytesToHex(ct) };
  const sigBytes = await signUtf8(JSON.stringify({ threadId, ts, payload, A_hex, B_hex, C_hex }));
  const env = {
    id: newId('msg'),
    threadId,
    senderHex,
    ts,
    triadic: { A_hex, B_hex, C_hex },
    payload,
    sig: bytesToHex(sigBytes),
  };
  await Store.put(STORE_NAMES.messages, env);
  await Audit.messageSent(threadId, env.id, A_hex);

  // Cross-device delivery: broadcast the encrypted envelope to every recipient
  // via the same Nostr relay client used for invites. Relay sees only ciphertext
  // + routing pubkeys; the channel key is never on the wire.
  const recipients = threadKind === 'group'
    ? (target.members || []).filter((h) => h && h !== senderHex)
    : (target ? [target] : []);
  if (recipients.length) {
    try { await Audit.chatEnvelope(env, recipients); }
    catch (_) { /* offline / relay unavailable — local copy is already saved */ }
  }
  return env;
}

/**
 * Idempotently persist an envelope received from the relay (or any other source).
 * Returns one of: 'inserted' | 'duplicate' | 'invalid'. The caller is responsible
 * for deciding whether to refresh the active thread.
 */
export async function ingestRemoteEnvelope(env) {
  if (!env || typeof env !== 'object') return 'invalid';
  const required = ['id', 'threadId', 'senderHex', 'ts', 'payload', 'sig', 'triadic'];
  for (const k of required) {
    if (env[k] === undefined || env[k] === null) return 'invalid';
  }
  if (typeof env.payload.iv !== 'string' || typeof env.payload.ct !== 'string') return 'invalid';
  const existing = await Store.get(STORE_NAMES.messages, env.id);
  if (existing) return 'duplicate';
  await Store.put(STORE_NAMES.messages, env);
  return 'inserted';
}

/**
 * Subscribe to incoming chat envelopes addressed to *meHex*. Returns an unsubscribe
 * function. The caller passes an `onIngested(env, status)` callback that fires once
 * per accepted envelope ('inserted' or 'duplicate' — 'invalid' is dropped silently).
 */
export function startChatRelayListener(meHex, onIngested) {
  const subId = `chat-${(meHex || '').slice(0, 8)}`;
  const since = Math.floor(Date.now() / 1000) - 7 * 24 * 3600;
  subscribeRelays(subId, [{
    kinds: [CHAT.ENVELOPE],
    '#p': [meHex],
    since,
  }], async (evt) => {
    let env;
    try { env = JSON.parse(evt.content); }
    catch (_) { return; }
    const status = await ingestRemoteEnvelope(env);
    if (status === 'inserted' && typeof onIngested === 'function') {
      try { onIngested(env, status); } catch (_) { /* swallow */ }
    }
  });
  return () => unsubscribeRelays(subId);
}

/** Decrypt one stored envelope. Group decryption requires the group object. */
export async function decryptMessage(env, ctx) {
  const aad = aadFor(env.threadId, env.senderHex, env.ts);
  let channelKey;
  if (ctx.threadKind === 'group') {
    channelKey = await deriveGroupKey(ctx.group.members);
  } else {
    const me = getPublicKeyHex();
    const peer = env.senderHex === me ? ctx.peerHex : env.senderHex;
    channelKey = await deriveChannelKey(me, peer);
  }
  const iv = hexToBytes(env.payload.iv);
  const ct = hexToBytes(env.payload.ct);
  const pt = await aesGcmDecrypt(channelKey, iv, ct, aad);
  return new TextDecoder().decode(pt);
}

export async function listMessages(threadId) {
  return Store.byIndex(STORE_NAMES.messages, 'by_thread', threadId);
}

/** Verify the triadic identity of a stored message (A is the SHA-256 of plaintext). */
export async function verifyTriadic(env, plaintextStr) {
  const pt = new TextEncoder().encode(plaintextStr);
  const A = await sha256Hex(pt);
  const B = env.senderHex;
  const C = await sha256Hex(new TextEncoder().encode(`${env.ts}|${env.threadId}`));
  return env.triadic.A_hex === A && env.triadic.B_hex === B && env.triadic.C_hex === C;
}

/** DM thread id helper. */
export function dmThreadId(meHex, peerHex) {
  return `dm_${[meHex, peerHex].sort().join('_')}`;
}
