/**
 * relationship-filter.js
 * ----------------------
 * UI + logic for the four-preset + custom relationship filter used during
 * group creation and member invitation flows.
 *
 *   Presets:
 *     'ancestors'   → types 1..10
 *     'descendants' → types 11..20
 *     'lateral'     → types 21..29
 *     'inlaws'      → types 30..31
 *     'custom'      → caller-provided Set<id>
 */

import { REL_CATEGORIES, REL_TYPE_LIST, typesInCategory, isValidRelType, relTypeLabel } from '../family/family-taxonomy.js';

export const PRESET_KEYS = Object.freeze([
  'ancestors', 'descendants', 'lateral', 'inlaws', 'custom',
]);

export class RelationshipFilter {
  constructor() {
    this.preset = 'lateral';
    this.customIds = new Set();
  }
  setPreset(key) {
    if (!PRESET_KEYS.includes(key)) throw new RangeError(`invalid preset ${key}`);
    this.preset = key;
    return this;
  }
  setCustom(ids) {
    this.customIds = new Set([...ids].filter(isValidRelType));
    this.preset = 'custom';
    return this;
  }
  /** Resolve to the active set of rel_type ids. */
  selectedIds() {
    if (this.preset === 'custom') return new Set(this.customIds);
    return new Set(typesInCategory(this.preset));
  }
  /** Filter a list of {pubkeyHex, rel_type, ...} members. */
  filterMembers(members) {
    const ids = this.selectedIds();
    return members.filter((m) => ids.has(m.rel_type));
  }
  toJSON() {
    return {
      preset: this.preset,
      customIds: this.preset === 'custom' ? [...this.customIds] : null,
    };
  }
  static fromJSON(o) {
    const f = new RelationshipFilter();
    if (o && PRESET_KEYS.includes(o.preset)) f.preset = o.preset;
    if (o && Array.isArray(o.customIds)) f.customIds = new Set(o.customIds);
    return f;
  }
}

/**
 * Render the filter into a container element. Hooks return the active filter.
 *   onChange(filter) — invoked whenever the selection changes.
 */
export function renderFilterInto(container, { initial, onChange }) {
  const filter = initial instanceof RelationshipFilter ? initial : new RelationshipFilter();
  container.innerHTML = '';
  const presetWrap = document.createElement('div');
  presetWrap.className = 'row';
  const presets = [
    ['ancestors',   REL_CATEGORIES.ancestors.label],
    ['descendants', REL_CATEGORIES.descendants.label],
    ['lateral',     REL_CATEGORIES.lateral.label],
    ['inlaws',      REL_CATEGORIES.inlaws.label],
    ['custom',      'Custom'],
  ];
  const customWrap = document.createElement('div');
  customWrap.className = 'row';
  customWrap.style.marginTop = '8px';
  customWrap.style.display = filter.preset === 'custom' ? 'flex' : 'none';

  presets.forEach(([key, label]) => {
    const chip = document.createElement('span');
    chip.className = 'chip' + (filter.preset === key ? ' selected' : '');
    chip.textContent = label;
    chip.dataset.key = key;
    chip.onclick = () => {
      filter.setPreset(key);
      [...presetWrap.children].forEach((c) => c.classList.toggle('selected', c.dataset.key === key));
      customWrap.style.display = key === 'custom' ? 'flex' : 'none';
      if (onChange) onChange(filter);
    };
    presetWrap.appendChild(chip);
  });

  REL_TYPE_LIST.forEach((rt) => {
    const chip = document.createElement('span');
    chip.className = 'chip' + (filter.customIds.has(rt.id) ? ' selected' : '');
    chip.textContent = rt.label;
    chip.dataset.id = rt.id;
    chip.onclick = () => {
      if (filter.customIds.has(rt.id)) filter.customIds.delete(rt.id);
      else filter.customIds.add(rt.id);
      filter.preset = 'custom';
      chip.classList.toggle('selected');
      if (onChange) onChange(filter);
    };
    customWrap.appendChild(chip);
  });

  container.appendChild(presetWrap);
  container.appendChild(customWrap);
  return filter;
}

export { relTypeLabel };
