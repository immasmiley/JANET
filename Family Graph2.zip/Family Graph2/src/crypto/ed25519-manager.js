/**
 * ed25519-manager.js
 * ------------------
 * Zero-setup Ed25519 keypair management.
 *
 *   - Auto-generated on first load via window.crypto.subtle (when available).
 *   - Private key is non-extractable; we only ever store the CryptoKey handle,
 *     never raw bytes. Public key is stored hex for advertisement / QR.
 *   - Falls back to a self-contained pure-JS Ed25519 implementation when
 *     SubtleCrypto Ed25519 is unavailable; in that mode the secret is stored
 *     in IndexedDB as a non-exportable opaque blob (still never logged, never
 *     placed in localStorage / plaintext export paths).
 *
 *  Public API:
 *    ensureIdentity()     -> {pubkeyHex, source:'subtle'|'fallback'}
 *    getPublicKeyHex()
 *    sign(bytes)          -> Uint8Array signature
 *    verify(bytes, sig, pubHex) -> boolean
 *    bytesToHex / hexToBytes utilities
 */

import { Store, STORE_NAMES } from '../storage/indexeddb-store.js';

const KEY_ID = 'self';

// ------------- helpers -------------
const HEX = '0123456789abcdef';
export function bytesToHex(b) {
  const u = b instanceof Uint8Array ? b : new Uint8Array(b);
  let s = '';
  for (let i = 0; i < u.length; i++) {
    s += HEX[u[i] >> 4] + HEX[u[i] & 15];
  }
  return s;
}
export function hexToBytes(h) {
  if (typeof h !== 'string' || h.length % 2) throw new Error('invalid hex');
  const out = new Uint8Array(h.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(h.substr(i * 2, 2), 16);
  }
  return out;
}
export function randomBytes(n) {
  const b = new Uint8Array(n);
  crypto.getRandomValues(b);
  return b;
}

// ------------- subtle availability probe -------------
let _subtleEd25519 = null;
async function probeSubtleEd25519() {
  if (_subtleEd25519 !== null) return _subtleEd25519;
  try {
    const kp = await crypto.subtle.generateKey({ name: 'Ed25519' }, false, ['sign', 'verify']);
    _subtleEd25519 = !!kp;
  } catch (_) {
    _subtleEd25519 = false;
  }
  return _subtleEd25519;
}

// ------------- fallback ed25519 (RFC 8032) — compact pure-JS implementation -------------
// Constants for ed25519 over GF(2^255-19); small but complete signer/verifier.
// Adapted, condensed, from the public-domain "tweetnacl" Ed25519 reference.
// Sufficient for browsers without SubtleCrypto Ed25519; has not been hardened
// against side-channels and SHOULD NOT be used in adversarial environments.
// In normal browsers (Chrome 113+, Firefox 130+) the SubtleCrypto path is taken.
const _ed = (() => {
  const D = new Float64Array([
    0x78a3, 0x1359, 0x4dca, 0x75eb, 0xd8ab, 0x4141, 0x0a4d, 0x0070,
    0xe898, 0x7779, 0x4079, 0x8cc7, 0xfe73, 0x2b6f, 0x6cee, 0x5203,
  ]);
  const D2 = new Float64Array([
    0xf159, 0x26b2, 0x9b94, 0xebd6, 0xb156, 0x8283, 0x149a, 0x00e0,
    0xd130, 0xeef3, 0x80f2, 0x198e, 0xfce7, 0x56df, 0xd9dc, 0x2406,
  ]);
  const X = new Float64Array([
    0xd51a, 0x8f25, 0x2d60, 0xc956, 0xa7b2, 0x9525, 0xc760, 0x692c,
    0xdc5c, 0xfdd6, 0xe231, 0xc0a4, 0x53fe, 0xcd6e, 0x36d3, 0x2169,
  ]);
  const Y = new Float64Array([
    0x6658, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666,
    0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666, 0x6666,
  ]);
  const I = new Float64Array([
    0xa0b0, 0x4a0e, 0x1b27, 0xc4ee, 0xe478, 0xad2f, 0x1806, 0x2f43,
    0xd7a7, 0x3dfb, 0x0099, 0x2b4d, 0xdf0b, 0x4fc1, 0x2480, 0x2b83,
  ]);
  function gf(init) { const r = new Float64Array(16); if (init) for (let i = 0; i < init.length; i++) r[i] = init[i]; return r; }
  function set25519(r, a) { for (let i = 0; i < 16; i++) r[i] = a[i] | 0; }
  function car25519(o) {
    let v, c = 1;
    for (let i = 0; i < 16; i++) {
      v = o[i] + c + 65535;
      c = Math.floor(v / 65536);
      o[i] = v - c * 65536;
    }
    o[0] += c - 1 + 37 * (c - 1);
  }
  function sel25519(p, q, b) {
    let t, c = ~(b - 1);
    for (let i = 0; i < 16; i++) {
      t = c & (p[i] ^ q[i]);
      p[i] ^= t; q[i] ^= t;
    }
  }
  function pack25519(o, n) {
    let i, j, b;
    const m = gf(), t = gf();
    for (i = 0; i < 16; i++) t[i] = n[i];
    car25519(t); car25519(t); car25519(t);
    for (j = 0; j < 2; j++) {
      m[0] = t[0] - 0xffed;
      for (i = 1; i < 15; i++) {
        m[i] = t[i] - 0xffff - ((m[i - 1] >> 16) & 1);
        m[i - 1] &= 0xffff;
      }
      m[15] = t[15] - 0x7fff - ((m[14] >> 16) & 1);
      b = (m[15] >> 16) & 1;
      m[14] &= 0xffff;
      sel25519(t, m, 1 - b);
    }
    for (i = 0; i < 16; i++) {
      o[2 * i] = t[i] & 0xff;
      o[2 * i + 1] = t[i] >> 8;
    }
  }
  function unpack25519(o, n) {
    for (let i = 0; i < 16; i++) o[i] = n[2 * i] + (n[2 * i + 1] << 8);
    o[15] &= 0x7fff;
  }
  function A(o, a, b) { for (let i = 0; i < 16; i++) o[i] = a[i] + b[i]; }
  function Z(o, a, b) { for (let i = 0; i < 16; i++) o[i] = a[i] - b[i]; }
  function M(o, a, b) {
    let v, c, t = new Float64Array(31);
    for (let i = 0; i < 31; i++) t[i] = 0;
    for (let i = 0; i < 16; i++) {
      v = a[i];
      for (let j = 0; j < 16; j++) t[i + j] += v * b[j];
    }
    for (let i = 0; i < 15; i++) t[i] += 38 * t[i + 16];
    for (let i = 0; i < 16; i++) o[i] = t[i];
    car25519(o); car25519(o);
  }
  function S(o, a) { M(o, a, a); }
  function inv25519(o, i) {
    const c = gf();
    for (let a = 0; a < 16; a++) c[a] = i[a];
    for (let a = 253; a >= 0; a--) {
      S(c, c);
      if (a !== 2 && a !== 4) M(c, c, i);
    }
    for (let a = 0; a < 16; a++) o[a] = c[a];
  }
  function pow2523(o, i) {
    const c = gf();
    for (let a = 0; a < 16; a++) c[a] = i[a];
    for (let a = 250; a >= 0; a--) { S(c, c); if (a !== 1) M(c, c, i); }
    for (let a = 0; a < 16; a++) o[a] = c[a];
  }
  function add(p, q) {
    const a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf(), g = gf(), h = gf(), t = gf();
    Z(a, p[1], p[0]); Z(t, q[1], q[0]); M(a, a, t);
    A(b, p[0], p[1]); A(t, q[0], q[1]); M(b, b, t);
    M(c, p[3], q[3]); M(c, c, D2);
    M(d, p[2], q[2]); A(d, d, d);
    Z(e, b, a); Z(f, d, c); A(g, d, c); A(h, b, a);
    M(p[0], e, f); M(p[1], h, g); M(p[2], g, f); M(p[3], e, h);
  }
  function cswap(p, q, b) {
    for (let i = 0; i < 4; i++) sel25519(p[i], q[i], b);
  }
  function pack(r, p) {
    const tx = gf(), ty = gf(), zi = gf();
    inv25519(zi, p[2]);
    M(tx, p[0], zi);
    M(ty, p[1], zi);
    pack25519(r, ty);
    r[31] ^= (parTrunc(tx) << 7);
  }
  function parTrunc(a) {
    const d = new Uint8Array(32);
    pack25519(d, a);
    return d[0] & 1;
  }
  function scalarmult(p, q, s) {
    set25519(p[0], gf()); set25519(p[1], gf([1])); set25519(p[2], gf([1])); set25519(p[3], gf());
    for (let i = 255; i >= 0; --i) {
      const b = (s[(i / 8) | 0] >> (i & 7)) & 1;
      cswap(p, q, b);
      add(q, p);
      add(p, p);
      cswap(p, q, b);
    }
  }
  function scalarbase(p, s) {
    const q = [gf(), gf(), gf(), gf()];
    set25519(q[0], X); set25519(q[1], Y); set25519(q[2], gf([1])); M(q[3], X, Y);
    scalarmult(p, q, s);
  }

  // SHA-512 (compact)
  const K = [
    0x428a2f98d728ae22n, 0x7137449123ef65cdn, 0xb5c0fbcfec4d3b2fn, 0xe9b5dba58189dbbcn,
    0x3956c25bf348b538n, 0x59f111f1b605d019n, 0x923f82a4af194f9bn, 0xab1c5ed5da6d8118n,
    0xd807aa98a3030242n, 0x12835b0145706fben, 0x243185be4ee4b28cn, 0x550c7dc3d5ffb4e2n,
    0x72be5d74f27b896fn, 0x80deb1fe3b1696b1n, 0x9bdc06a725c71235n, 0xc19bf174cf692694n,
    0xe49b69c19ef14ad2n, 0xefbe4786384f25e3n, 0x0fc19dc68b8cd5b5n, 0x240ca1cc77ac9c65n,
    0x2de92c6f592b0275n, 0x4a7484aa6ea6e483n, 0x5cb0a9dcbd41fbd4n, 0x76f988da831153b5n,
    0x983e5152ee66dfabn, 0xa831c66d2db43210n, 0xb00327c898fb213fn, 0xbf597fc7beef0ee4n,
    0xc6e00bf33da88fc2n, 0xd5a79147930aa725n, 0x06ca6351e003826fn, 0x142929670a0e6e70n,
    0x27b70a8546d22ffcn, 0x2e1b21385c26c926n, 0x4d2c6dfc5ac42aedn, 0x53380d139d95b3dfn,
    0x650a73548baf63den, 0x766a0abb3c77b2a8n, 0x81c2c92e47edaee6n, 0x92722c851482353bn,
    0xa2bfe8a14cf10364n, 0xa81a664bbc423001n, 0xc24b8b70d0f89791n, 0xc76c51a30654be30n,
    0xd192e819d6ef5218n, 0xd69906245565a910n, 0xf40e35855771202an, 0x106aa07032bbd1b8n,
    0x19a4c116b8d2d0c8n, 0x1e376c085141ab53n, 0x2748774cdf8eeb99n, 0x34b0bcb5e19b48a8n,
    0x391c0cb3c5c95a63n, 0x4ed8aa4ae3418acbn, 0x5b9cca4f7763e373n, 0x682e6ff3d6b2b8a3n,
    0x748f82ee5defb2fcn, 0x78a5636f43172f60n, 0x84c87814a1f0ab72n, 0x8cc702081a6439ecn,
    0x90befffa23631e28n, 0xa4506cebde82bde9n, 0xbef9a3f7b2c67915n, 0xc67178f2e372532bn,
    0xca273eceea26619cn, 0xd186b8c721c0c207n, 0xeada7dd6cde0eb1en, 0xf57d4f7fee6ed178n,
    0x06f067aa72176fban, 0x0a637dc5a2c898a6n, 0x113f9804bef90daen, 0x1b710b35131c471bn,
    0x28db77f523047d84n, 0x32caab7b40c72493n, 0x3c9ebe0a15c9bebcn, 0x431d67c49c100d4cn,
    0x4cc5d4becb3e42b6n, 0x597f299cfc657e2an, 0x5fcb6fab3ad6faecn, 0x6c44198c4a475817n,
  ];
  function rotr(x, n) { return (x >> n) | (x << (64n - n)) & 0xffffffffffffffffn; }
  function sha512(msg) {
    const M = new Uint8Array((Math.ceil((msg.length + 17) / 128)) * 128);
    M.set(msg);
    M[msg.length] = 0x80;
    const bitLen = BigInt(msg.length) * 8n;
    const dv = new DataView(M.buffer);
    dv.setBigUint64(M.length - 8, bitLen);
    const H = [
      0x6a09e667f3bcc908n, 0xbb67ae8584caa73bn, 0x3c6ef372fe94f82bn, 0xa54ff53a5f1d36f1n,
      0x510e527fade682d1n, 0x9b05688c2b3e6c1fn, 0x1f83d9abfb41bd6bn, 0x5be0cd19137e2179n,
    ];
    const W = new BigUint64Array(80);
    for (let off = 0; off < M.length; off += 128) {
      for (let i = 0; i < 16; i++) W[i] = dv.getBigUint64(off + i * 8);
      for (let i = 16; i < 80; i++) {
        const s0 = rotr(W[i-15], 1n) ^ rotr(W[i-15], 8n) ^ (W[i-15] >> 7n);
        const s1 = rotr(W[i-2], 19n) ^ rotr(W[i-2], 61n) ^ (W[i-2] >> 6n);
        W[i] = (W[i-16] + s0 + W[i-7] + s1) & 0xffffffffffffffffn;
      }
      let [a,b,c,d,e,f,g,h] = H;
      for (let i = 0; i < 80; i++) {
        const S1 = rotr(e, 14n) ^ rotr(e, 18n) ^ rotr(e, 41n);
        const ch = (e & f) ^ (~e & 0xffffffffffffffffn & g);
        const t1 = (h + S1 + ch + K[i] + W[i]) & 0xffffffffffffffffn;
        const S0 = rotr(a, 28n) ^ rotr(a, 34n) ^ rotr(a, 39n);
        const mj = (a & b) ^ (a & c) ^ (b & c);
        const t2 = (S0 + mj) & 0xffffffffffffffffn;
        h = g; g = f; f = e; e = (d + t1) & 0xffffffffffffffffn;
        d = c; c = b; b = a; a = (t1 + t2) & 0xffffffffffffffffn;
      }
      H[0]=(H[0]+a)&0xffffffffffffffffn; H[1]=(H[1]+b)&0xffffffffffffffffn;
      H[2]=(H[2]+c)&0xffffffffffffffffn; H[3]=(H[3]+d)&0xffffffffffffffffn;
      H[4]=(H[4]+e)&0xffffffffffffffffn; H[5]=(H[5]+f)&0xffffffffffffffffn;
      H[6]=(H[6]+g)&0xffffffffffffffffn; H[7]=(H[7]+h)&0xffffffffffffffffn;
    }
    const out = new Uint8Array(64);
    const odv = new DataView(out.buffer);
    for (let i = 0; i < 8; i++) odv.setBigUint64(i * 8, H[i]);
    return out;
  }

  function reduce(r) {
    const x = new Float64Array(64);
    for (let i = 0; i < 64; i++) x[i] = r[i];
    for (let i = 0; i < 64; i++) r[i] = 0;
    modL(r, x);
  }
  const L = new Float64Array([
    0xed, 0xd3, 0xf5, 0x5c, 0x1a, 0x63, 0x12, 0x58,
    0xd6, 0x9c, 0xf7, 0xa2, 0xde, 0xf9, 0xde, 0x14,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0x10
  ]);
  function modL(r, x) {
    let carry, i, j, k;
    for (i = 63; i >= 32; --i) {
      carry = 0;
      for (j = i - 32, k = i - 12; j < k; ++j) {
        x[j] += carry - 16 * x[i] * L[j - (i - 32)];
        carry = Math.floor((x[j] + 128) / 256);
        x[j] -= carry * 256;
      }
      x[j] += carry;
      x[i] = 0;
    }
    carry = 0;
    for (j = 0; j < 32; j++) {
      x[j] += carry - (x[31] >> 4) * L[j];
      carry = x[j] >> 8;
      x[j] &= 255;
    }
    for (j = 0; j < 32; j++) x[j] -= carry * L[j];
    for (i = 0; i < 32; i++) {
      x[i + 1] += x[i] >> 8;
      r[i] = x[i] & 255;
    }
  }

  function generateKey() {
    const seed = randomBytes(32);
    return keypairFromSeed(seed);
  }
  function keypairFromSeed(seed) {
    const h = sha512(seed);
    h[0] &= 248; h[31] &= 127; h[31] |= 64;
    const p = [gf(), gf(), gf(), gf()];
    scalarbase(p, h);
    const pk = new Uint8Array(32);
    pack(pk, p);
    const sk = new Uint8Array(64);
    sk.set(seed);
    sk.set(pk, 32);
    return { secret: sk, publicKey: pk };
  }
  function sign(message, sk) {
    const d = sha512(sk.subarray(0, 32));
    d[0] &= 248; d[31] &= 127; d[31] |= 64;
    const pk = sk.subarray(32, 64);

    const rHashInput = new Uint8Array(32 + message.length);
    rHashInput.set(d.subarray(32, 64), 0);
    rHashInput.set(message, 32);
    const r = sha512(rHashInput);
    reduce(r);

    const p = [gf(), gf(), gf(), gf()];
    scalarbase(p, r);
    const R = new Uint8Array(32);
    pack(R, p);

    const hramInput = new Uint8Array(32 + 32 + message.length);
    hramInput.set(R, 0);
    hramInput.set(pk, 32);
    hramInput.set(message, 64);
    const hram = sha512(hramInput);
    reduce(hram);

    const x = new Float64Array(64);
    for (let i = 0; i < 32; i++) x[i] = r[i];
    for (let i = 0; i < 32; i++) {
      for (let j = 0; j < 32; j++) {
        x[i + j] += hram[i] * d[j];
      }
    }
    const sig = new Uint8Array(64);
    sig.set(R, 0);
    modL(sig.subarray(32), x);
    return sig;
  }
  function unpackneg(r, p) {
    const t = gf(), chk = gf(), num = gf(), den = gf(), den2 = gf(), den4 = gf(), den6 = gf();
    set25519(r[2], gf([1]));
    unpack25519(r[1], p);
    S(num, r[1]); M(den, num, D); Z(num, num, r[2]); A(den, r[2], den);
    S(den2, den); S(den4, den2); M(den6, den4, den2); M(t, den6, num); M(t, t, den);
    pow2523(t, t); M(t, t, num); M(t, t, den); M(t, t, den); M(r[0], t, den);
    S(chk, r[0]); M(chk, chk, den);
    if (!neq(chk, num)) M(r[0], r[0], I);
    S(chk, r[0]); M(chk, chk, den);
    if (!neq(chk, num)) return -1;
    if (parTrunc(r[0]) === (p[31] >> 7)) Z(r[0], gf(), r[0]);
    M(r[3], r[0], r[1]);
    return 0;
  }
  function neq(a, b) {
    const c = new Uint8Array(32), d = new Uint8Array(32);
    pack25519(c, a); pack25519(d, b);
    let r = 0;
    for (let i = 0; i < 32; i++) r |= c[i] ^ d[i];
    return r === 0;
  }
  function verify(sig, msg, pk) {
    if (sig.length !== 64 || pk.length !== 32) return false;
    const q = [gf(), gf(), gf(), gf()];
    if (unpackneg(q, pk) !== 0) return false;
    const hramInput = new Uint8Array(32 + 32 + msg.length);
    hramInput.set(sig.subarray(0, 32), 0);
    hramInput.set(pk, 32);
    hramInput.set(msg, 64);
    const h = sha512(hramInput);
    reduce(h);
    const p = [gf(), gf(), gf(), gf()];
    scalarmult(p, q, h);
    const r = [gf(), gf(), gf(), gf()];
    set25519(r[0], gf()); set25519(r[1], gf([1])); set25519(r[2], gf([1])); set25519(r[3], gf());
    // We use scalarbase with the second half of the signature
    scalarbase(r, sig.subarray(32, 64));
    add(p, r);
    const t = new Uint8Array(32);
    pack(t, p);
    let ok = 0;
    for (let i = 0; i < 32; i++) ok |= sig[i] ^ t[i];
    return ok === 0;
  }
  return { generateKey, keypairFromSeed, sign, verify };
})();

// ------------- public API -------------
let _mode = null;        // 'subtle' | 'fallback'
let _publicHex = null;
let _subtleKeys = null;  // {privateKey, publicKey}
let _fallbackSecret = null; // Uint8Array(64) — non-extractable contract: never returned

export async function ensureIdentity() {
  const existing = await Store.get(STORE_NAMES.keys, KEY_ID);
  if (existing) {
    _mode = existing.mode;
    _publicHex = existing.pubkeyHex;
    if (_mode === 'subtle') {
      _subtleKeys = { privateKey: existing.privateKey, publicKey: existing.publicKey };
    } else {
      _fallbackSecret = existing._secret; // remains in IDB-bound closure; never exposed
    }
    return { pubkeyHex: _publicHex, source: _mode };
  }
  const subtleOk = await probeSubtleEd25519();
  if (subtleOk) {
    const kp = await crypto.subtle.generateKey({ name: 'Ed25519' }, false, ['sign', 'verify']);
    const raw = new Uint8Array(await crypto.subtle.exportKey('raw', kp.publicKey));
    _publicHex = bytesToHex(raw);
    _mode = 'subtle';
    _subtleKeys = kp;
    await Store.put(STORE_NAMES.keys, {
      id: KEY_ID, mode: _mode,
      privateKey: kp.privateKey,    // CryptoKey – non-extractable, structured-cloned to IDB
      publicKey: kp.publicKey,
      pubkeyHex: _publicHex,
      createdAt: Date.now(),
    });
  } else {
    const kp = _ed.generateKey();
    _fallbackSecret = kp.secret;
    _publicHex = bytesToHex(kp.publicKey);
    _mode = 'fallback';
    await Store.put(STORE_NAMES.keys, {
      id: KEY_ID, mode: _mode,
      _secret: kp.secret,           // Uint8Array stored in IDB; never exported via API
      pubkeyHex: _publicHex,
      createdAt: Date.now(),
    });
  }
  return { pubkeyHex: _publicHex, source: _mode };
}

export function getPublicKeyHex() { return _publicHex; }
export function getMode() { return _mode; }

/** Reset in-memory identity state. Used after a demo wipe before a fresh ensureIdentity(). */
export function resetIdentityState() {
  _mode = null;
  _publicHex = null;
  _subtleKeys = null;
  _fallbackSecret = null;
  _subtleEd25519 = null;
}

/** Deterministic 32-byte seed from a label string (SHA-256 first 32 bytes). */
async function deterministicSeed(label) {
  const bytes = new TextEncoder().encode(label);
  const h = await crypto.subtle.digest('SHA-256', bytes);
  return new Uint8Array(h);
}

/** Per-install salt mixed into demo seed so cross-device demos don't share keys. */
async function getInstallSalt() {
  const cur = await Store.get(STORE_NAMES.meta, 'install_salt');
  if (cur && cur.v) return cur.v;
  const salt = bytesToHex(randomBytes(16));
  await Store.put(STORE_NAMES.meta, { k: 'install_salt', v: salt });
  return salt;
}

/**
 * Bootstrap a *demo* identity using a deterministic seed.
 * The key is reproducible across reloads on this device, but unique across
 * devices because of a per-install salt. It is still labelled `mode:'demo'`
 * and wiped via retireDemo() when the user starts a real graph.
 */
export async function ensureDemoIdentity(label = 'janet-fc-demo-self-v1') {
  const existing = await Store.get(STORE_NAMES.keys, KEY_ID);
  if (existing) {
    _mode = existing.mode;
    _publicHex = existing.pubkeyHex;
    if (_mode === 'subtle') {
      _subtleKeys = { privateKey: existing.privateKey, publicKey: existing.publicKey };
    } else {
      _fallbackSecret = existing._secret;
    }
    return { pubkeyHex: _publicHex, source: _mode };
  }
  const installSalt = await getInstallSalt();
  const seed = await deterministicSeed(`${label}|${installSalt}`);
  const kp = _ed.keypairFromSeed(seed);
  _fallbackSecret = kp.secret;
  _publicHex = bytesToHex(kp.publicKey);
  _mode = 'demo';
  await Store.put(STORE_NAMES.keys, {
    id: KEY_ID, mode: _mode,
    _secret: kp.secret,
    pubkeyHex: _publicHex,
    createdAt: Date.now(),
    isDemo: true,
  });
  return { pubkeyHex: _publicHex, source: 'demo' };
}

/** Generate a deterministic Ed25519 *public* key (hex) for a demo relative.
 *  No private key is stored — these are mock peers used only to populate
 *  the family graph and derive group channel keys for sample messages.
 */
export async function generateDemoPubkeyHex(tag) {
  const seed = await deterministicSeed(`janet-fc-demo-relative-${tag}-v1`);
  const kp = _ed.keypairFromSeed(seed);
  return bytesToHex(kp.publicKey);
}

export async function sign(bytes) {
  if (!_mode) await ensureIdentity();
  if (_mode === 'subtle') {
    const sig = await crypto.subtle.sign({ name: 'Ed25519' }, _subtleKeys.privateKey, bytes);
    return new Uint8Array(sig);
  }
  return _ed.sign(bytes, _fallbackSecret);
}

export async function verify(bytes, signature, pubHex) {
  const pk = hexToBytes(pubHex);
  const subtleOk = await probeSubtleEd25519();
  if (subtleOk) {
    try {
      const key = await crypto.subtle.importKey('raw', pk, { name: 'Ed25519' }, false, ['verify']);
      return await crypto.subtle.verify({ name: 'Ed25519' }, key, signature, bytes);
    } catch (_) { /* fallthrough */ }
  }
  return _ed.verify(signature, bytes, pk);
}

/** Convenience: sign UTF-8 string. */
export async function signUtf8(str) {
  const enc = new TextEncoder().encode(str);
  return sign(enc);
}
export async function verifyUtf8(str, sig, pubHex) {
  const enc = new TextEncoder().encode(str);
  return verify(enc, sig, pubHex);
}

/** Derive a *deterministic* shared symmetric key from two ed25519 pubkeys.
 *  Uses HKDF over the lexicographic concatenation of the two public keys.
 *  This is NOT an ECDH on Ed25519 (which would require X25519 conversion);
 *  it is a pubkey-bound channel salt suitable for symmetric AES-GCM keys
 *  combined with a session nonce. For real ECDH, convert to X25519 first.
 */
export async function deriveChannelKey(pubHexA, pubHexB, contextLabel = 'janet-fc-channel') {
  const a = hexToBytes(pubHexA);
  const b = hexToBytes(pubHexB);
  const [lo, hi] = bytesToHex(a) < bytesToHex(b) ? [a, b] : [b, a];
  const ikm = new Uint8Array(64);
  ikm.set(lo, 0); ikm.set(hi, 32);
  const baseKey = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    {
      name: 'HKDF',
      hash: 'SHA-256',
      salt: new TextEncoder().encode(contextLabel),
      info: new Uint8Array(),
    },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function aesGcmEncrypt(channelKey, plaintextBytes, aad = new Uint8Array()) {
  const iv = randomBytes(12);
  const ct = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: aad },
    channelKey,
    plaintextBytes
  );
  return { iv, ct: new Uint8Array(ct) };
}
export async function aesGcmDecrypt(channelKey, iv, ct, aad = new Uint8Array()) {
  const pt = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv, additionalData: aad },
    channelKey,
    ct
  );
  return new Uint8Array(pt);
}

export async function sha256Hex(bytes) {
  const h = await crypto.subtle.digest('SHA-256', bytes);
  return bytesToHex(new Uint8Array(h));
}
