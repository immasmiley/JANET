/**
 * indexeddb-store.js
 * ------------------
 * Tiny IndexedDB façade for keys, members, groups, messages, audit events, overlays.
 * Pure ESM, zero deps. Operates with non-extractable CryptoKey objects (browser keeps
 * them safe; we never read raw bytes).
 */

const DB_NAME = 'janet-fc';
const DB_VERSION = 3;

const STORES = {
  keys:    { keyPath: 'id' },         // {id:'self', privateKey, publicKey, pubkeyHex, createdAt}
  members: { keyPath: 'pubkeyHex' },  // {pubkeyHex, n_index, rel_type, degree, displayName, addedAt}
  groups:  { keyPath: 'id' },         // {id, name, filter, members:[pubkeyHex], creatorHex, n_index_bridge, createdAt}
  messages:{ keyPath: 'id', indexes: [{name: 'by_thread', keyPath: 'threadId'}] },
  audit:   { keyPath: 'id', indexes: [{name: 'by_kind', keyPath: 'kind'}] },
  overlays:{ keyPath: 'id' },         // {id, kind:'location'|'language'|'profession', n_index, payload}
  meta:    { keyPath: 'k' },
  invites: { keyPath: 'invite_id' },  // {invite_id, pin (local only), commitment, salt, rel_type, degree_band, attempts:{pubkey:n}, total_attempts, consumed, revoked, expires_at, ...}
  feedRegistry: {
    keyPath: 'id',
    indexes: [{ name: 'by_url', keyPath: 'feed_url' }],
    // {id, feed_url, title, addedByHex, addedAt, adopters:[hex,...], removed?, sig}
  },
  feedFilters: { keyPath: 'pubkeyHex' }, // {pubkeyHex, focus:[term,...], exclude:[term,...]}
};

let _dbPromise = null;
function openDB() {
  if (_dbPromise) return _dbPromise;
  _dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = req.result;
      const tx = req.transaction;
      for (const [name, cfg] of Object.entries(STORES)) {
        let store;
        if (!db.objectStoreNames.contains(name)) {
          store = db.createObjectStore(name, { keyPath: cfg.keyPath });
        } else if (tx) {
          // Existing store — use the upgrade transaction to add any new indexes idempotently.
          store = tx.objectStore(name);
        }
        if (!store) continue;
        const existingIndexes = new Set(Array.from(store.indexNames || []));
        for (const { name: idxName, keyPath, unique } of (cfg.indexes || [])) {
          if (!existingIndexes.has(idxName)) {
            store.createIndex(idxName, keyPath, { unique: !!unique });
          }
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return _dbPromise;
}

function tx(db, store, mode = 'readonly') {
  return db.transaction(store, mode).objectStore(store);
}

async function withStore(name, mode, fn) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const t = db.transaction(name, mode);
    const store = t.objectStore(name);
    const result = fn(store);
    t.oncomplete = () => resolve(result.value !== undefined ? result.value : result);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
}

export const Store = {
  async put(storeName, value) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const t = db.transaction(storeName, 'readwrite');
      const r = t.objectStore(storeName).put(value);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  },
  async get(storeName, key) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const r = db.transaction(storeName, 'readonly').objectStore(storeName).get(key);
      r.onsuccess = () => resolve(r.result || null);
      r.onerror = () => reject(r.error);
    });
  },
  async getAll(storeName) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const r = db.transaction(storeName, 'readonly').objectStore(storeName).getAll();
      r.onsuccess = () => resolve(r.result || []);
      r.onerror = () => reject(r.error);
    });
  },
  async delete(storeName, key) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const r = db.transaction(storeName, 'readwrite').objectStore(storeName).delete(key);
      r.onsuccess = () => resolve();
      r.onerror = () => reject(r.error);
    });
  },
  async clear(storeName) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const r = db.transaction(storeName, 'readwrite').objectStore(storeName).clear();
      r.onsuccess = () => resolve();
      r.onerror = () => reject(r.error);
    });
  },
  async byIndex(storeName, indexName, value) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const idx = db.transaction(storeName, 'readonly').objectStore(storeName).index(indexName);
      const r = idx.getAll(value);
      r.onsuccess = () => resolve(r.result || []);
      r.onerror = () => reject(r.error);
    });
  },
};

export const STORE_NAMES = Object.freeze(Object.fromEntries(
  Object.keys(STORES).map(k => [k, k])
));
