/**
 * demo-seed.js
 * ------------
 * One-time demo bootstrap for first-run validation.
 *
 *   - Seeds a deterministic Ed25519 demo identity (clearly labelled `mode:'demo'`).
 *   - Adds 4 mock relatives spread across hot/warm/cold tiers.
 *   - Creates one sample group with welcome messages from "you (demo)".
 *   - Sets meta `graph_mode = 'demo'`.
 *
 * On retireDemo():
 *   - All IndexedDB stores are cleared (atomic per-store; the contract is "one
 *     family graph per device", so a partial wipe is impossible without an
 *     explicit reload, which boot() handles).
 *   - resetIdentityState() clears in-memory key handles.
 *   - app.js is responsible for calling ensureIdentity() and markLiveMode()
 *     before reloading.
 *
 * Mandates remain in force for the demo: USER_N_INDEX = 0 still asserts
 * (degree=4, ADOPTIVE_CHILD); the 7×31=217 factorisation is unchanged.
 */

import { Store, STORE_NAMES } from '../storage/indexeddb-store.js';
import {
  ensureDemoIdentity,
  generateDemoPubkeyHex,
  resetIdentityState,
  getPublicKeyHex,
} from '../crypto/ed25519-manager.js';
import { USER_N_INDEX } from '../lattice/janet-lattice.js';
import { SELF_ANCHOR, nIndexFor } from '../family/family-graph.js';
import { RelationshipType } from '../family/family-taxonomy.js';
import { createGroup, sendMessage } from '../chat/chat-engine.js';
import { RelationshipFilter } from '../chat/relationship-filter.js';

const META_KEY = 'graph_mode';

export const GraphMode = Object.freeze({
  DEMO: 'demo',
  LIVE: 'live',
});

const DEMO_RELATIVES = [
  { tag: 'mom', name: 'Demo Mom',     rel_type: RelationshipType.PARENT,         degree: 1 },
  { tag: 'sib', name: 'Demo Sibling', rel_type: RelationshipType.SIBLING,        degree: 2 },
  { tag: 'cuz', name: 'Demo Cousin',  rel_type: RelationshipType.COUSIN_FIRST,   degree: 4 },
  { tag: 'inl', name: 'Demo In-Law',  rel_type: RelationshipType.SIBLING_IN_LAW, degree: 5 },
];

export async function getGraphMode() {
  const m = await Store.get(STORE_NAMES.meta, META_KEY);
  return m ? m.v : null;
}

export async function markLiveMode() {
  await Store.put(STORE_NAMES.meta, { k: META_KEY, v: GraphMode.LIVE, since: Date.now() });
}

export async function markDemoMode() {
  await Store.put(STORE_NAMES.meta, { k: META_KEY, v: GraphMode.DEMO, since: Date.now() });
}

/**
 * Seed the demo graph on first run. No-op if a graph_mode is already set.
 * Returns the resolved mode string.
 */
export async function seedDemoIfNeeded() {
  const existing = await getGraphMode();
  if (existing) return existing;

  await ensureDemoIdentity();
  const meHex = getPublicKeyHex();

  // Self anchor at n_index = 0
  await Store.put(STORE_NAMES.members, {
    pubkeyHex: meHex,
    n_index: USER_N_INDEX,
    rel_type: SELF_ANCHOR.rel_type,
    degree: SELF_ANCHOR.degree,
    displayName: 'You (demo)',
    addedAt: Date.now(),
    isDemo: true,
  });

  // Mock relatives across tiers
  const memberRecords = [];
  for (const r of DEMO_RELATIVES) {
    const pub = await generateDemoPubkeyHex(r.tag);
    const rec = {
      pubkeyHex: pub,
      n_index: nIndexFor(r.degree, r.rel_type),
      rel_type: r.rel_type,
      degree: r.degree,
      displayName: r.name,
      addedAt: Date.now(),
      isDemo: true,
    };
    memberRecords.push(rec);
    await Store.put(STORE_NAMES.members, rec);
  }

  // One sample group containing every demo relative.
  const customIds = new Set(memberRecords.map((m) => m.rel_type));
  const filter = new RelationshipFilter().setCustom(customIds);

  // Pre-vouch every relative so warm/cold tiers join cleanly in demo mode.
  const vouchMap = {};
  for (const m of memberRecords) vouchMap[m.pubkeyHex] = 99;

  const grp = await createGroup({
    name: 'Family Demo',
    filter,
    candidates: memberRecords.map((m) => ({
      pubkeyHex: m.pubkeyHex,
      n_index: m.n_index,
      rel_type: m.rel_type,
      degree: m.degree,
    })),
    existingForVouch: vouchMap,
  });

  // Welcome messages from "you (demo)" — all encrypted under the real group key.
  await sendMessage({
    threadKind: 'group', target: grp,
    text: 'Welcome to the JANET demo family graph.',
  });
  await sendMessage({
    threadKind: 'group', target: grp,
    text: 'This sample data is local-first and encrypted. It will be erased the moment you start your real family graph.',
  });
  await sendMessage({
    threadKind: 'group', target: grp,
    text: 'Tap "Start my family" in the banner above to mint your real Ed25519 identity.',
  });

  await markDemoMode();
  return GraphMode.DEMO;
}

/**
 * Atomically retire the demo graph: clear every store, reset in-memory state.
 * Caller must follow with ensureIdentity() + markLiveMode() and reload.
 */
export async function retireDemo() {
  for (const name of Object.values(STORE_NAMES)) {
    await Store.clear(name);
  }
  resetIdentityState();
}
