/**
 * recovery-engine.js
 * ------------------
 * Degree-tier weighted recovery + 1.39% fractal-seed lattice reconstruction.
 *
 *   Vouch threshold by tier (from family-graph):
 *     hot  (deg 1..2): 0    fast / instant
 *     warm (deg 3..4): 1    normal
 *     cold (deg 5..6): 2    slow
 *
 *   Audit kinds:
 *     38010 start  → 38011 vouch (xN)  → 38012 complete  → 38013 rotated
 */

import {
  vouchThresholdForDegree,
  batTierForDegree,
  validateMember,
} from '../family/family-graph.js';
import { Audit } from '../sync/nostr-audit.js';
import {
  reconstructFromSeed,
  N_NODES,
  HALF_IDX,
  FRACTAL_SEED_RATIO,
  USER_N_INDEX,
} from '../lattice/janet-lattice.js';

const _active = new Map(); // requestId -> {oldHex, vouchersHex:Set, threshold, startedAt, degree}

function newRequestId() {
  const r = crypto.getRandomValues(new Uint8Array(8));
  return Array.from(r, b => b.toString(16).padStart(2, '0')).join('');
}

export async function startRecovery({ oldHex, degree }) {
  if (!oldHex || typeof oldHex !== 'string') throw new TypeError('oldHex required');
  const threshold = vouchThresholdForDegree(degree);
  const requestId = newRequestId();
  _active.set(requestId, {
    oldHex, vouchersHex: new Set(), threshold, startedAt: Date.now(), degree,
    tier: batTierForDegree(degree),
  });
  await Audit.recoveryStart(oldHex, requestId);
  return { requestId, threshold, tier: batTierForDegree(degree) };
}

export async function submitVouch({ requestId, voucherHex, voucherDegree }) {
  const req = _active.get(requestId);
  if (!req) throw new Error('unknown recovery request');
  // Voucher must themselves pass member validation w/ a known degree
  const mv = validateMember({ n_index: USER_N_INDEX, degree: 4 });
  if (!mv.ok && voucherDegree == null) throw new Error('voucher degree required');
  req.vouchersHex.add(voucherHex);
  await Audit.recoveryVouch(requestId, voucherHex);
  return {
    have: req.vouchersHex.size,
    need: req.threshold,
    satisfied: req.vouchersHex.size >= req.threshold,
  };
}

export async function completeRecovery({ requestId, newHex }) {
  const req = _active.get(requestId);
  if (!req) throw new Error('unknown recovery request');
  if (req.vouchersHex.size < req.threshold) {
    throw new Error(`insufficient vouches: ${req.vouchersHex.size}/${req.threshold}`);
  }
  await Audit.recoveryComplete(requestId, newHex);
  await Audit.keyRotated(req.oldHex, newHex);
  _active.delete(requestId);
  return { ok: true, oldHex: req.oldHex, newHex };
}

export function activeRequests() {
  return Array.from(_active.entries()).map(([id, v]) => ({
    requestId: id,
    oldHex: v.oldHex,
    have: v.vouchersHex.size,
    need: v.threshold,
    tier: v.tier,
    startedAt: v.startedAt,
  }));
}

/**
 * 1.39% seed reconstruction.
 * Given any valid triple (n_index, A_n, B_n) plus 2 signed audit events,
 * reconstruct the full lattice walk + verify continuity.
 */
export function reconstructLatticeFromTriple(triple, signedAudits = []) {
  if (!triple) throw new TypeError('triple required');
  if (signedAudits.length < 2) {
    throw new Error('need at least 2 signed audit events to anchor the seed');
  }
  const r = reconstructFromSeed(triple);
  return {
    ratio: FRACTAL_SEED_RATIO,
    nodes: r.nodes,
    complete: r.complete,
    visited: r.nodes.length,
    expected: N_NODES,
    equilibrium_present: r.nodes.some(n => n.n === HALF_IDX),
    audits_used: signedAudits.length,
  };
}
