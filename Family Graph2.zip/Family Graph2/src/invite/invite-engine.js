/**
 * invite-engine.js
 * ----------------
 * Three-factor onboarding: knowledge (PIN) + binding (rel_type) + authorization
 * (manual approval). The QR is *not secret*; it can be broadcast publicly via
 * Nostr. The PIN is shared out-of-band (phone/email) and never traverses the
 * wire. Each invite enforces:
 *
 *   - max 3 attempts per joiner pubkey
 *   - max 10 total attempts globally per invite
 *   - absolute TTL (default 24h)
 *   - consumed on first successful + approved bind
 *
 * The commitment is:
 *
 *   commitment = SHA-256( pin || rel_type || degree_band || invite_id || salt )
 *
 * Joiner sends back the same hash; inviter recomputes locally with the
 * remembered PIN. PIN never appears on any signed event.
 */

import { Store, STORE_NAMES } from '../storage/indexeddb-store.js';
import {
  sha256Hex,
  bytesToHex,
  hexToBytes,
  randomBytes,
} from '../crypto/ed25519-manager.js';
import { isValidRelType } from '../family/family-taxonomy.js';

// Crockford Base32 - no I, L, O, U (avoid visual ambiguity).
export const PIN_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
export const PIN_LEN = 5;
export const DEFAULT_TTL_MS = 24 * 60 * 60 * 1000;
export const MAX_ATTEMPTS_PER_JOINER = 3;
export const MAX_TOTAL_ATTEMPTS = 10;

export function generatePin() {
  const bytes = randomBytes(PIN_LEN * 4);
  let pin = '';
  // Use rejection sampling for unbiased pick from 32-char alphabet.
  let i = 0, k = 0;
  while (pin.length < PIN_LEN && k < bytes.length) {
    const v = bytes[k++] & 0x1f; // 0..31
    pin += PIN_ALPHABET[v];
    i++;
  }
  return pin;
}

/** Normalize joiner-typed PIN: uppercase, strip spaces, map ambiguous glyphs. */
export function normalizePin(input) {
  if (typeof input !== 'string') return '';
  return input.trim().toUpperCase().replace(/\s+/g, '')
    .replace(/I/g, '1').replace(/L/g, '1')
    .replace(/O/g, '0').replace(/U/g, 'V');
}

async function commitmentHex(pin, rel_type, degree_band, invite_id_hex, salt_hex) {
  const pinBytes = new TextEncoder().encode(pin);
  const idBytes = hexToBytes(invite_id_hex);
  const saltBytes = hexToBytes(salt_hex);
  const buf = new Uint8Array(pinBytes.length + 2 + idBytes.length + saltBytes.length);
  let off = 0;
  buf.set(pinBytes, off); off += pinBytes.length;
  buf[off++] = rel_type & 0xff;
  buf[off++] = degree_band & 0xff;
  buf.set(idBytes, off); off += idBytes.length;
  buf.set(saltBytes, off);
  return sha256Hex(buf);
}

/**
 * Inviter creates a new invite. Returns the local invite record (includes the
 * PIN — surface it to the inviter UI for out-of-band sharing only).
 */
export async function createInvite({ rel_type, degree_band, ttl_ms = DEFAULT_TTL_MS, inviter_pubkey }) {
  if (!isValidRelType(rel_type)) throw new RangeError('invalid rel_type');
  if (!Number.isInteger(degree_band) || degree_band < 1 || degree_band > 6) {
    throw new RangeError('invalid degree_band');
  }
  const invite_id = bytesToHex(randomBytes(16));
  const salt = bytesToHex(randomBytes(16));
  const pin = generatePin();
  const commitment = await commitmentHex(pin, rel_type, degree_band, invite_id, salt);
  const now = Date.now();
  const inv = {
    invite_id,
    inviter_pubkey,
    pin,            // *** stored locally only; never put in any Nostr event ***
    commitment,
    salt,
    rel_type,
    degree_band,
    attempts: {},
    total_attempts: 0,
    consumed: false,
    revoked: false,
    created_at: now,
    expires_at: now + ttl_ms,
  };
  await Store.put(STORE_NAMES.invites, inv);
  return inv;
}

export async function getInvite(invite_id) {
  if (!invite_id) return null;
  return Store.get(STORE_NAMES.invites, invite_id);
}

export async function listInvites() {
  return Store.getAll(STORE_NAMES.invites);
}

export async function listActiveInvites() {
  const all = await listInvites();
  const now = Date.now();
  return all.filter((i) => !i.consumed && !i.revoked && i.expires_at > now);
}

/**
 * Tally an incoming attempt. Returns updated counters and a permission verdict.
 *   reason: 'unknown_invite' | 'consumed' | 'revoked' | 'expired'
 *           | 'attempts_exceeded' | 'global_cap_reached' | null
 */
export async function tallyAttempt(invite_id, joiner_pubkey) {
  const inv = await getInvite(invite_id);
  if (!inv) return { allowed: false, reason: 'unknown_invite' };
  if (inv.consumed) return { allowed: false, reason: 'consumed' };
  if (inv.revoked) return { allowed: false, reason: 'revoked' };
  if (inv.expires_at <= Date.now()) return { allowed: false, reason: 'expired' };

  inv.attempts[joiner_pubkey] = (inv.attempts[joiner_pubkey] || 0) + 1;
  inv.total_attempts = (inv.total_attempts || 0) + 1;

  if (inv.attempts[joiner_pubkey] > MAX_ATTEMPTS_PER_JOINER) {
    await Store.put(STORE_NAMES.invites, inv);
    return { allowed: false, reason: 'attempts_exceeded',
             attempts: inv.attempts[joiner_pubkey], total: inv.total_attempts };
  }
  if (inv.total_attempts > MAX_TOTAL_ATTEMPTS) {
    inv.revoked = true;
    inv.revoked_reason = 'global_cap';
    inv.revoked_at = Date.now();
    await Store.put(STORE_NAMES.invites, inv);
    return { allowed: false, reason: 'global_cap_reached',
             attempts: inv.attempts[joiner_pubkey], total: inv.total_attempts };
  }
  await Store.put(STORE_NAMES.invites, inv);
  return {
    allowed: true,
    reason: null,
    attempts: inv.attempts[joiner_pubkey],
    total: inv.total_attempts,
    remaining_for_joiner: MAX_ATTEMPTS_PER_JOINER - inv.attempts[joiner_pubkey],
  };
}

/**
 * Verify that the joiner-supplied proof matches the locally-stored PIN AND the
 * claimed (rel_type, degree_band) matches what the inviter expected. Does not
 * mutate the invite (use consumeInvite() after manual approval).
 */
export async function verifyAttempt(invite_id, attempt) {
  const inv = await getInvite(invite_id);
  if (!inv) return { match: false, reason: 'unknown_invite' };
  if (inv.consumed) return { match: false, reason: 'consumed' };
  if (inv.revoked) return { match: false, reason: 'revoked' };
  if (inv.expires_at <= Date.now()) return { match: false, reason: 'expired' };
  if (attempt.rel_type !== inv.rel_type) {
    return { match: false, reason: 'rel_type_mismatch',
             expected_rel_type: inv.rel_type, got_rel_type: attempt.rel_type };
  }
  if (attempt.degree_band !== inv.degree_band) {
    return { match: false, reason: 'degree_mismatch',
             expected_degree: inv.degree_band, got_degree: attempt.degree_band };
  }
  const expected = await commitmentHex(
    inv.pin, attempt.rel_type, attempt.degree_band, invite_id, inv.salt
  );
  if (expected !== attempt.proof_hex) {
    return { match: false, reason: 'proof_mismatch' };
  }
  return { match: true };
}

export async function consumeInvite(invite_id, { joiner_pubkey, n_index } = {}) {
  const inv = await getInvite(invite_id);
  if (!inv) throw new Error('invite not found');
  inv.consumed = true;
  inv.consumed_at = Date.now();
  inv.consumed_by = joiner_pubkey || null;
  inv.consumed_n_index = (n_index ?? null);
  await Store.put(STORE_NAMES.invites, inv);
  return inv;
}

export async function revokeInvite(invite_id, reason = 'manual') {
  const inv = await getInvite(invite_id);
  if (!inv) return null;
  inv.revoked = true;
  inv.revoked_at = Date.now();
  inv.revoked_reason = reason;
  await Store.put(STORE_NAMES.invites, inv);
  return inv;
}

/**
 * Joiner-side: compute the proof to send back to the inviter. The PIN is
 * normalized first so user typos in case/spacing/I-vs-1/O-vs-0 don't fail.
 */
export async function computeJoinerProof({ pin, invite_id, salt, rel_type, degree_band }) {
  const norm = normalizePin(pin);
  return commitmentHex(norm, rel_type, degree_band, invite_id, salt);
}
