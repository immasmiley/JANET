# JANET Family Chat (PWA)
Zero-setup, passwordless, local-first family chat. Identity is auto-generated Ed25519. Trust and group membership are governed by a deterministic 217-node JANET equilibrium lattice with 31 canonical relationship types.
## Quick start
This is a static PWA — no build step, no dependencies.
```sh
# any static server works; from the project root:
python -m http.server 8080
# or:
npx http-server -p 8080
```
Open `http://localhost:8080/` in a modern browser (Chrome 113+, Firefox 130+, Edge, Safari 17+). The first visit auto-generates an Ed25519 keypair via `window.crypto.subtle` and stores the non-extractable handle in IndexedDB.
Run the validation test page at `http://localhost:8080/tests/`.
## Mathematical core
- State space: `S = { x_n | x_n = -100 + n·δ, n ∈ 0..216 }` with `δ = 25/27`
- Equilibrium: `x = 0` at `n = 108` (since `108 · 25/27 = 100`)
- Antisymmetry: `x_{216-n} = -x_n`
- Triadic identity: every `x ∈ S` decomposes as `A + B + C` with `A,B,C ∈ S`
- 1.39% fractal seed: any valid `(n, A, B)` triple plus 2 signed audit events regenerates the whole lattice (`3/216 ≈ 1.389%`)
## Family addressing
`record_index = (degree − 1) · 31 + (rel_type − 1)` for `degree ∈ 1..6`. Indices `186..216` form the reserved band for cross-circle bridges only — never key-binding.
- BAT tiers: deg 1–2 hot (27 polling steps, 0 vouches), deg 3–4 warm (54, 1 vouch), deg 5–6 cold (108, 2 vouches)
- Self-anchor: `USER_N_INDEX = 0` asserts as `(degree=4, ADOPTIVE_CHILD)`
## Module layout
```
index.html              chat UI shell + group create modal + QR modal
manifest.json           installable PWA manifest
sw.js                   offline cache + background sync for audit events
app.js                  front-end glue (boot, sidebar, composer, modals)
src/
  crypto/ed25519-manager.js     auto-genned Ed25519, sign/verify, AES-GCM
  storage/indexeddb-store.js    tiny IndexedDB facade
  lattice/janet-lattice.js      δ-stepping, triadic decomposition, antisymmetry
  family/family-taxonomy.js     31 relationship types + 4 preset categories
  family/family-graph.js        7×31=217 addressing, BAT tiering, mandate asserts
  chat/chat-engine.js           groups, DMs, E2E AES-GCM, triadic envelopes
  chat/relationship-filter.js   4-preset + custom UI helper
  domains/domain-overlays.js    location / language / profession projections
  sync/nostr-audit.js           kinds 38010..38013 signed audit log
  recovery/recovery-engine.js   tier-weighted vouch + 1.39% seed reconstruction
  qr/qr-onboard.js              janet1: QR payload encode/decode/validate
tests/
  index.html                    in-browser test runner
  validation.test.js            mandate test cases
```
## Strict guarantees enforced in code
- Private keys never leave `crypto.subtle` (or non-exported IDB blob in fallback). No localStorage. No mnemonic. No export path.
- No manual pubkey entry, no password fallback, no seed phrases.
- No row expansion: every domain (location/language/profession/etc.) projects onto the same 217-node ring.
- Group membership requires (a) a relationship type ∈ the chosen filter and (b) a tier-appropriate vouch count.
- Recovery requires `38010 → N×38011 → 38012 → 38013` signed events.
## Validation checklist
The test page proves every mandate from the spec:
- `7×31 = 217` factorisation
- `δ = 25/27` integer-ratio precision
- equilibrium at `n=108`, `x=0`
- antisymmetry `x_{216-n} = -x_n` ∀n
- triadic identity tolerance `≤ δ/2`
- BAT tier + polling + vouch routing per degree
- 1.39% fractal seed reconstruction visits all 217 nodes
- Ed25519 sign/verify round-trip
- AES-GCM channel key round-trip
- QR `janet1:` payload encode/decode/validate
## Notes & non-goals
- The fallback Ed25519 path (used only on browsers without SubtleCrypto Ed25519) is a compact pure-JS implementation; in production you should prefer browsers with native support or replace the fallback with a hardened library.
- The "/api/auth/device/challenge" endpoints in the service worker are network-first stubs — the local-first flow signs/verifies inside the app, and the API is only invoked when an external relay is configured.
- Relay sync is intentionally a no-op stub; integrate your preferred Nostr relay client by listening to the `audit` IndexedDB store.
## Co-Author
This project was built with assistance from Oz (oz-agent@warp.dev).
