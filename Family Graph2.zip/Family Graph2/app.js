/**
 * app.js — JANET Family Chat front-end glue.
 *
 * Boot order:
 *   1. Register service worker
 *   2. assertMandates()  (7×31=217, USER_N_INDEX self-anchor)
 *   3. Ed25519 ensureIdentity() — auto-generated, never user-provided
 *   4. Render sidebar / threads / messages
 */

import { Janet, USER_N_INDEX, HALF_IDX, isEquilibrium, triadicDecompose } from './src/lattice/janet-lattice.js';
import { assertMandates, batTierForDegree, SELF_ANCHOR, validateMember, nIndexFor } from './src/family/family-graph.js';
import { REL_TYPE_LIST, relTypeLabel } from './src/family/family-taxonomy.js';
import { ensureIdentity, ensureDemoIdentity, getPublicKeyHex, getMode } from './src/crypto/ed25519-manager.js';
import { Store, STORE_NAMES } from './src/storage/indexeddb-store.js';
import { RelationshipFilter, renderFilterInto } from './src/chat/relationship-filter.js';
import { createGroup, listGroups, sendMessage, decryptMessage, listMessages, dmThreadId, verifyTriadic, startChatRelayListener } from './src/chat/chat-engine.js';
import { buildOnboardPayload, encodePayload, decodePayload, validatePayload, buildInvitePayload, validateInvitePayload } from './src/qr/qr-onboard.js';
import { makeQRMatrix, renderQRSvg } from './src/qr/qr-encoder.js';
import { seedDemoIfNeeded, retireDemo, getGraphMode, markLiveMode, GraphMode } from './src/demo/demo-seed.js';
import {
  createInvite, computeJoinerProof, tallyAttempt, verifyAttempt,
  consumeInvite, revokeInvite, listActiveInvites, getInvite, normalizePin,
  PIN_LEN,
} from './src/invite/invite-engine.js';
import { emit, INVITE, subscribeRelays, unsubscribeRelays } from './src/sync/nostr-audit.js';
import { ensureDefaultRelays, getRelayUrls, addRelayListener } from './src/sync/nostr-relay.js';
import {
  submitFeed, adoptFeed, removeFeed, listFeeds,
  getFilters as getFeedFilters, setFilters as setFeedFilters, applyFilters as applyFeedFilters,
  startFeedRegistryListener,
} from './src/feeds/feed-registry.js';
import {
  fetchFeed, getProxyTemplate, setProxyTemplate, DEFAULT_PROXY_TEMPLATE, testProxy,
} from './src/feeds/feed-fetcher.js';

const $ = (id) => document.getElementById(id);
const toast = (msg) => {
  const t = $('toast'); t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 1800);
};

let active = { kind: null, target: null };  // 'group' or 'dm'
let cachedMembers = [];
let memberByHex = new Map();

async function setMemberDisplayName(pubkeyHex, displayName) {
  const rec = await Store.get(STORE_NAMES.members, pubkeyHex);
  if (!rec) throw new Error('member not found');
  rec.displayName = displayName || null;
  rec.renamedAt = Date.now();
  await Store.put(STORE_NAMES.members, rec);
}

function promptRename(currentName, label = 'Display name') {
  const v = window.prompt(`${label} (leave blank to clear):`, currentName || '');
  if (v === null) return null;            // cancelled
  const trimmed = v.trim();
  if (trimmed.length > 64) {
    toast('Name too long (max 64 chars)');
    return null;
  }
  return trimmed;
}

async function boot() {
  if ('serviceWorker' in navigator) {
    try { await navigator.serviceWorker.register('./sw.js'); } catch (e) { console.warn(e); }
  }
  // Mandates
  try {
    assertMandates();
    const td = triadicDecompose(HALF_IDX);
    if (!isEquilibrium(HALF_IDX) || td.A !== HALF_IDX || td.B !== HALF_IDX || td.C !== HALF_IDX) {
      throw new Error('equilibrium triadic identity violated');
    }
  } catch (e) {
    document.body.innerHTML = `<pre style="color:#ff6b6b;padding:24px">FATAL: ${e.message}</pre>`;
    return;
  }

  // Mode-aware identity bootstrap.
  // graph_mode === null  -> first run, seed demo
  // graph_mode === 'demo' -> reuse demo identity + data
  // graph_mode === 'live' -> reuse real identity
  const initialMode = await getGraphMode();
  let id;
  if (!initialMode) {
    await seedDemoIfNeeded();
    id = { pubkeyHex: getPublicKeyHex(), source: getMode() };
  } else if (initialMode === GraphMode.DEMO) {
    id = await ensureDemoIdentity();
  } else {
    id = await ensureIdentity();
  }
  const currentMode = await getGraphMode();
  const isDemo = currentMode === GraphMode.DEMO;

  // Self-upsert (idempotent), preserving any user-chosen displayName.
  const existingSelf = await Store.get(STORE_NAMES.members, id.pubkeyHex);
  const defaultSelfName = isDemo ? 'You (demo)' : 'You';
  await Store.put(STORE_NAMES.members, {
    pubkeyHex: id.pubkeyHex,
    n_index: USER_N_INDEX,
    rel_type: SELF_ANCHOR.rel_type,
    degree: SELF_ANCHOR.degree,
    displayName: existingSelf?.displayName || defaultSelfName,
    addedAt: existingSelf?.addedAt || Date.now(),
    renamedAt: existingSelf?.renamedAt,
    isDemo,
  });

  await renderIdentityLine();
  $('tier-badge').textContent = `tier: ${batTierForDegree(SELF_ANCHOR.degree)}`;
  $('tier-badge').classList.add(batTierForDegree(SELF_ANCHOR.degree));

  // Demo banner
  const banner = $('demo-banner');
  if (banner) banner.hidden = !isDemo;

  await refreshSidebar();
  wireUi();

  // Bring up Nostr relays + start listening for invite traffic addressed to us.
  ensureDefaultRelays();
  await startInviterListener();
  startChatRelayListener(id.pubkeyHex, onIncomingChat);
  startFeedRegistryListener(id.pubkeyHex, () => { refreshFeedsView().catch(() => {}); });

  // Backwards-compat: legacy v:1 onboarding via URL hash.
  if (location.hash.startsWith('#janet1:')) {
    handleScannedPayload(location.hash.slice(1)).catch((e) => toast(e.message));
  }
  // v:2 invite via URL hash -> open join modal pre-filled.
  if (location.hash.startsWith('#janet2:')) {
    openJoinModal({ prefillPayload: location.hash.slice(1) });
  }
}

// ---- Feeds view ----
let _feedFilterTimer = null;
let _feedItemsCache = [];        // [{ id, sourceUrl, sourceTitle, title, link, summary, ts }]
let _feedItemsErrors = [];       // [{ url, message }]
let _feedItemsRefreshing = false;

function itemMatchesFilter(item, filters) {
  const focus = (filters.focus || []).map((s) => s.toLowerCase());
  const exclude = (filters.exclude || []).map((s) => s.toLowerCase());
  if (!focus.length && !exclude.length) return true;
  const text = `${item.title || ''} ${item.summary || ''} ${item.link || ''} ${item.sourceTitle || ''}`.toLowerCase();
  if (exclude.length && exclude.some((t) => t && text.indexOf(t) >= 0)) return false;
  if (focus.length && !focus.some((t) => t && text.indexOf(t) >= 0)) return false;
  return true;
}

async function refreshFeedItems({ force = true } = {}) {
  const list = document.getElementById('feed-items-list');
  const count = document.getElementById('feed-items-count');
  const status = document.getElementById('feed-items-status');
  if (!list) return;
  if (_feedItemsRefreshing) return;

  // Pick adopted feeds. Submitter is auto-adopted, so newly added feeds load too.
  const me = getPublicKeyHex();
  const all = await listFeeds();
  const adopted = all.filter((e) => (e.adopters || []).includes(me));
  if (!adopted.length) {
    _feedItemsCache = [];
    _feedItemsErrors = [];
    if (count) count.textContent = '';
    if (status) status.textContent = '';
    list.innerHTML = '<div class="feed-empty">Adopt a feed from the registry below to see its latest items here.</div>';
    return;
  }

  if (force) {
    _feedItemsRefreshing = true;
    if (status) status.textContent = `Fetching — ${adopted.length} feed${adopted.length === 1 ? '' : 's'}…`;
    list.innerHTML = '<div class="feed-empty">Loading items…</div>';
    const settled = await Promise.allSettled(adopted.map((e) => fetchFeed(e.feed_url)));
    _feedItemsCache = [];
    _feedItemsErrors = [];
    settled.forEach((res, i) => {
      const url = adopted[i].feed_url;
      if (res.status === 'fulfilled') _feedItemsCache.push(...res.value);
      else _feedItemsErrors.push({ url, message: (res.reason && res.reason.message) || String(res.reason) });
    });
    _feedItemsRefreshing = false;
    if (status) {
      const okN = _feedItemsCache.length;
      const errN = _feedItemsErrors.length;
      status.textContent = `${okN} item${okN === 1 ? '' : 's'} fetched${errN ? ` · ${errN} feed${errN === 1 ? '' : 's'} errored` : ''}.`;
    }
  }

  renderFeedItems();
}

function renderFeedItems() {
  const list = document.getElementById('feed-items-list');
  const count = document.getElementById('feed-items-count');
  if (!list) return;
  // Apply focus/exclude filter (in-memory; no need to await IDB).
  const focusEl = document.getElementById('feed-focus');
  const excludeEl = document.getElementById('feed-exclude');
  const filters = {
    focus: parseTermInput(focusEl?.value),
    exclude: parseTermInput(excludeEl?.value),
  };
  const visible = _feedItemsCache
    .filter((it) => itemMatchesFilter(it, filters))
    .sort((a, b) => (b.ts || 0) - (a.ts || 0))
    .slice(0, 80);
  if (count) count.textContent = visible.length ? `· ${visible.length}` : '';
  const errBlocks = _feedItemsErrors.map((er) =>
    `<div class="feed-item-error">Couldn’t fetch <code>${escapeHtml(er.url)}</code>: ${escapeHtml(er.message)}</div>`
  ).join('');
  if (!visible.length && !errBlocks) {
    list.innerHTML = '<div class="feed-empty">No items match your filters.</div>';
    return;
  }
  if (!visible.length) { list.innerHTML = errBlocks; return; }
  list.innerHTML = errBlocks + visible.map((it) => {
    const title = escapeHtml(it.title || '(untitled)');
    const link = escapeHtml(it.link || '');
    const summary = escapeHtml(it.summary || '');
    const source = escapeHtml(it.sourceTitle || it.sourceUrl);
    const when = it.ts ? new Date(it.ts).toLocaleString() : '';
    const titleNode = link
      ? `<a href="${link}" target="_blank" rel="noopener noreferrer">${title}</a>`
      : title;
    return `<div class="feed-item feed-item-article">`
      + `<div class="ff-title">${titleNode}</div>`
      + (summary ? `<div class="ff-summary">${summary}</div>` : '')
      + `<div class="ff-meta"><span class="ff-source">${source}</span>${when ? `<span>· ${escapeHtml(when)}</span>` : ''}</div>`
      + `</div>`;
  }).join('');
}

function loadProxyTemplateInput() {
  const el = document.getElementById('feed-proxy-tmpl');
  if (el) el.value = getProxyTemplate();
}

function onProxySave() {
  const el = document.getElementById('feed-proxy-tmpl');
  const v = setProxyTemplate(el?.value || '');
  if (el) el.value = v;
  const status = document.getElementById('feed-proxy-status');
  if (status) status.textContent = 'Saved.';
}

function onProxyReset() {
  setProxyTemplate(DEFAULT_PROXY_TEMPLATE);
  loadProxyTemplateInput();
  const status = document.getElementById('feed-proxy-status');
  if (status) status.textContent = 'Restored to default.';
}

async function onProxyTest() {
  const status = document.getElementById('feed-proxy-status');
  const el = document.getElementById('feed-proxy-tmpl');
  const tmpl = (el?.value || '').trim();
  // Probe against the user's own first adopted feed when possible. This makes
  // the test reflect reality (proxy reaching the URLs they actually care about)
  // instead of a canned upstream that might be slow for unrelated reasons.
  let probeUrl;
  try {
    const me = getPublicKeyHex();
    const all = await listFeeds();
    const mine = all.filter((e) => (e.adopters || []).includes(me));
    if (mine.length) probeUrl = mine[0].feed_url;
  } catch (_) { /* fall back to canned probe */ }
  if (status) status.textContent = `Testing… (probe: ${probeUrl ? 'your feed' : 'hnrss.org'})`;
  const result = await testProxy(tmpl || undefined, probeUrl);
  if (!status) return;
  const took = result.tookMs != null ? `${result.tookMs} ms` : '';
  const probeLabel = result.probe ? ` via ${escapeHtml(new URL(result.probe).host)}` : '';
  if (result.ok) {
    status.textContent = `✓ ${result.host} OK${probeLabel} — ${result.itemCount} items, ${took}`;
  } else {
    status.textContent = `✗ ${result.host} failed${probeLabel} after ${took}: ${result.error}`;
  }
}

function setActiveView(view) {
  const v = view === 'feeds' ? 'feeds' : 'chat';
  document.querySelectorAll('.view-toggle [data-view]').forEach((b) => {
    const on = b.getAttribute('data-view') === v;
    b.classList.toggle('on', on);
    b.setAttribute('aria-selected', on ? 'true' : 'false');
  });
  document.querySelectorAll('main > section[data-view]').forEach((s) => {
    s.hidden = s.getAttribute('data-view') !== v;
  });
  if (v === 'feeds') {
    refreshFeedsView().catch((e) => console.warn('feeds:', e));
    // Render whatever items we already have from this session; only fetch on user click.
    renderFeedItems();
  }
}

async function refreshFeedsView() {
  const list = document.getElementById('feed-list');
  const count = document.getElementById('feed-count');
  if (!list) return;
  const all = await listFeeds();
  const filters = await getFeedFilters();
  const visible = applyFeedFilters(all, filters);
  if (count) count.textContent = visible.length ? `· ${visible.length}` : '';
  if (!visible.length) {
    list.innerHTML = '<div class="feed-empty">No feeds match your filters yet. Submit one above, or adjust the focus / exclude terms.</div>';
    return;
  }
  const me = getPublicKeyHex();
  list.innerHTML = visible.map((e) => {
    const title = escapeHtml(e.title || e.feed_url || '(untitled feed)');
    const url = escapeHtml(e.feed_url || '');
    const adopters = (e.adopters || []).length;
    const adopted = (e.adopters || []).includes(me);
    const isMine = e.addedByHex === me;
    const byRec = memberByHex.get(e.addedByHex);
    const byName = byRec?.displayName || (e.addedByHex ? `${e.addedByHex.slice(0, 8)}…` : '?');
    const when = e.addedAt ? new Date(e.addedAt * 1000).toLocaleDateString() : '';
    const meta = `by ${escapeHtml(byName)}${when ? ' · ' + escapeHtml(when) : ''} · ${adopters} adopter${adopters === 1 ? '' : 's'}`;
    const actions = adopted
      ? '<span class="ff-adopted">adopted ✓</span>'
      : `<button type="button" class="primary" data-feed-adopt="${escapeHtml(e.id)}">Adopt</button>`;
    const remove = isMine ? `<button type="button" data-feed-remove="${escapeHtml(e.id)}">Remove</button>` : '';
    return `<div class="feed-item"><div><div class="ff-title">${title}</div><div class="ff-url"><a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a></div><div class="ff-meta">${meta}</div></div><div class="ff-actions">${actions}${remove}</div></div>`;
  }).join('');
}

async function loadFeedFilterInputs() {
  const f = await getFeedFilters();
  const focusEl = document.getElementById('feed-focus');
  const excludeEl = document.getElementById('feed-exclude');
  if (focusEl) focusEl.value = (f.focus || []).join(', ');
  if (excludeEl) excludeEl.value = (f.exclude || []).join(', ');
}

function parseTermInput(s) {
  return String(s || '').split(/[,\n]+/).map((t) => t.trim()).filter(Boolean);
}

async function saveFeedFilters() {
  const focusEl = document.getElementById('feed-focus');
  const excludeEl = document.getElementById('feed-exclude');
  await setFeedFilters({
    focus: parseTermInput(focusEl?.value),
    exclude: parseTermInput(excludeEl?.value),
  });
  const status = document.getElementById('feed-filter-status');
  if (status) status.textContent = 'Saved on this device.';
  await refreshFeedsView();
  renderFeedItems();
}

function setFeedAddMessage(text, kind) {
  const el = document.getElementById('feed-add-msg');
  if (!el) return;
  el.textContent = text || '';
  el.className = 'feed-msg' + (kind ? ' ' + kind : '');
}

async function onSubmitFeed() {
  const urlEl = document.getElementById('feed-url');
  const titleEl = document.getElementById('feed-title');
  const url = (urlEl?.value || '').trim();
  const title = (titleEl?.value || '').trim();
  if (!url) { setFeedAddMessage('Enter a feed URL.', 'err'); return; }
  setFeedAddMessage('Submitting…', '');
  try {
    await submitFeed({ url, title });
    if (urlEl) urlEl.value = '';
    if (titleEl) titleEl.value = '';
    setFeedAddMessage('Added to family registry.', 'ok');
    await refreshFeedsView();
  } catch (e) {
    setFeedAddMessage('Submit failed: ' + (e.message || 'error'), 'err');
  }
}

async function onAdoptFeed(id) {
  try {
    await adoptFeed(id);
    await refreshFeedsView();
    refreshFeedItems({ force: true }).catch(() => {});
  } catch (e) {
    setFeedAddMessage('Adopt failed: ' + (e.message || 'error'), 'err');
  }
}

async function onRemoveFeed(id) {
  if (!confirm('Remove this feed from the family registry? Other members will see it disappear.')) return;
  try {
    const ok = await removeFeed(id);
    if (!ok) setFeedAddMessage('Only the original submitter can remove an entry.', 'err');
    await refreshFeedsView();
  } catch (e) {
    setFeedAddMessage('Remove failed: ' + (e.message || 'error'), 'err');
  }
}

async function onIncomingChat(env) {
  // A new envelope addressed to us was just stored. If the user is currently
  // viewing that thread, re-render so it shows up immediately.
  const me = getPublicKeyHex();
  if (!active.kind) return;
  let activeThreadId;
  if (active.kind === 'group') activeThreadId = active.target && active.target.id;
  else activeThreadId = dmThreadId(me, active.target);
  if (env.threadId === activeThreadId) {
    try { await openThread(active.kind, active.target); } catch (_) {}
  }
}

async function renderIdentityLine() {
  const me = getPublicKeyHex();
  const rec = await Store.get(STORE_NAMES.members, me);
  const name = rec?.displayName || 'You';
  const mode = getMode();
  const isDemo = (await getGraphMode()) === GraphMode.DEMO;
  const el = $('identity-line');
  el.innerHTML = '';
  const nameSpan = document.createElement('span');
  nameSpan.textContent = name;
  nameSpan.style.color = 'var(--accent)';
  nameSpan.style.cursor = 'pointer';
  nameSpan.title = 'Click to rename yourself';
  nameSpan.onclick = async () => {
    const v = promptRename(name, 'Your display name');
    if (v === null) return;
    await setMemberDisplayName(me, v || (isDemo ? 'You (demo)' : 'You'));
    await renderIdentityLine();
    await refreshSidebar();
    if (active.kind) await openThread(active.kind, active.target);
    toast('Name updated');
  };
  const meta = document.createElement('span');
  meta.style.color = 'var(--muted)';
  meta.textContent = `  · key ${me.slice(0, 8)}… · ${mode}${isDemo ? ' · demo' : ''}`;
  el.appendChild(nameSpan);
  el.appendChild(meta);
}

async function refreshSidebar() {
  cachedMembers = await Store.getAll(STORE_NAMES.members);
  memberByHex = new Map(cachedMembers.map((m) => [m.pubkeyHex, m]));
  const groups = await listGroups();
  const me = getPublicKeyHex();
  // Threads = groups + DM-with-each-known-other-member
  const threadsEl = $('threads');
  threadsEl.innerHTML = '';
  groups.forEach((g) => {
    const li = document.createElement('li');
    li.textContent = g.name;
    const tag = document.createElement('span'); tag.className = 'badge'; tag.textContent = `${g.members.length} members`;
    li.appendChild(tag);
    li.onclick = () => openThread('group', g);
    threadsEl.appendChild(li);
  });
  const otherMembers = cachedMembers.filter((m) => m.pubkeyHex !== me);
  otherMembers.forEach((m) => {
    const li = document.createElement('li');
    li.textContent = `DM · ${m.displayName || m.pubkeyHex.slice(0, 8)}`;
    const tag = document.createElement('span'); tag.className = `badge ${batTierForDegree(m.degree)}`;
    tag.textContent = batTierForDegree(m.degree);
    li.appendChild(tag);
    li.onclick = () => openThread('dm', m.pubkeyHex);
    threadsEl.appendChild(li);
  });

  const membersEl = $('members');
  membersEl.innerHTML = '';
  cachedMembers.forEach((m) => {
    const li = document.createElement('li');
    const label = document.createElement('span');
    label.textContent = `${m.displayName || m.pubkeyHex.slice(0, 8)} — ${relTypeLabel(m.rel_type) || 'self'}`;
    label.title = 'Click to rename';
    label.style.cursor = 'pointer';
    label.onclick = async (e) => {
      e.stopPropagation();
      const v = promptRename(m.displayName, m.pubkeyHex === me ? 'Your display name' : 'Member display name');
      if (v === null) return;
      const fallback = m.pubkeyHex === me
        ? ((await getGraphMode()) === GraphMode.DEMO ? 'You (demo)' : 'You')
        : null;
      await setMemberDisplayName(m.pubkeyHex, v || fallback);
      await renderIdentityLine();
      await refreshSidebar();
      if (active.kind) await openThread(active.kind, active.target);
      toast('Name updated');
    };
    li.appendChild(label);
    const tag = document.createElement('span'); tag.className = `badge ${batTierForDegree(m.degree)}`;
    tag.textContent = `d${m.degree}`;
    li.appendChild(tag);
    membersEl.appendChild(li);
  });
}

function senderLabel(hex, meHex) {
  const rec = memberByHex.get(hex);
  if (rec?.displayName) return rec.displayName;
  if (hex === meHex) return 'You';
  return `${hex.slice(0, 8)}…`;
}

async function openThread(kind, target) {
  active = { kind, target };
  const me = getPublicKeyHex();
  const threadId = kind === 'group' ? target.id : dmThreadId(me, target);
  const all = await listMessages(threadId);
  all.sort((a, b) => a.ts - b.ts);
  const el = $('messages'); el.innerHTML = '';
  for (const m of all) {
    let text = '(unable to decrypt)';
    try {
      text = await decryptMessage(m, kind === 'group' ? { threadKind: 'group', group: target } : { threadKind: 'dm', peerHex: target });
    } catch (e) { /* ignore */ }
    const div = document.createElement('div');
    div.className = 'msg' + (m.senderHex === me ? ' me' : '');
    const who = senderLabel(m.senderHex, me);
    div.innerHTML = `<div>${escapeHtml(text)}</div><div class="meta" title="${m.senderHex}">${escapeHtml(who)} · ${new Date(m.ts).toLocaleTimeString()}</div>`;
    el.appendChild(div);
  }
  el.scrollTop = el.scrollHeight;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

function wireUi() {
  // Composer
  $('composer').onsubmit = async (e) => {
    e.preventDefault();
    const text = $('msg-input').value.trim();
    if (!text) return;
    if (!active.kind) {
      toast('Pick a thread or DM from the left first, then send.');
      return;
    }
    try {
      await sendMessage({
        threadKind: active.kind,
        target: active.target,
        text,
      });
      $('msg-input').value = '';
      await openThread(active.kind, active.target);
    } catch (err) { toast(err.message); }
  };

  // Group modal
  const grpModal = $('grp-modal');
  let currentFilter = new RelationshipFilter();
  $('btn-create-group').onclick = () => {
    grpModal.classList.add('open');
    currentFilter = renderFilterInto($('grp-filter'), { initial: new RelationshipFilter(), onChange: refreshCandidates });
    refreshCandidates(currentFilter);
  };
  $('grp-cancel').onclick = () => grpModal.classList.remove('open');
  $('grp-create').onclick = async () => {
    const name = $('grp-name').value.trim();
    const checked = [...document.querySelectorAll('#grp-candidates input[type="checkbox"]:checked')]
      .map((cb) => cb.dataset.pubkey);
    const candidates = cachedMembers
      .filter((m) => checked.includes(m.pubkeyHex))
      .map((m) => ({ pubkeyHex: m.pubkeyHex, n_index: m.n_index, rel_type: m.rel_type, degree: m.degree }));
    try {
      await createGroup({ name, filter: currentFilter, candidates });
      grpModal.classList.remove('open');
      await refreshSidebar();
      toast('Group created');
    } catch (e) { toast(e.message); }
  };

  function refreshCandidates(filter) {
    currentFilter = filter;
    const wrap = $('grp-candidates'); wrap.innerHTML = '';
    const filtered = filter.filterMembers(cachedMembers.filter((m) => m.pubkeyHex !== getPublicKeyHex()));
    if (filtered.length === 0) {
      wrap.innerHTML = '<small style="color:var(--muted)">No members match this filter yet. Add some via QR.</small>';
      return;
    }
    filtered.forEach((m) => {
      const row = document.createElement('label');
      row.className = 'member';
      const cb = document.createElement('input');
      cb.type = 'checkbox'; cb.dataset.pubkey = m.pubkeyHex;
      const span = document.createElement('span');
      span.textContent = `${m.displayName || m.pubkeyHex.slice(0, 8)} — ${relTypeLabel(m.rel_type)} (d${m.degree})`;
      row.appendChild(cb); row.appendChild(span);
      wrap.appendChild(row);
    });
  }

  // Invite + Join buttons
  $('btn-show-qr').onclick = () => openInviteModal();
  $('btn-scan-qr').onclick = () => openJoinModal({});

  // Invite modal wiring
  const invModal = $('invite-modal');
  $('inv-close').onclick = () => invModal.classList.remove('open');
  $('inv-generate').onclick = onGenerateInvite;
  $('inv-revoke').onclick = onRevokeInvite;
  $('inv-copy-pin').onclick = () => copyToClipboard($('inv-pin').textContent);
  $('inv-copy-link').onclick = () => copyToClipboard($('inv-payload').value);

  // Join modal wiring
  const joinModal = $('join-modal');
  $('join-cancel').onclick = () => joinModal.classList.remove('open');
  $('join-submit').onclick = onJoinSubmit;

  // Approval modal wiring
  const apModal = $('approval-modal');
  $('approval-decline').onclick = () => onApproval(false);
  $('approval-approve').onclick = () => onApproval(true);

  // View toggle (Chat / Feeds)
  document.querySelectorAll('.view-toggle [data-view]').forEach((b) => {
    b.addEventListener('click', () => setActiveView(b.getAttribute('data-view')));
  });

  // Feeds wiring
  $('feed-submit')?.addEventListener('click', onSubmitFeed);
  $('feed-refresh')?.addEventListener('click', () => refreshFeedsView().catch(() => {}));
  $('feed-list')?.addEventListener('click', (ev) => {
    const a = ev.target.closest('[data-feed-adopt]');
    if (a) { onAdoptFeed(a.getAttribute('data-feed-adopt')); return; }
    const r = ev.target.closest('[data-feed-remove]');
    if (r) onRemoveFeed(r.getAttribute('data-feed-remove'));
  });
  const onTermsInput = () => {
    if (_feedFilterTimer) clearTimeout(_feedFilterTimer);
    _feedFilterTimer = setTimeout(() => { saveFeedFilters().catch(() => {}); }, 350);
  };
  $('feed-focus')?.addEventListener('input', onTermsInput);
  $('feed-exclude')?.addEventListener('input', onTermsInput);
  loadFeedFilterInputs().catch(() => {});

  // Items panel + Settings
  $('feed-items-refresh')?.addEventListener('click', () => refreshFeedItems({ force: true }).catch(() => {}));
  $('feed-proxy-save')?.addEventListener('click', onProxySave);
  $('feed-proxy-reset')?.addEventListener('click', onProxyReset);
  $('feed-proxy-test')?.addEventListener('click', () => onProxyTest().catch(() => {}));
  loadProxyTemplateInput();

  // Retire demo -> create real graph
  const startBtn = $('btn-start-real');
  if (startBtn) {
    startBtn.onclick = async () => {
      const ok = confirm(
        'This erases the demo family graph (members, groups, messages) and mints your real Ed25519 identity.\n\n' +
        'Only one family graph can exist on this device. Continue?'
      );
      if (!ok) return;
      try {
        await retireDemo();
        await ensureIdentity();
        await markLiveMode();
        location.reload();
      } catch (e) {
        toast(`Failed to start real graph: ${e.message}`);
      }
    };
  }
}

async function handleScannedPayload(s) {
  const p = decodePayload(s);
  const v = validatePayload(p);
  if (!v.ok) throw new Error(v.error);
  await Store.put(STORE_NAMES.members, {
    pubkeyHex: p.pubkey,
    n_index: v.n_index,
    rel_type: p.rel_type,
    degree: p.degree_band,
    displayName: null,
    addedAt: Date.now(),
  });
  await refreshSidebar();
  toast('Member bound from URL');
}

// =====================================================================
//  Invite (inviter side)
// =====================================================================

let _activeInviteId = null;

function populateInviteSelectors() {
  const rel = $('inv-rel');
  const deg = $('inv-deg');
  if (!rel.options.length) {
    rel.innerHTML = REL_TYPE_LIST.map((rt) => `<option value="${rt.id}">${rt.label}</option>`).join('');
  }
  if (!deg.options.length) {
    deg.innerHTML = [1,2,3,4,5,6].map((d) => {
      const tier = d <= 2 ? 'hot — instant' : d <= 4 ? 'warm — 1 vouch' : 'cold — 2 vouches';
      return `<option value="${d}" ${d===2?'selected':''}>${d} (${tier})</option>`;
    }).join('');
  }
}

function openInviteModal() {
  const m = $('invite-modal');
  populateInviteSelectors();
  $('inv-result').hidden = true;
  $('inv-revoke').hidden = true;
  $('inv-status').textContent = 'waiting…';
  $('inv-status').className = 'badge';
  $('inv-attempts').textContent = 'attempts: 0';
  $('inv-pin').textContent = '—';
  $('inv-payload').value = '';
  $('inv-qr-wrap').innerHTML = '';
  _activeInviteId = null;
  m.classList.add('open');
}

async function onGenerateInvite() {
  try {
    const rel = parseInt($('inv-rel').value, 10);
    const deg = parseInt($('inv-deg').value, 10);
    const me = getPublicKeyHex();
    const selfRec = await Store.get(STORE_NAMES.members, me);
    const inv = await createInvite({ rel_type: rel, degree_band: deg, inviter_pubkey: me });
    _activeInviteId = inv.invite_id;

    // Publish the public commitment (NO PIN) on Nostr.
    await emit(INVITE.PUBLISHED, {
      invite_id: inv.invite_id,
      commitment: inv.commitment,
      salt: inv.salt,
      rel_type: inv.rel_type,
      degree_band: inv.degree_band,
      ttl: inv.expires_at - inv.created_at,
      inviter_name: selfRec?.displayName || null,
    }, [['e', inv.invite_id], ['t', 'invite'], ['d', String(inv.degree_band)]], { broadcast: true });

    // Build QR payload (v:2)
    const qrPayload = buildInvitePayload({
      invite_id: inv.invite_id,
      inviter_pubkey: me,
      commitment: inv.commitment,
      salt: inv.salt,
      rel_type: inv.rel_type,
      degree_band: inv.degree_band,
      ttl: inv.expires_at - inv.created_at,
      relays: getRelayUrls(),
      inviter_name: selfRec?.displayName || null,
    });
    const enc = encodePayload(qrPayload);
    const url = `${location.href.split('#')[0]}#${enc}`;
    $('inv-pin').textContent = inv.pin;
    $('inv-payload').value = enc;
    try {
      const matrix = makeQRMatrix(url, 'M');
      $('inv-qr-wrap').innerHTML = renderQRSvg(matrix, { scale: 5, margin: 4, dark: '#0b0d12', light: '#ffffff' });
    } catch (e) {
      $('inv-qr-wrap').innerHTML = `<small style="color:var(--err)">QR error: ${escapeHtml(e.message)}</small>`;
    }
    $('inv-result').hidden = false;
    $('inv-revoke').hidden = false;
    $('inv-status').textContent = 'awaiting joiner…';
    $('inv-status').className = 'badge status-pending';
    toast('Invite ready. Share the QR widely; share the PIN privately.');
  } catch (e) {
    toast(`Could not create invite: ${e.message}`);
  }
}

async function onRevokeInvite() {
  if (!_activeInviteId) return;
  if (!confirm('Revoke this invite? It will stop accepting attempts.')) return;
  await revokeInvite(_activeInviteId, 'manual');
  await emit(INVITE.REVOKED, { invite_id: _activeInviteId, reason: 'manual' },
    [['e', _activeInviteId]], { broadcast: true });
  $('inv-status').textContent = 'revoked';
  $('inv-status').className = 'badge status-err';
  $('inv-revoke').hidden = true;
  toast('Invite revoked');
}

async function refreshInviteAttemptCounter(invite_id) {
  if (_activeInviteId !== invite_id) return;
  const inv = await getInvite(invite_id);
  if (!inv) return;
  $('inv-attempts').textContent = `attempts: ${inv.total_attempts}/10`;
  if (inv.consumed) {
    $('inv-status').textContent = 'connected ✓';
    $('inv-status').className = 'badge status-ok';
  } else if (inv.revoked) {
    $('inv-status').textContent = 'revoked';
    $('inv-status').className = 'badge status-err';
  }
}

// =====================================================================
//  Join (joiner side)
// =====================================================================

let _pendingJoin = null;
let _joinSubId = null;

function openJoinModal({ prefillPayload }) {
  const m = $('join-modal');
  $('join-payload').value = prefillPayload || '';
  $('join-pin').value = '';
  $('join-rel').innerHTML = REL_TYPE_LIST.map((rt) => `<option value="${rt.id}">${rt.label}</option>`).join('');
  $('join-deg').innerHTML = [1,2,3,4,5,6].map((d) => `<option value="${d}" ${d===2?'selected':''}>${d}</option>`).join('');
  $('join-status').textContent = '';
  $('join-status').className = '';
  m.classList.add('open');
}

async function onJoinSubmit() {
  const statusEl = $('join-status');
  try {
    let raw = $('join-payload').value.trim();
    const idx = raw.indexOf('#janet2:');
    if (idx >= 0) raw = raw.slice(idx + 1);
    if (raw.startsWith('#')) raw = raw.slice(1);
    const payload = decodePayload(raw);
    const v = validateInvitePayload(payload);
    if (!v.ok) throw new Error('invalid invite: ' + v.error);

    const pin = normalizePin($('join-pin').value);
    if (pin.length !== PIN_LEN) throw new Error(`PIN must be ${PIN_LEN} characters`);

    const rel = parseInt($('join-rel').value, 10);
    const deg = parseInt($('join-deg').value, 10);

    // Local fast-fail: recompute commitment with our PIN guess and the user's claimed (rel, deg).
    const proof = await computeJoinerProof({
      pin, invite_id: payload.invite_id, salt: payload.salt,
      rel_type: rel, degree_band: deg,
    });
    if (proof !== payload.commitment) {
      statusEl.textContent = 'PIN or relationship does not match. Double-check both before retrying — the inviter only allows 3 wrong attempts.';
      statusEl.className = 'status-err';
      return;
    }

    statusEl.textContent = 'PIN checks out locally. Sending request to the inviter for approval…';
    statusEl.className = 'status-pending';

    _pendingJoin = { payload, proof, rel, deg, pin };

    // Subscribe to inviter's ack/revoke for this invite_id.
    if (_joinSubId) unsubscribeRelays(_joinSubId);
    _joinSubId = `join-${payload.invite_id.slice(0, 8)}`;
    subscribeRelays(_joinSubId, [{
      kinds: [INVITE.COMPLETED, INVITE.REVOKED],
      authors: [payload.inviter_pubkey],
      '#e': [payload.invite_id],
      since: Math.floor(Date.now() / 1000) - 5,
    }], (evt) => handleInviterResponse(evt));

    // Publish attempt event.
    await emit(INVITE.ATTEMPT, {
      invite_id: payload.invite_id,
      rel_type: rel,
      degree_band: deg,
      proof_hex: proof,
      joiner_nonce: cryptoNonce(),
    }, [['e', payload.invite_id], ['p', payload.inviter_pubkey], ['t', 'invite']], { broadcast: true });
  } catch (e) {
    statusEl.textContent = e.message;
    statusEl.className = 'status-err';
  }
}

function cryptoNonce() {
  const b = new Uint8Array(8); crypto.getRandomValues(b);
  return Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
}

async function handleInviterResponse(evt) {
  if (!_pendingJoin) return;
  let body;
  try { body = JSON.parse(evt.content); } catch (_) { return; }
  if (body.invite_id !== _pendingJoin.payload.invite_id) return;

  const statusEl = $('join-status');
  const m = $('join-modal');

  if (evt.kind === INVITE.COMPLETED) {
    // Bind inviter into our local member graph.
    const p = _pendingJoin.payload;
    await Store.put(STORE_NAMES.members, {
      pubkeyHex: p.inviter_pubkey,
      n_index: nIndexFor(_pendingJoin.deg, _pendingJoin.rel),
      rel_type: _pendingJoin.rel,
      degree: _pendingJoin.deg,
      displayName: p.inviter_name || null,
      addedAt: Date.now(),
      via_invite: p.invite_id,
    });
    statusEl.textContent = 'Connected! The inviter approved your request.';
    statusEl.className = 'status-ok';
    await refreshSidebar();
    setTimeout(() => m.classList.remove('open'), 1200);
    if (_joinSubId) { unsubscribeRelays(_joinSubId); _joinSubId = null; }
    _pendingJoin = null;
    toast('Connected to the family graph');
  } else if (evt.kind === INVITE.REVOKED) {
    statusEl.textContent = `Connection refused: ${body.reason || 'revoked'}`;
    statusEl.className = 'status-err';
    if (_joinSubId) { unsubscribeRelays(_joinSubId); _joinSubId = null; }
    _pendingJoin = null;
  }
}

// =====================================================================
//  Inviter listener: receive incoming attempts, gate them, prompt approval
// =====================================================================

const _seenAttempts = new Set();
let _pendingApproval = null;

async function startInviterListener() {
  const me = getPublicKeyHex();
  if (!me) return;
  const subId = `inviter-${me.slice(0, 8)}`;
  subscribeRelays(subId, [{
    kinds: [INVITE.ATTEMPT],
    '#p': [me],
    since: Math.floor(Date.now() / 1000) - 60,
  }], (evt) => onInviteAttempt(evt));
}

async function onInviteAttempt(evt) {
  if (_seenAttempts.has(evt.id)) return;
  _seenAttempts.add(evt.id);
  let body;
  try { body = JSON.parse(evt.content); } catch (_) { return; }

  const inviteId = body.invite_id;
  const inv = await getInvite(inviteId);
  if (!inv) return; // not our invite

  // Tally first (this enforces 3-strikes / global cap independently of correctness).
  const tally = await tallyAttempt(inviteId, evt.pubkey);
  if (!tally.allowed) {
    await emit(INVITE.REVOKED, { invite_id: inviteId, reason: tally.reason },
      [['e', inviteId], ['p', evt.pubkey]], { broadcast: true });
    await refreshInviteAttemptCounter(inviteId);
    return;
  }

  // Verify the proof (PIN+rel+degree).
  const verdict = await verifyAttempt(inviteId, {
    rel_type: body.rel_type,
    degree_band: body.degree_band,
    proof_hex: body.proof_hex,
  });
  await refreshInviteAttemptCounter(inviteId);
  if (!verdict.match) {
    // wrong PIN/rel/deg — silent: don't reveal which factor was wrong
    if (tally.remaining_for_joiner === 0) {
      await emit(INVITE.REVOKED, { invite_id: inviteId, reason: 'attempts_exceeded' },
        [['e', inviteId], ['p', evt.pubkey]], { broadcast: true });
    }
    return;
  }

  // Local invite is good. Ask the human.
  _pendingApproval = { invite: inv, evt, body };
  showApprovalModal(inv, evt, body);
}

function showApprovalModal(inv, evt, body) {
  const el = $('approval-body');
  el.innerHTML = `
    <p style="margin:6px 0">A device wants to join your family graph as your
      <b>${escapeHtml(relTypeLabel(body.rel_type))}</b> at <b>degree ${body.degree_band}</b>.</p>
    <ul style="font-size:12px;color:var(--muted);padding-left:18px">
      <li>Joiner pubkey: <code>${evt.pubkey.slice(0,16)}…</code></li>
      <li>PIN ✓ verified locally (the wire never carried it)</li>
      <li>Relationship ✓ matches your invite expectation</li>
      <li>Attempts so far: ${inv.total_attempts}/10</li>
    </ul>
    <p style="font-size:12px;color:var(--warm)">Approve only if you actually shared the PIN with this person and the relationship matches.</p>
  `;
  $('approval-modal').classList.add('open');
}

async function onApproval(approved) {
  const m = $('approval-modal');
  m.classList.remove('open');
  if (!_pendingApproval) return;
  const { invite, evt, body } = _pendingApproval;
  _pendingApproval = null;
  try {
    if (approved) {
      const n_idx = nIndexFor(body.degree_band, body.rel_type);
      await consumeInvite(invite.invite_id, { joiner_pubkey: evt.pubkey, n_index: n_idx });
      await Store.put(STORE_NAMES.members, {
        pubkeyHex: evt.pubkey,
        n_index: n_idx,
        rel_type: body.rel_type,
        degree: body.degree_band,
        displayName: null,
        addedAt: Date.now(),
        via_invite: invite.invite_id,
      });
      await emit(INVITE.COMPLETED, {
        invite_id: invite.invite_id,
        joiner_pubkey: evt.pubkey,
        rel_type: body.rel_type,
        degree_band: body.degree_band,
        n_index: n_idx,
      }, [['e', invite.invite_id], ['p', evt.pubkey]], { broadcast: true });
      await refreshSidebar();
      await refreshInviteAttemptCounter(invite.invite_id);
      toast('Approved — member added to your family graph.');
    } else {
      await revokeInvite(invite.invite_id, 'declined');
      await emit(INVITE.REVOKED, { invite_id: invite.invite_id, reason: 'declined' },
        [['e', invite.invite_id], ['p', evt.pubkey]], { broadcast: true });
      await refreshInviteAttemptCounter(invite.invite_id);
      toast('Declined');
    }
  } catch (e) {
    toast('Approval failed: ' + e.message);
  }
}

function copyToClipboard(s) {
  navigator.clipboard?.writeText(s).then(() => toast('Copied'), () => toast('Copy failed'));
}

window.JanetApp = { Janet, validateMember, nIndexFor, verifyTriadic };

boot();
