/* JANET Family Chat — Service Worker
 * Offline-first cache for the lattice/taxonomy/UI shell + background sync queue
 * for kinds 38010..38013 audit events.
 */
const VERSION = 'janet-fc-v1.4.5';
const CORE_CACHE = `${VERSION}-core`;
const RUNTIME_CACHE = `${VERSION}-runtime`;

const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './styles.css',
  './app.js',
  './src/crypto/ed25519-manager.js',
  './src/lattice/janet-lattice.js',
  './src/family/family-taxonomy.js',
  './src/family/family-graph.js',
  './src/chat/chat-engine.js',
  './src/chat/relationship-filter.js',
  './src/domains/domain-overlays.js',
  './src/sync/nostr-audit.js',
  './src/recovery/recovery-engine.js',
  './src/storage/indexeddb-store.js',
  './src/qr/qr-onboard.js',
  './src/qr/qr-encoder.js',
  './src/demo/demo-seed.js',
  './src/invite/invite-engine.js',
  './src/sync/nostr-relay.js',
  './src/feeds/feed-registry.js',
  './src/feeds/feed-fetcher.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CORE_CACHE);
    // Use individual adds so a single 404 does not nuke install.
    await Promise.all(CORE_ASSETS.map(async (u) => {
      try { await cache.add(new Request(u, { cache: 'reload' })); } catch (_) { /* ignore */ }
    }));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // API auth challenge/verify endpoints: network-first, no cache (challenges are nonced).
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(fetch(req).catch(() => new Response(JSON.stringify({
      error: 'offline',
      hint: 'JANET auth requires online relay; queued for background sync.'
    }), { status: 503, headers: { 'Content-Type': 'application/json' } })));
    return;
  }

  // Same-origin static: cache-first w/ runtime fallback.
  if (url.origin === self.location.origin) {
    event.respondWith((async () => {
      const cached = await caches.match(req);
      if (cached) return cached;
      try {
        const res = await fetch(req);
        if (res.ok) {
          const clone = res.clone();
          const cache = await caches.open(RUNTIME_CACHE);
          cache.put(req, clone);
        }
        return res;
      } catch (_) {
        return caches.match('./index.html');
      }
    })());
  }
});

// Background sync for queued audit events (kinds 38010..38013).
self.addEventListener('sync', (event) => {
  if (event.tag === 'janet-audit-flush') {
    event.waitUntil((async () => {
      const clients = await self.clients.matchAll({ includeUncontrolled: true });
      clients.forEach((c) => c.postMessage({ type: 'AUDIT_FLUSH_REQUESTED' }));
    })());
  }
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});
