#!/usr/bin/env python3
"""Write zone map, static UI bundle, and ledger JSONL from a manifest (CI / local)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", type=Path, default=_ROOT / "TEST_MANIFEST.json")
    ap.add_argument("--out-dir", type=Path, default=_ROOT / "artifacts")
    args = ap.parse_args()

    src = str(_ROOT / "src")
    if src not in sys.path:
        sys.path.insert(0, src)

    from janet_ledger.export_bundle import (  # noqa: PLC0415
        ledger_golden_vectors_to_jsonl_lines,
        static_ui_bundle_dict,
        zone_map_export_dict,
    )
    from janet_ledger.policy_config import policy_config_from_manifest  # noqa: PLC0415

    manifest: dict = json.loads(args.manifest.read_text(encoding="utf-8"))
    pc = policy_config_from_manifest(manifest)
    tie = pc.zone_tie_break_coord

    args.out_dir.mkdir(parents=True, exist_ok=True)
    zm = zone_map_export_dict(tie_coord=tie)
    (args.out_dir / "zone_map.json").write_text(
        json.dumps(zm, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    bundle = static_ui_bundle_dict(manifest, tie_coord=tie)
    (args.out_dir / "static_ui_bundle.json").write_text(
        json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    lines = ledger_golden_vectors_to_jsonl_lines(manifest)
    (args.out_dir / "ledger_golden_vectors.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
