#!/usr/bin/env python3
"""Emit policy / export BOM for compliance (stdout + optional file). CI calls this with no args."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
_DOCS = _REPO_ROOT / "docs"


def _policy_codes_from_docs() -> list[str]:
    codes: set[str] = set()
    if not _DOCS.is_dir():
        return []
    for name in (
        "EVIDENCE_TRIAD.md",
        "HITL_KNOWLEDGE.md",
        "DEVICE_TRUST_MODEL.md",
        "NOSTR_JANET_POLICY.md",
        "DEMO_IDENTITY.md",
        "DEMO_IDENTITY_LIVE.md",
        "DESKTOP_PWA_SPLIT.md",
        "GAP_REWARD_BADGE.md",
        "NIP29_VALIDATORS.md",
        "BRIDGE_GAP_REWARD.md",
        "NATIVE_INTEGRATION_GUIDE.md",
    ):
        path = _DOCS / name
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        for m in re.finditer(r"`([A-Z][A-Z0-9_-]+-\d{3})`", text):
            codes.add(m.group(1))
    return sorted(codes)


def _export_names() -> list[str]:
    sys.path.insert(0, str(_REPO_ROOT / "src"))
    import janet_ledger as jl  # noqa: PLC0415

    return sorted(jl.__all__)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--output", type=Path, default=None, help="Write BOM text here")
    args = ap.parse_args()
    lines = [
        "# janet-ledger policy / export BOM (generated)",
        "",
        "## __all__",
        *[f"- `{n}`" for n in _export_names()],
        "",
        "## Policy-like codes (from docs/*.md policy scans)",
        *[f"- `{c}`" for c in _policy_codes_from_docs()],
        "",
    ]
    text = "\n".join(lines) + "\n"
    sys.stdout.write(text)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
