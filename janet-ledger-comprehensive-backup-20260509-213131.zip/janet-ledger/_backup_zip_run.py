"""One-off runner: comprehensive zip of repo (invoke from shell, then delete if desired)."""
from __future__ import annotations

import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAMP = datetime.now().strftime("%Y%m%d-%H%M%S")
OUT = ROOT.parent / f"janet-ledger-comprehensive-backup-{STAMP}.zip"

SKIP_DIR_NAMES = frozenset({
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "htmlcov",
    ".tox",
    ".eggs",
    ".venv",
    "venv",
    "node_modules",
    ".hypothesis",
})
SKIP_SUFFIXES = frozenset({".pyc", ".pyo"})


def skip_path(rel: Path) -> bool:
    parts = rel.parts
    if any(p in SKIP_DIR_NAMES for p in parts):
        return True
    if rel.suffix.lower() in SKIP_SUFFIXES:
        return True
    name = rel.name
    if name == ".coverage":
        return True
    if name.endswith(".egg-info"):
        return True
    return False


def main() -> None:
    count = 0
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for p in ROOT.rglob("*"):
            if not p.is_file():
                continue
            rel = p.relative_to(ROOT)
            if skip_path(rel):
                continue
            arc = Path(ROOT.name) / rel
            zf.write(p, arc.as_posix())
            count += 1
    print(str(OUT))
    print("files_archived:", count)
    print("zip_bytes:", OUT.stat().st_size)


if __name__ == "__main__":
    main()
