# Escalation & clearance (template)

## Escalation

1. Trigger: automated gate failure **or** conflicting `pattern_observation` rows for same `mapping_key_sha256`.
2. Freeze session: stop δ-stepping; snapshot `prev_hash` tip.
3. Assign senior validator; attach manifest `policy_config` version in effect.

## Clearance

- [ ] Root cause tied to explicit policy id (e.g. `CONV-ADJ-001`, `ZONE-TIE-001`).
- [ ] Resolution row appended to ledger with sorted canonical JSON.
- [ ] If quorum reached, single `pattern_confirmed` emitted (see `knowledge_dag`).
