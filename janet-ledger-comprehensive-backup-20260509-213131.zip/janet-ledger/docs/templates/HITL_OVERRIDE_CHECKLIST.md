# HITL override checklist (template)

Use one row per override; link ledger `entry_hash` and `pattern_observation` payload.

| # | Session | Frame id | GEO cell hash (64 hex) | Prior zone claim | Routed zone | HITL token | Validator | Timestamp (UTC) |
|---|---------|----------|--------------------------|-------------------|-------------|------------|-----------|-------------------|
| 1 |         |          |                          |                   |             |            |           |                   |

- [ ] Coordinate ingested only via **GEO-PROJ-001** (no raw floats in ledger JSON).
- [ ] Triadic binding logged (`audit_evidence_binding` or equivalent).
- [ ] Parent ledger hashes recorded for DAG continuity.
