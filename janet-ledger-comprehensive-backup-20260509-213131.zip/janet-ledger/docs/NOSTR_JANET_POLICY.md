# Nostr × JANET — versioned policy codes (NIP-33 payloads)

Engineering handoff: **NIP-33 replaceable event `content`** carries explicit **JANET policy codes** so recovery, rotation, tamper response, and delegation rules are **auditable**, **replay-testable**, and **swappable** without changing the canonical JSON shape (same pattern as `CONV-ADJ-001` / `ZONE-TIE-001`).

Transport and signing use **NIP-01** (and **NIP-17** / **NIP-29** as elsewhere); this document norms **inner JSON** strings produced by `janet_ledger.nostr_janet_policy` (NIP-33-focused) and cross-links NIP-29 roster payloads in `janet_ledger.nip29_validator_group`.

---

## 1. Field: `janet_policy_codes`

Every payload below includes **`janet_policy_codes`**: a **sorted JSON array** of unique strings, each a `NAME-001` token.

Coordinators **MUST** reject payloads missing mandatory codes for that `schema` (see builders in `nostr_janet_policy.py`).

**Mandatory on every payload:** `NIP33-JANET-CONTENT-001` is required in `janet_policy_codes` (enforced by all builders).

---

## 2. Policy codes (normative)

| Code | Meaning |
|------|---------|
| `ROTATION-EPOCH-001` | Enforce monotonic `(epoch, monotonic_counter)` per `(author_pubkey, d-tag)` scope; bind `previous_event_id_hex` when present. |
| `RECOVERY-THRESHOLD-001` | Threshold quorum over `trustee_pubkey_hex`; trustee set is sorted in canonical JSON. |
| `NIP33-JANET-CONTENT-001` | Payload conforms to `nip33_janet_*_v1` schema in this repo (**required** on all builders). |
| `TAMPER-RESPONSE-001` | Tamper → wipe → re-gen policy version; **required** when `wipe_reason` is set on rotation payloads. |
| `DELEGATION-CHAIN-001` | Pre-registered successor binding; used with `nip33_janet_delegation_v1`. |
| `RECOVERY-CHALLENGE-BIND-001` | Challenge id binds exactly one `new_pubkey`; **required** when `recovery_challenge_id_hex` is set on rotation payloads. |
| `NIP29-VALIDATORS-GROUP-001` | NIP-29 `janet-validators` roster inner JSON (`nip29_janet_validators_provision_v1`); see [NIP29_VALIDATORS.md](NIP29_VALIDATORS.md). |
| `VALIDATOR-WEIGHT-QUORUM-001` | Quorum by sum of integer `reputation_weight` over distinct approving pubkeys. |
| `PWA-GAP-PROPOSE-001` | PWA gap proposal inner JSON (`janet_pwa_gap_proposal_v1`); see [BRIDGE_GAP_REWARD.md](BRIDGE_GAP_REWARD.md). |
| `VERIFIER-JANET-001` | Desktop verifier gate before bind/reward rows. |
| `BINDER-001` | Root bind; Desktop-only. |
| `SETTLEMENT-DISPATCH-001` | Desktop-signed dispatch envelope before settlement POST. |

Callers supply the full `janet_policy_codes` set; builders validate mandatory and field-conditional codes.

---

## 3. Schemas (`schema` key)

| `schema` | Builder | Mandatory codes (minimum) |
|----------|---------|----------------------------|
| `nip33_janet_rotation_v1` | `nip33_rotation_payload_canonical` | `ROTATION-EPOCH-001`, `NIP33-JANET-CONTENT-001` (+ conditionals; see §2) |
| `nip33_janet_recovery_policy_v1` | `nip33_recovery_policy_payload_canonical` | `RECOVERY-THRESHOLD-001`, `NIP33-JANET-CONTENT-001` |
| `nip33_janet_delegation_v1` | `nip33_delegation_snapshot_canonical` | `DELEGATION-CHAIN-001`, `NIP33-JANET-CONTENT-001` |
| `nip29_janet_validators_provision_v1` | `nip29_validators_provision_payload_canonical` (`janet_ledger.nip29_validator_group`) | `NIP29-VALIDATORS-GROUP-001`, `VALIDATOR-WEIGHT-QUORUM-001`, `NIP33-JANET-CONTENT-001` |
| `janet_desktop_settlement_dispatch_v1` | `desktop_settlement_dispatch_envelope_canonical` (`janet_ledger.pwa_gap_bridge`) | `SETTLEMENT-DISPATCH-001`, `GAP-REWARD-001`, `NIP33-JANET-CONTENT-001` |

---

## 4. Public material encoding

- **Pubkeys:** 64-character lowercase hex (**x-only secp256k1** serialization as used across JANET ledger helpers).
- **Event ids / challenges:** same 64-hex form (SHA-256 digests).
- **Relays:** untrusted; verifiers re-check signatures and policy gates locally.

---

## 5. Integration with local audit log

Mirror each published (or received) canonical `content` string into the **hash-chained audit log** used elsewhere in JANET (`entry_hash` style) so **relay head** and **local tail** can be diffed.

---

## 6. Reference implementation

`janet_ledger/nostr_janet_policy.py`, tests in `tests/test_nostr_janet_policy.py`.
