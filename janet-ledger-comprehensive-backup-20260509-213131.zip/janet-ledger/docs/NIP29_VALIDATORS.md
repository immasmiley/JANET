# NIP-29 `janet-validators` group (roster + weighted quorum)

This repo does **not** open relay sockets or verify Schnorr on group events. It defines **canonical inner JSON** and **pure quorum arithmetic** so coordinators can publish a **JANET-managed** NIP-29 validator roster with explicit policy codes.

---

## 1. Policy codes

| Code | Role |
|------|------|
| `NIP29-VALIDATORS-GROUP-001` | Roster payload is an authorized `janet-validators` group definition. |
| `VALIDATOR-WEIGHT-QUORUM-001` | Quorum = **sum of `reputation_weight`** over distinct approving pubkeys (not head-count). |
| `NIP33-JANET-CONTENT-001` | Same canonical JSON marker as other JANET Nostr inner payloads. |

---

## 2. Stable group address

`janet_validators_group_address_v1()` returns a **64-hex** digest (SHA-256 over a fixed preimage). Use it as the canonical **group id** in NIP-29 tags / coordinator config alongside slug `janet-validators` (`GROUP_SLUG_JANET_VALIDATORS`).

---

## 3. Provision payload

- **Builder:** `nip29_validators_provision_payload_canonical` (or `auto_provision_janet_validators_payload`).
- **Schema:** `nip29_janet_validators_provision_v1`.
- **Members:** sorted by `pubkey_hex`; each `{ "pubkey_hex", "reputation_weight" }` with weight ≥ 1.
- **`quorum_weight_sum_required`:** must be ≤ sum of weights and ≥ 1.
- **`relay_hints`:** sorted unique strings (may be empty `[]`).

**Verifier:** `verify_nip29_validators_provision_canonical` — rejects non-canonical JSON (extra keys, wrong member order).

---

## 4. Reputation-weighted quorum (off-relay)

1. Load roster weights: `roster_weights_from_provision_dict(parsed_json)`.
2. Collect approving pubkeys (from verified votes / signatures — **native crypto out of scope here**).
3. `accumulated_vote_weight(approved_pubkeys=..., roster_weights_by_pubkey=...)`.
4. `weighted_quorum_met(signed_weight=..., quorum_weight_sum_required=...)`.

**Round order:** `sort_validators_for_round(proposal_id_hex=..., members=...)` — deterministic order using `SHA-256(proposal_id || pubkey)` so coordinators can sequence validation rounds without central randomness.

---

## 5. Relation to `GAP-REWARD-001`

Crowd validators may co-sign **gap-closure** vouchers (`quorum_sigs` in `gap_reward`). This document norms **who is on the roster** and **how weighted quorum is computed**; Schnorr checks remain in production verifiers.
