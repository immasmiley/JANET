# HITL pattern knowledge & immutable DAG edges (normative)

**Schema:** `hitl_knowledge_v1`  
**Purpose:** Grow **auditable** coverage—explicit human overrides, ontology/frame refinements, and convergence—without changing the δ-lattice or introducing hidden weights. “Intelligence” here means **reproducible reasoning quality** and logged coverage, not stochastic completion.

---

## 1. Event types

| `event_type` | When |
|--------------|------|
| `pattern_observation` | Each HITL-validated **coordinate→frame** override (one ledger row). |
| `pattern_confirmed` | **Once** when **≥ 3 distinct `session_id`** values have produced observations sharing the same **`coord_frame_v1`** mapping key. |

---

## 2. Coordinate→frame identity (`coord_frame_v1`)

No raw WGS84 in the key—only the **GEO-PROJ-001** cell hash and the **frame id**:

```json
{"frame_id":"<string>","geo_cell_sha256_hex":"<64 lower hex>","mapping_schema":"coord_frame_v1"}
```

Sorted keys, compact separators. **`mapping_key_sha256`** = SHA-256 hex of that UTF-8 string. Used for deduplication and convergence.

---

## 3. `pattern_observation` payload

Canonical JSON (sorted keys) includes at minimum:

- `schema`: `hitl_knowledge_v1`
- `event_type`: `pattern_observation`
- `hitl_token`, `session_id`, `frame_id`, `geo_cell_sha256_hex`
- `mapping_key_canonical`, `mapping_key_sha256`
- `triad_evidence_fingerprint` (UInt64 from triadic binding; same family as `EvidenceTriadResult.evidence_fingerprint`)
- Integer `k_a`, `k_b`, `k_c`, `k_rank` (δ-line / overlay indices)
- `parent_entry_hashes`: sorted list of **64-hex ledger entry hashes** this row extends (DAG **parents**)
- `sub_lattice_path`: dotted path for recursive overlays; root default **`"0"`** (e.g. `"0.12.45"` for nested lattice addressing without new deps)

Append to the main ledger with the same **`entry_hash(prev_hex, payload)`** rule as all other rows.

---

## 4. `pattern_confirmed` payload

Emitted when **`pattern_state_after_observation`** first sees **three distinct sessions** for one `mapping_key_sha256`. Fields include:

- `session_ids` (sorted, unique)
- `distinct_session_count`
- `parent_observation_entry_hashes`: sorted observation **entry** hashes that contributed
- `triad_evidence_fingerprint` and `k_rank` from the **confirming** observation (the call that completed the quorum)

**Persistence:** coordinators must persist **`confirmed_digests`** (or replay the ledger) so restarts do not emit duplicate `pattern_confirmed` rows.

---

## 5. Audit bundles

**`audit_bundle_canonical`** wraps a multiset of canonical event JSON strings in sorted order:

```json
{"audit_bundle_schema":"audit_bundle_v1","events":[...]}
```

Same events → same bundle → verifiable export / handoff.

---

## 6. Sub-lattice recursion (addressing only)

`sub_lattice_path` is a **naming hook** for infinite recursive overlays: the core package does not materialise sub-lattices, but ledger rows stay **linkable** to nested contexts without breaking δ-invariants.

---

## 7. Reference

Implementation: `janet_ledger/knowledge_dag.py`. Tests: `tests/test_knowledge_dag.py`.
