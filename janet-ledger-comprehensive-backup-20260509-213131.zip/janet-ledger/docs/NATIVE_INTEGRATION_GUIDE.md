# Native integration guide (hardware keystore + relays)

Targets: **iOS (Secure Enclave / CryptoKit)**, **Android (Keystore / StrongBox)**, **Desktop (platform HSM or OS keystore)**. This repo supplies **canonical JSON**, **hash-chain helpers**, and **pytest**; wire I/O and crypto in native code.

---

## 1. Python dependency

```bash
pip install -e /path/to/janet-ledger
```

Import builders from `janet_ledger` per `janet_ledger.__all__` or submodule paths in [BRIDGE_GAP_REWARD.md](BRIDGE_GAP_REWARD.md), [GAP_REWARD_BADGE.md](GAP_REWARD_BADGE.md), [DEMO_IDENTITY_LIVE.md](DEMO_IDENTITY_LIVE.md).

---

## 2. Signing: dispatch envelope → Schnorr

1. Build dispatch: `desktop_settlement_dispatch_envelope_canonical(...)` → UTF-8 string `D`.
2. Challenge: `h_hex = nip01_challenge_hash_for_desktop_utf8(tagged_payload_utf8=D)`.
3. Native: `msg32 = Data(hex: h_hex)` (32 bytes). Sign with **secp256k1** Schnorr using **root** key handle only (never export raw `nsec`).
4. POST body JSON: `{"settlement_dispatch_canonical": D, "desktop_schnorr_sig_hex": <128 lowercase hex>}`.

Settlement stub checks **length** of `desktop_schnorr_sig_hex`; production settlement **must** verify `sig` against `desktop_root_pubkey_hex` from parsed dispatch and `msg32`.

---

## 3. Signing: NIP-01 events (NIP-33 revoke, rotation, etc.)

- Serialize unsigned NIP-01 event per product Nostr library.
- Event `id` = double-SHA-256 of serialized form (per NIP-01).
- Sign `id` with same hardware key path as §2.

Inner `content` strings **must** match janet-ledger builders (`nip33_session_revoke_pwa_payload_canonical`, `nip33_rotation_payload_canonical`, …).

---

## 4. PWA gap path (WebCrypto + relay)

| Step | Web | Notes |
|------|-----|------|
| Delegate | Parse `delegation_session_offer_canonical` from QR/WSS | `permitted_publish_kinds=ALLOWED_PWA_GAP_DELEGATION_KINDS`, `allowed_kinds=(38822,)` |
| Publish | `EVENT.kind === 38822`, `content = pwa_gap_proposal_payload_canonical(...)` | No other kinds if gap-only delegation |
| REQ | `JSON.parse(pwa_relay_req_filter_capsule_canonical(..., permitted_publish_kinds=ALLOWED_PWA_GAP_DELEGATION_KINDS))` | Enforce subset in client |

**Forbidden:** building `gap_reward_badge_payload_canonical` or bind payloads in JS; use `assert_pwa_gap_proposal_field_allowlist` patterns server-side if mirroring.

---

## 5. Desktop audit tail

- Persist last head `prev_hash_hex` (64 hex genesis `0…0` or last `entry_hash` output).
- On each mirrored PWA event: `row, next_h = desktop_audit_mirror_pwa_event_row_canonical(...)` then store `next_h`.
- On bind / voucher rows: `desktop_audit_chain_append(prev_hash_hex=tail, row_payload_canonical_utf8=row)`; store returned digest as new tail.

`entry_hash` contract: same as `README.md` §4 Ledger continuity and `TEST_MANIFEST.json` (ASCII hex `prev` concatenated with UTF-8 payload, then SHA-256).

---

## 6. Relay WebSocket (native)

| Role | Suggested `REQ` | Publish |
|------|-----------------|---------|
| PWA delegate | From `pwa_relay_req_filter_capsule_canonical` | Only allowed kinds (38822 for gap profile) |
| Desktop root | Full filters + NIP-33 admin kinds | Rotation, revoke, reward-related **only** from root handle |

Use **NIP-42** `AUTH` if relay requires; out of scope for janet-ledger tests. Wire-level subscription/propagation: [§8 below](#8-live-relay-subscription-and-propagation-platform).

---

## 7. CI vs staging

| Mode | Command | Purpose |
|------|---------|---------|
| Offline | `pytest -q --cov=janet_ledger --cov-fail-under=85` | Default CI |
| Relay live | `RELAY_LIVE=1 pytest -q -m relay_live` | GitHub Actions `workflow_dispatch` job `relay_live` |

Extend `tests/test_relay_live_bridge.py` when native coordinator can call relay + HSM; keep **no secrets** in repo.

---

## 8. Live relay subscription and propagation (platform)

**Not implemented in janet-ledger** — requires **native WebSocket** shims per OS:

- Open TLS `wss://` to configured relays; send NIP-01 `["REQ", subid, filters…]`; parse `EVENT`, `EOSE`, `NOTICE`, `CLOSED`.
- **PWA:** browser `WebSocket` + same filter discipline as §4; optional `AUTH` (NIP-42) per relay.
- **Desktop:** separate socket with root filters; ingest PWA-originated `EVENT` ids for `desktop_audit_mirror_pwa_event_row_canonical`.
- **Propagation** is relay-defined (fan-out, latency); do not assume delivery until `EVENT` received or relay ACK policy documented by product.

---

## 9. Hardware Schnorr verification (production)

| Layer | Behavior |
|-------|----------|
| **janet-settlement-stub** | Accepts `desktop_schnorr_sig_hex` if length = 128 lowercase hex; **no** secp256k1 verify. |
| **Production settlement** | Verify **BIP340** Schnorr: message `msg32 = bytes.fromhex(nip01_challenge_hash_for_desktop_utf8(tagged_payload_utf8=D))`, pubkey from `desktop_root_pubkey_hex` in dispatch `D`, signature wire format 64 bytes → 128 hex. |
| **Root signing** | Use **Secure Enclave** (iOS), **Android Keystore / StrongBox** (hardware-backed), **TPM / platform key** (Windows/Linux) — never verify with software-only root in prod. |

---

## 10. HSM attestation hooks (CI mock, staging hardware)

| Phase | Responsibility |
|-------|----------------|
| **CI** | Mock attestation / memory vault only where env-gated (see [DEMO_IDENTITY_LIVE.md](DEMO_IDENTITY_LIVE.md), `ALLOW_CI_DEMO_MEMORY_VAULT`); no real TPM quotes in default pipeline. |
| **Staging** | Real **DeviceCheck / Play Integrity / TPM quotes** before trusting long-lived root signing or first `GAP-REWARD-001` dispatch. |
| **Hook points** | After delegation bind, before first voucher build; optional re-attest on `RELAY_LIVE` session start. |

**Deferred:** full hardware attestation E2E stays out of default `pytest`; enable `relay_live` workflow + device lab when shims land.

---

## 11. Reference doc map

| Topic | Doc |
|-------|-----|
| Bridge state + policies | [BRIDGE_GAP_REWARD.md](BRIDGE_GAP_REWARD.md) |
| Voucher + settlement stub | [GAP_REWARD_BADGE.md](GAP_REWARD_BADGE.md) |
| PWA / Desktop split | [DESKTOP_PWA_SPLIT.md](DESKTOP_PWA_SPLIT.md) |
| Live demo + `HardwareDemoSigning` Protocol | [DEMO_IDENTITY_LIVE.md](DEMO_IDENTITY_LIVE.md) |
| Validator roster / quorum math | [NIP29_VALIDATORS.md](NIP29_VALIDATORS.md) |
| NIP-33 inner policy codes | [NOSTR_JANET_POLICY.md](NOSTR_JANET_POLICY.md) |
