# BRIDGE: PWA gap proposal → Desktop reward → settlement (normative)

Native keystore + relay wiring: [NATIVE_INTEGRATION_GUIDE.md](NATIVE_INTEGRATION_GUIDE.md).

## 0. Trust

| Actor | Keys | Publishes |
|-------|------|-----------|
| Desktop | Hardware `nsec` (root) | `VERIFIER-JANET-001`, `BINDER-001`, `GAP-REWARD-001`, NIP-33 revoke, settlement POST |
| PWA | NIP-26 delegate only | kind `38822` body = `pwa_gap_proposal_payload_canonical` |
| Settlement | Verifier | HTTP POST from Desktop only |

NIP-26 offer: `delegation_session_offer_canonical(..., permitted_publish_kinds=ALLOWED_PWA_GAP_DELEGATION_KINDS, allowed_kinds=(38822,))`.

## 1. State machine (ordered)

1. `pwa_gap_proposal_payload_canonical` → PWA EVENT kind `38822` (optional relay).
2. Desktop ingests event → `desktop_audit_mirror_pwa_event_row_canonical` → `desktop_audit_chain_append` (prev = last audit head).
3. `VERIFIER-JANET-001` run (native) → row `verifier_result` in product DB.
4. If PASS: `desktop_gap_bind_row_canonical` → append audit (`entry_hash`).
5. NIP-29 quorum (relay) → product records `quorum_sigs` (128-hex each).
6. `gap_reward_badge_payload_canonical` (Desktop only) → append signed voucher row to audit → `audit_row_hash_after_voucher_hex`.
7. `desktop_settlement_dispatch_envelope_canonical` → `nip01_challenge_hash_for_desktop_utf8(dispatch)` → hardware sign → POST `{"settlement_dispatch_canonical","desktop_schnorr_sig_hex"}`.
8. `janet-settlement-stub`: `parse_settlement_post_body` → `settle_gap_reward_voucher` (secp verify out-of-scope in stub; sig length checked).

## 2. Bridge transports (non-Nostr)

| Direction | Payload | Transport |
|-----------|---------|-----------|
| PWA→Desktop | `pwa_gap_proposal_payload_canonical` | WSS paired / QR chunk / secure channel |
| Desktop→PWA | `desktop_gap_bridge_status_canonical` | same channel poll |

## 3. Policy codes (audit + inner JSON)

- `PWA-GAP-PROPOSE-001` — proposal rows.
- `VERIFIER-JANET-001` — bind row gate.
- `BINDER-001` — root bind.
- `GAP-REWARD-001` / `BADGE-ATTEST-001` / `NIP33-JANET-CONTENT-001` — voucher.
- `SETTLEMENT-DISPATCH-001` — dispatch envelope.

## 4. Forbidden on PWA

`assert_pwa_gap_proposal_field_allowlist`: no `binder_pubkey_hex`, `gap_id`, `triad_hash`, `quorum_sigs`, `verifier_result`, `badge_slug`.

## 5. CI

- Default: `pytest` (relay_live test skipped).
- Optional: workflow `relay_live` (manual dispatch) + `RELAY_LIVE=1 pytest -m relay_live`.

## 6. Platform-owned (not in `janet-ledger` Python)

See [NATIVE_INTEGRATION_GUIDE.md](NATIVE_INTEGRATION_GUIDE.md):

- **Live relay subscription/propagation** — native WebSocket shims (`wss://`, `REQ`/`EVENT`, NIP-42); [NATIVE_INTEGRATION_GUIDE §8](NATIVE_INTEGRATION_GUIDE.md#8-live-relay-subscription-and-propagation-platform).
- **Hardware Schnorr verification** — settlement stub = hex length only; production = BIP340 verify + Secure Enclave / Keystore-StrongBox / TPM; [§9](NATIVE_INTEGRATION_GUIDE.md#9-hardware-schnorr-verification-production).
- **HSM attestation hooks** — CI mocks; staging = real DeviceCheck / Play Integrity / TPM quotes; [§10](NATIVE_INTEGRATION_GUIDE.md#10-hsm-attestation-hooks-ci-mock-staging-hardware).
