# Device trust & family binding (passwordless)

**Goal:** Tie **device → user** and **user → family** with **multiple explicit factors**, without storing memorized passwords. The user’s protection is primarily **device security** (screen lock, secure enclave, OS‑gated biometrics) plus **cryptographic keys** (passkeys).

**Ledger:** append canonical payloads from `janet_ledger.device_trust.identity_binding_canonical` with the same `entry_hash(prev, payload)` rule as all other rows.

---

## 1. Factor codes (extensible)

| Code | Meaning |
|------|---------|
| `FACTOR-DEVICE-PASSKEY-001` | WebAuthn / passkey proof verified by coordinator; ledger holds **SHA‑256(pubkey)** (or agreed pubkey material), never private keys. |
| `FACTOR-SCREEN-LOCK-002` | Device attests user passed local gate for this action (honesty model: OS / attestation; optional future: signed assertion). |
| `FACTOR-FAMILY-LEDGER-003` | Family accepted the binding via prior **ledger anchor** and/or **HITL** row referenced in `parent_entry_hashes`. |

Add new `FACTOR-*` codes only with a doc row and tests; never infer factors silently.

---

## 2. Roles

- **`device_to_user`**: first binding of a device key to a user record (may omit `user_pubkey_sha256_hex` if identical to device key for single‑key users).
- **`user_to_family`**: binds user into family context; include `family_ledger_anchor_hex` (64‑hex row you treat as anchor) and optional `family_graph_n_index` (0..216) when mapped on the ring.

---

## 3. Multi-factor rule (normative)

At least **two** distinct factor codes in `factors_applied` for `device_to_user`, and for `user_to_family` include **`FACTOR-FAMILY-LEDGER-003`** plus one device‑side factor **unless** pure HITL quorum is explicitly allowed by deployment policy (document that exception in your coordinator).

Enforcement of counts is **coordinator policy**; this package only canonicalizes payloads.

---

## 4. Reference

`janet_ledger/device_trust.py`, `tests/test_device_trust.py`.
