# 217 architecture capability matrix

This document ties **seven emergent capabilities** (geometric + cryptographic primitives on the 217 ring, δ-stepping, hashing, antisymmetry, zone routing) to **concrete janet-ledger modules**. No separate stack is required: coordinators compose these pure functions and ledger conventions.

---

## 1. Antisymmetric mediation

**Idea:** Opposed or paired positions map to a signed \(c\) line; equilibrium at \(c = 0\) is a verifiable synthesis point.

| Module | Roles |
|--------|--------|
| `janet_ledger.lattice217` | `x_at`, `x_at_frac`, `nearest_n`, `janet_index_for`, `is_equilibrium`, `step_toward_equilibrium`, `trajectory_to_equilibrium` |
| `janet_ledger.lattice217` | `antisymmetric_n` — antisymmetric partner on the ring |
| `janet_ledger.constants` | `DELTA`, `k_index_from_coord` — same step as rational δ in the lattice |
| `janet_ledger.equilibrium` | `equilibrium_null_fires` — EQ-NULL style termination checks |
| `janet_ledger.family_graph` / `lattice217` | `family_n_to_janet_k` — map family slot index `n` to symmetric `k` |

**Normative context:** README §ledger + zone routing; `TEST_MANIFEST.json` goldens for convergence.

---

## 2. Epistemic drift tracking

**Idea:** Ledger-anchored evidence and coordinates show how domain understanding moves across zones over time (longitudinal knowledge graph).

| Module | Roles |
|--------|--------|
| `janet_ledger.evidence_triad` | `geo_cell_overlay_from_wgs84_e7`, `language_overlay_from_confirmed_iso639_1`, `triadic_parents_from_bound_evidence`, `audit_evidence_binding`, `canonical_evidence_payload`, `evidence_fingerprint_from_payload` |
| `janet_ledger.knowledge_dag` | `pattern_observation_payload`, `pattern_confirmed_payload`, `pattern_state_after_observation`, `audit_bundle_canonical` — HITL DAG edges via sorted parent hashes |
| `janet_ledger.zones` | `route_zone`, `route_zone_with_tie_meta` — classify `c` into zones per manifest tie |
| `janet_ledger.toolbox` | `audit_session_bundle_canonical` — glue ledger payloads + zone outcomes + evidence dicts for export |

**Specs:** [EVIDENCE_TRIAD.md](EVIDENCE_TRIAD.md), [HITL_KNOWLEDGE.md](HITL_KNOWLEDGE.md).

---

## 3. Deterministic scenario sandboxing

**Idea:** Hash-chained ledger + pure replay functions fork and compare policy simulations without corrupting live state.

| Module | Roles |
|--------|--------|
| `janet_ledger.ledger` | `entry_hash`, `entry_hash_binary_prev` — chain steps (UTF-8 hex prev vs binary-alt) |
| `janet_ledger.convergence` | `evaluate_scenario` — manifest-driven scenario boolean |
| `janet_ledger.policy_config` | `PolicyConfig`, `policy_config_from_manifest` — inject default convergence policy, zone tie coord |
| `janet_ledger.toolbox` | `diff_manifest_convergence_scenarios`, `diff_canonical_jsonl_lines`, `whatif_convergence_json` |
| `janet_ledger.whatif` | CLI `python -m janet_ledger.whatif` |

**Manifest:** `TEST_MANIFEST.json` (`domain_libraries` for replay slices).

---

## 4. Privacy-preserving audit

**Idea:** Verifiers accept ledger heads + proofs of inclusion; sensitive payloads stay off the wire.

| Module | Roles |
|--------|--------|
| `janet_ledger.ledger` | `entry_hash` — commitment per row from canonical payload + prev digest |
| `janet_ledger.toolbox` | `cache_key_ledger_row` — stable dedup keys from prev + payload |
| `janet_ledger.renderer` | `render_log_hash` — auxiliary hash over ledger head + canonical renderer config |
| `janet_ledger.device_trust` | `identity_binding_canonical` — bind device/user/family with pubkey hashes and factor codes, not secrets |

**Extension (not in-package):** Batch rows under a Merkle tree built from the same `entry_hash` digests; third parties verify membership without receiving full chain plaintext. This repo commits to row hashes only.

---

## 5. Pedagogical zone gating

**Idea:** Reasoning is forced through ordered zones; competency is replay-auditable, not self-reported.

| Module | Roles |
|--------|--------|
| `janet_ledger.zones` | `route_zone`, `route_zone_with_tie_meta` — FINAL intervals + ZONE-TIE-001 at configured `tie_coord` |
| `janet_ledger.policy_config` | `policy_config_from_manifest` — coordinator-wide `zone_router.tie_break_coord` |
| `janet_ledger.renderer` | `render_surface`, `RendererConfig` — §5.4 safety strip (`safety_54_active`), deterministic `variant_index` |
| `janet_ledger.toolbox` | `coherence_binding_vs_zone` — explicit zone claim vs routed zone + triadic audit ids |

---

## 6. Cross-tradition consensus

**Idea:** Independent frame libraries share the same lattice; the ledger reconciles divergent mappings without a single forced translation layer at the edge.

| Module | Roles |
|--------|--------|
| `janet_ledger.evidence_triad` | Bound evidence → triadic parents; same overlay math for every domain |
| `janet_ledger.knowledge_dag` | HITL observations and confirmations with DAG parent hashes — disagree, then converge on-chain |
| `janet_ledger.convergence` + manifest | `evaluate_scenario` over `domain_libraries` entries (e.g. clinical, legal) in `TEST_MANIFEST.json` |

---

## 7. Automated compliance mapping

**Idea:** Bright-line rules and policy codes map to exports, zone tables, and BOM artifacts for CI or runtime checks.

| Module / script | Roles |
|-----------------|--------|
| `janet_ledger.pwa_gap_bridge` | `pwa_gap_proposal_payload_canonical`, `desktop_gap_bind_row_canonical`, `desktop_settlement_dispatch_envelope_canonical`, `desktop_audit_mirror_pwa_event_row_canonical`, `nip01_challenge_hash_for_desktop_utf8` — Desktop/PWA split + settlement POST envelope |
| `janet_ledger.nip29_validator_group` | `nip29_validators_provision_payload_canonical`, `janet_validators_group_address_v1`, `accumulated_vote_weight`, `sort_validators_for_round` — **janet-validators** roster + weighted quorum (no relay I/O) |
| `janet_ledger.settlement_stub` | `run_stub_server`, `settle_gap_reward_voucher`, `mint_local_test_badge` — **dev-only** HTTP stub, stub SHA-256 chain head, filesystem dedup → `badges/*.json` |
| `janet_ledger.gap_reward` | `gap_reward_badge_payload_canonical`, `gap_reward_dedup_key`, `assert_verifier_passed_before_reward` — verified gap closure as **badge voucher** (`GAP-REWARD-001` + `BADGE-ATTEST-001`); settlement off-ledger |
| `janet_ledger.export_bundle` | `zone_map_export_dict`, `static_ui_bundle_dict`, `equilibrium_rules_export_dict`, `k_delta_line_export_dict`, `ledger_golden_vectors_to_jsonl_lines` |
| `scripts/export_compliance_artifacts.py` | Emit `artifacts/` for CI |
| `scripts/policy_bom.py` | Aggregate `janet_ledger.__all__` and policy-like codes from selected docs |
| `janet_ledger.policy_config` | Typed manifest subset for router and convergence defaults |

**Related docs:** [EVIDENCE_TRIAD.md](EVIDENCE_TRIAD.md), [HITL_KNOWLEDGE.md](HITL_KNOWLEDGE.md), [DEVICE_TRUST_MODEL.md](DEVICE_TRUST_MODEL.md), [NOSTR_JANET_POLICY.md](NOSTR_JANET_POLICY.md), [NIP29_VALIDATORS.md](NIP29_VALIDATORS.md), [DEMO_IDENTITY.md](DEMO_IDENTITY.md), [DEMO_IDENTITY_LIVE.md](DEMO_IDENTITY_LIVE.md), [DESKTOP_PWA_SPLIT.md](DESKTOP_PWA_SPLIT.md), [BRIDGE_GAP_REWARD.md](BRIDGE_GAP_REWARD.md), [NATIVE_INTEGRATION_GUIDE.md](NATIVE_INTEGRATION_GUIDE.md), [GAP_REWARD_BADGE.md](GAP_REWARD_BADGE.md).

---

## Summary

| # | Capability | Primary entrypoints |
|---|------------|----------------------|
| 1 | Antisymmetric mediation | `antisymmetric_n`, `lattice217.*`, `equilibrium_null_fires` |
| 2 | Epistemic drift | `evidence_triad.*`, `knowledge_dag.*`, `route_zone*` |
| 3 | Scenario sandbox | `evaluate_scenario`, `diff_manifest_convergence_scenarios`, `whatif_convergence_json` |
| 4 | Privacy-preserving audit | `entry_hash`, `identity_binding_canonical`; Merkle layer external |
| 5 | Zone gating | `route_zone*`, `render_surface` §5.4, `coherence_binding_vs_zone` |
| 6 | Cross-tradition consensus | `triadic_parents_from_bound_evidence`, HITL payloads, `domain_libraries` |
| 7 | Compliance mapping | `export_bundle.*`, `policy_bom.py`, `policy_config_from_manifest` |

**Nostr / transport policy payloads (handoff):** [NOSTR_JANET_POLICY.md](NOSTR_JANET_POLICY.md) — `nip33_rotation_payload_canonical`, `nip33_recovery_policy_payload_canonical`, `nip33_delegation_snapshot_canonical` in `janet_ledger.nostr_janet_policy`. **NIP-29 validators:** [NIP29_VALIDATORS.md](NIP29_VALIDATORS.md). **Live demo + hardware:** [DEMO_IDENTITY_LIVE.md](DEMO_IDENTITY_LIVE.md). **Gap closure → badge voucher:** [GAP_REWARD_BADGE.md](GAP_REWARD_BADGE.md).
