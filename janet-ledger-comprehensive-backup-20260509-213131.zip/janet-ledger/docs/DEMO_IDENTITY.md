# Demo identity (relay validation, zero-touch teardown)

Normative module: **`janet_ledger.demo_identity`**. Native coordinators own keystore handles, relay pools, and NIP-01 signing; this repo supplies **canonical JSON**, **state transitions**, and **retirement ordering**.

**Live production (hardware + real relays):** **[DEMO_IDENTITY_LIVE.md](DEMO_IDENTITY_LIVE.md)** — state flow, pseudocode, storage mapping, atomic teardown, integration test matrix. Python contracts: **`janet_ledger.demo_identity_production`** (`HardwareDemoSigning`, `LiveNostrRelayPool`, production guard).

---

## 1. State machine

```
first_launch → demo_provision → relay_ping → demo_active
                    │                │            │
                    └────────────────┴────────────┘
                                     │ CREATE_REAL_ACCOUNT | ACCEPT_FAMILY_INVITE
                                     ▼
                            retire_sequence → retired_final → real_init
```

| State | Meaning |
|-------|---------|
| `first_launch` | No demo material yet. |
| `demo_provision` | Demo key registered in vault; NIP-33 `demo-provision` payload ready / published. |
| `relay_ping` | Connectivity / relay filter probe in flight. |
| `demo_active` | Safe to run NIP-17/NIP-29 demo traffic; only state that accepts retirement. |
| `retire_sequence` | Ephemeral; entered by `execute_demo_retirement`. |
| `retired_final` | Demo key deleted; session purged; irreversible. |
| `real_init` | Real account flow may start; relay pool must not reuse `demo_` tags. |

API: `auto_provision_demo_session`, `advance_demo_relay_ping`, `advance_demo_active`, `execute_demo_retirement`, `advance_real_init`.

---

## 2. Policy codes (NIP-33 / NIP-29 / NIP-17 inner `content`)

| Code | Use |
|------|-----|
| `DEMO-IDENTITY-001` | Keystore / policy tag; provision + NIP-17 demo envelope. |
| `DEMO-PROVISION-001` | NIP-33 `d: demo-provision` schema. |
| `DEMO-RETIRE-001` | NIP-33 `d: demo-retired` + NIP-29 leave + teardown. |
| `NIP17-DEMO-SESSION-001` | Demo-only NIP-17 session marker (tests). |
| `NIP33-JANET-CONTENT-001` | Shared content-schema marker (from `nostr_janet_policy`). |

---

## 3. Secure storage layout (coordinator)

| Key / record | Type | Notes |
|--------------|------|--------|
| `demo_key_handle_id` | string | Opaque OS handle; **never** mix with production `KeyHandleId`. |
| `demo_pubkey_hex` | 64 hex | Derived from hardware pubkey export. |
| `nip29_group_id` | string | **MUST** prefix `demo_`. |
| `last_demo_event_id_hex` | 64 hex | Tip for `chain_prev_event_id_hex` on retire. |
| `demo_retired_irreversible` | bool | Once true, refuse all demo re-provision (or reinstall only). |
| Relay pool tag | string | Fixed `demo_` for WS subscriptions / publish routing. |

NIP-17 session keys: filenames / SQL keys prefixed `demo_` (implementation-specific).

---

## 4. Retirement sequence (strict order)

Constant **`RETIREMENT_STEP_ORDER`**:

1. Build NIP-33 `demo-retired` content (`nip33_demo_retired_payload_canonical`).  
2. Sign + publish (demo key) → obtain `retire_event_id`.  
3. Build NIP-29 `leave` body (`nip29_demo_leave_payload_canonical`).  
4. Sign + publish (demo key) → obtain `leave_event_id`.  
5. **`DeleteKey(demo_key_handle)`** — hardware wipe.  
6. Purge local demo DB / cache.  
7. Append **`demo_retired_audit_row_canonical`** + `entry_hash(audit_ledger_prev, row)` for JANET continuity.

`execute_demo_retirement` materializes steps 1–4 as canonical strings + synthetic ids, performs 5–6 on session/vault, returns audit row + final hash (step 7).

---

## 5. Triggers

| Input | `reason` in NIP-33 retire payload |
|--------|-------------------------------------|
| `CREATE_REAL_ACCOUNT` | `user_promoted` |
| `ACCEPT_FAMILY_INVITE` | `family_invite_accepted` |

---

## 6. Irreversibility

After `execute_demo_retirement`, `session.retired_irreversibly` is true and demo handles are removed from the vault adapter. Re-running provision on the same session object MUST fail state checks; a **new** app install or explicit factory reset policy may create a new session.

---

## 7. CI

Use **`InMemoryDemoKeyVault`** only when ``JANET_ALLOW_CI_DEMO_MEMORY_VAULT=1`` for pytest; default CI does not set it — call ``assert_no_ci_memory_vault_in_production`` from production bridges to reject the memory vault. Deterministic ``simulate_nostr_event_id``; no live relays in default janet-ledger CI. Live relay jobs: see **[DEMO_IDENTITY_LIVE.md](DEMO_IDENTITY_LIVE.md)** §7.
