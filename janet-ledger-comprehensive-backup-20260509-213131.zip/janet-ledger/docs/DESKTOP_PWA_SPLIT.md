# Desktop root + volatile PWA (split trust)

Normative payloads: **`janet_ledger.pwa_session_policy`**. Native Desktop owns signing and NIP-33 admin; PWA is a **delegated, expiring** read/chat surface. **janet-ledger** does not ship a browser bundle or Desktop binary—only **canonical JSON**, **policy codes**, and **tests**.

---

## 1. Trust-boundary diagram (text)

```
┌─────────────────────────────────────────────────────────────────────────┐
│ DESKTOP (native) — sole root of trust                                      │
│  TPM / Secure Enclave / Keystore: master key NON-exportable              │
│  Signs: NIP-26 delegation to PWA delegatee | NIP-33 revoke | NIP-33 admin │
│  Hash-chained audit log (64-hex prev || canonical UTF-8 → SHA-256)         │
│  DEMO-IDENTITY-001 lifecycle (see DEMO_IDENTITY_LIVE.md)                   │
└─────────────────────────────────────────────────────────────────────────┘
         │ ① QR or WSS localhost: TLS + pairing pin / mutual auth
         │    payload = delegation_session_offer_canonical (+ NIP-26 event bytes)
         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ PWA (browser) — volatile delegate                                           │
│  WebCrypto: generateKey({extractable:false}, …) for session + NIP-44 keys  │
│  IndexedDB: ciphertext + session meta ONLY; NO master nsec               │
│  Relay WS: REQ filters from pwa_relay_req_filter_capsule_canonical         │
│  Publish: ONLY kinds ∈ {1,4,29}; deny NIP-33 / rotation / recovery client  │
└─────────────────────────────────────────────────────────────────────────┘
         │ ② Live Nostr relays (same internet; PWA uses delegate identity)
         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ RELAYS (untrusted)                                                         │
│  NIP-01 OK / NIP-42 AUTH before session active                             │
│  STRONGLY RECOMMENDED: relay-side filter rejecting PWA connection          │
│  publishing kinds ∉ {1,4,29} or any parameterized replaceable from PWA    │
└─────────────────────────────────────────────────────────────────────────┘
         │ ③ Desktop subscribes to same relays with master filter + admin keys
         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ AUDIT MIRROR                                                               │
│  Each PWA-published EVENT → Desktop appends audit row                    │
│  (payload hash + relay id + delegate event id) using entry_hash chain      │
└─────────────────────────────────────────────────────────────────────────┘
```

**Invariant:** master scalar **never** crosses Desktop process boundary. PWA never holds `nsec`.

---

## 2. State machine (Desktop ↔ PWA)

```
Desktop_hardware_init
  → demo_provision (optional; DEMO-IDENTITY-001)
  → delegation_handshake
        Desktop: build delegation_session_offer_canonical; sign NIP-26; push QR/WS
        PWA: import keys extractable:false; store until; open relay after OK/AUTH
  → pwa_volatile_session
        PWA: REQ + EVENT only kinds 1/4/29; Desktop mirrors relay receipts to audit
  → [trigger: real account | revoke | policy]
  → revocation_publish
        Desktop: nip33_session_revoke_pwa_payload_canonical; sign; monotonic++
  → pwa_wipe
        PWA: on valid revoke + sig from Desktop delegate root: zero WK; drop IDB
  → relay_disconnect_pwa_pool
  → real_init (real identity / clean session)
```

## 2b. Gap-reward bridge (parallel track)

When delegating **gap proposals only**: NIP-26 inner offer uses `delegation_session_offer_canonical(..., permitted_publish_kinds=ALLOWED_PWA_GAP_DELEGATION_KINDS, allowed_kinds=(38822,))`. Canonical payloads + audit order: **[BRIDGE_GAP_REWARD.md](BRIDGE_GAP_REWARD.md)** (`janet_ledger.pwa_gap_bridge`).

---

## 3. Payload schemas (canonical builders)

| Builder | Policy codes required | Use |
|---------|------------------------|-----|
| `delegation_session_offer_canonical` | `SESSION-DELEGATE-001`, `NIP33-JANET-CONTENT-001` | Pre-NIP-26 JSON blob; QR/WS body. Optional `permitted_publish_kinds` (default `{1,4,29}`; gap-only: `ALLOWED_PWA_GAP_DELEGATION_KINDS`). |
| `nip33_session_revoke_pwa_payload_canonical` | `SESSION-REVOKE-001`, `NIP33-JANET-CONTENT-001` | NIP-33 `d: session-revoke-pwa` content. |
| `pwa_relay_req_filter_capsule_canonical` | *(none — schema only)* | Serialize allowed `authors` + `kinds` subset. |
| `delegation_offer_fingerprint_hex` | — | `SHA-256(offer_canonical)` → bind revoke row. |

**NIP-26:** Wire `delegation` event is assembled outside janet-ledger; **inner** offer JSON MUST match `delegation_session_offer_canonical` for fingerprint binding.

**NIP-44:** Optional `nip44_session_pubkey_hex` inside offer binds session encryption key to same expiry as `until_unix`.

---

## 4. Capability enforcement

| Layer | Rule |
|-------|------|
| PWA JS (default chat) | Outbound `EVENT.kind` ∈ `{1,4,29}`; reject otherwise. |
| PWA JS (gap-only delegate) | Outbound `EVENT.kind` **only** `38822` with `pwa_gap_proposal_payload_canonical` as `content`. |
| PWA REQ | `pwa_relay_req_filter_capsule_canonical` kinds ⊆ permitted set (default `{1,4,29}`; pass `permitted_publish_kinds` for `38822`-only). |
| Relay | Recommended: authenticated connection class “pwa-delegate” rejects forbidden kinds at ingress. |
| Desktop | All NIP-33 / rotation / recovery; PWA sockets use **different** auth token or delegate-only pubkey. |

---

## 5. Revocation & wipe (PWA)

1. Desktop publishes NIP-33 replaceable `d=session-revoke-pwa` with `SESSION-REVOKE-001`, strict `monotonic_counter`, `delegate_fingerprint_hex` matching offer.  
2. PWA worker polls filter `{authors:[desktop], kinds:[<nip33 kind>], #d:['session-revoke-pwa']}` (exact kind number is product-specific; document in app).  
3. Verify NIP-01 sig using **Desktop master npub** (or delegation chain per product).  
4. `crypto.subtle` wrap/unwrap keys: delete all; `indexedDB.deleteDatabase`; clear `sessionStorage`.  
5. Close WebSocket with policy reason; no retry with stale delegation.

---

## 6. Desktop keystore wrapper (pseudocode)

```
fun desktop_sign_event(unsigned: Event): Event
  digest = nip01_id(unsigned)
  sig = SecKeySign(demo_or_master_handle, digest)   // hardware only
  return unsigned.with(sig)

fun desktop_publish_revoke(offer_canonical: str, prev_event_id: str, mc: int)
  fp = delegation_offer_fingerprint_hex(offer_canonical)
  body = nip33_session_revoke_pwa_payload_canonical(
      chain_prev_event_id_hex = prev_event_id,
      delegate_fingerprint_hex = fp,
      epoch = epoch_now,
      monotonic_counter = mc,
      janet_policy_codes = ("SESSION-REVOKE-001", "NIP33-JANET-CONTENT-001"),
  )
  ev = build_unsigned_nip33(d="session-revoke-pwa", content=body)
  signed = desktop_sign_event(ev)
  relay.publish(signed)
  audit.append(entry_hash(prev_audit, audit_row_for("pwa_revoke_publish", body)))
```

---

## 7. PWA WebCrypto loader (pseudocode)

```
const kp = await crypto.subtle.generateKey(
  { name: "ECDH", namedCurve: "P-256" },  // or Ed25519 per NIP-26 delegate material spec
  false,  // extractable MUST be false
  ["deriveBits", "sign"]
);
// Never store master; store delegation token + until from offer JSON
if (Date.now()/1000 > offer.until_unix) throw new Error("expired");
// REQ filters from pwa_relay_req_filter_capsule_canonical(...)
```

---

## 8. Relay subscription + audit mirroring

**PWA REQ:** built from `pwa_relay_req_filter_capsule_canonical` with `authors_hex` = [delegate npub hex, counterparty…] and `kinds` subset of `{1,4,29}`.

**Desktop mirror:** on each `EVENT` seen on PWA relay connection (or duplicate subscription), append audit payload:

```json
{"schema":"janet_audit_pwa_relay_mirror_v1","event_id_hex":"…","kind":1,"relay_url":"wss://…","delegate_fingerprint_hex":"…"}
```

Chain with `entry_hash` using same 64-hex ASCII `prev` rule as ledger goldens.

---

## 9. Minimal product repo layout (reference)

```
desktop/
  keystore/          SecKey / NCrypt adapters
  nostr/             relay pool, signer, nip26 builder
  audit/             append-only hash chain + export
  bridge/            localhost WSS + QR encoder for offer_canonical
pwa/
  src/crypto/        WebCrypto wrappers (extractable false)
  src/nostr/         thin client; kind guard; revoke poller
  src/db/            IndexedDB schema (volatile only)
```

---

## 10. Security audit checklist

- [ ] Master key `nonExtractable` / TPM-bound; no export API in release builds.  
- [ ] PWA `generateKey` / `importKey` never sets `extractable: true`.  
- [ ] Delegation `until_unix` enforced on PWA before every publish.  
- [ ] PWA binary / relay rejects kinds outside `{1,4,29}`.  
- [ ] Revoke row signature verified against expected Desktop key.  
- [ ] Monotonic `monotonic_counter` on `session-revoke-pwa` enforced Desktop-side.  
- [ ] Post-revoke: zero subtle keys + IDB delete + WS close.  
- [ ] Desktop audit has no gaps: every PWA `EVENT` mirrored or explicitly policy-skipped with reason row.

---

## 11. CI / test strategy

| Job | Scope |
|-----|--------|
| **janet-ledger unit** | Canonical JSON goldens; fingerprint/revoke binding; no network. |
| **Desktop integration** | Platform attestation or HSM simulator **only** where legal for CI; otherwise manual hardware lane. |
| **PWA headless** | Playwright + fake relay **not** used for prod claim—use tagged `live_relay` with real URLs from CI secret. |
| **E2E split** | Desktop publishes offer → PWA connects relay → single kind-1 note → Desktop revoke → assert IDB empty + subtle key count 0. |

---

## 12. Policy codes (BOM extract)

| Code | Role |
|------|------|
| `SESSION-DELEGATE-001` | Desktop→PWA delegation offer (`delegation_session_offer_canonical`). |
| `SESSION-REVOKE-001` | NIP-33 `d: session-revoke-pwa` kill (`nip33_session_revoke_pwa_payload_canonical`). |
| `NIP33-JANET-CONTENT-001` | Shared inner-content marker (from `nostr_janet_policy`). |

---

## 13. Cross-references

- `janet_ledger.ledger.entry_hash` — audit chain.  
- `janet_ledger.pwa_session_policy` — builders + `ALLOWED_PWA_KINDS`.  
- `docs/DEMO_IDENTITY_LIVE.md` — demo lifecycle on Desktop.  
- `docs/NOSTR_JANET_POLICY.md` — general NIP-33 policy pattern.
