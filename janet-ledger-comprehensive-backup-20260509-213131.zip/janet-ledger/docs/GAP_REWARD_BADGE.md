# Gap closure → badge voucher (`GAP-REWARD-001`)

**Ledger = proof; badge = off-ledger.** A settlement engine (webhook, worker, game server) reads canonical rows built by `janet_ledger.gap_reward.gap_reward_badge_payload_canonical`, verifies `quorum_sigs`, `prev_event_id` chain, and **mints the badge** in its own store. Nothing in `janet-ledger` issues UI assets.

---

## 1. Policy codes

| Code | Role |
|------|------|
| `GAP-REWARD-001` | Voucher: verified gap closure eligible for settlement. |
| `BADGE-ATTEST-001` | Payload includes `badge_slug` for which badge class may be granted. |
| `NIP33-JANET-CONTENT-001` | Canonical inner-content marker. |

---

## 2. Builder

`gap_reward_badge_payload_canonical` — sorted JSON, UTF-8 for `entry_hash` chaining.

Coordinator flow:

1. Run JANET verifier → `assert_verifier_passed_before_reward("PASS")`.  
2. Collect NIP-29 quorum signatures → `quorum_sigs` (128-hex each).  
3. Build payload; append `entry_hash(prev_event_id, payload)`.  
4. Emit NIP-33 `d: gap-closed` (or local audit only).  
5. **Dedup:** `gap_reward_dedup_key(triad_hash, badge_slug)` — enforce one row per product policy.  
6. **Validator roster (optional):** publish `janet-validators` via `nip29_validators_provision_payload_canonical` — see [NIP29_VALIDATORS.md](NIP29_VALIDATORS.md).

---

## 3. Settlement boundary

```
GAP-REWARD-001 row  →  verify sigs + chain  →  Badge engine grants `badge_slug` to `binder_pubkey_hex` mapping
```

No write-back to JANET required.

---

## 4. Local settlement stub (E2E dev only)

`janet_ledger.settlement_stub` provides a **stdlib HTTP** listener (no FastAPI) for manual wiring tests:

- **GET** `/test` — HTML page with **QR code** for this page URL, copy-link, `/health`, and POST to `/webhooks/gap-reward` (same origin). Vendored JS: **GET** `/static/qrcode.min.js`.
- **POST** `/webhooks/gap-reward` with body = canonical voucher JSON **string**, or `{"voucher_canonical":"<string>"}`, or Desktop dispatch `{"settlement_dispatch_canonical":"<dispatch>","desktop_schnorr_sig_hex":"<128hex>"}` (stub checks sig **length** only).
- **`verify_gap_reward_voucher_canonical`** (in `gap_reward`) — bit-identical round-trip vs `gap_reward_badge_payload_canonical`.
- **Dedup** (checked before chain): one JSON badge file per `gap_reward_dedup_key`; replay of the same voucher returns **409**.
- **Stub chain:** first mint in an empty `--out-dir` requires `prev_event_id` = 64×`0` (`STUB_ROOT_PREV`). Each successful mint sets the chain head to `SHA-256(utf-8 voucher canonical)`; the next **distinct** voucher must use that digest as `prev_event_id`.

Run:

```bash
pip install -e .
janet-settlement-stub --port 8765 --out-dir ./settlement_data
# or: python -m janet_ledger.settlement_stub --port 8765
```

**Not verified here:** Schnorr signatures, relay timelines, or production identity binding — only voucher shape + stub chain + filesystem dedup.
