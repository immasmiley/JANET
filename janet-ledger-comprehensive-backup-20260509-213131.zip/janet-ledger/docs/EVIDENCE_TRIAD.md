# Deterministic evidence → triadic parents (normative)

**Policy bundle:** `JANET-EVTRIAD-001`  
**Purpose:** Map multi-modal evidence to **three snapped JANET indices** `k_A, k_B, k_C ∈ [−108, 108]` (ring indices `n = k + 108`) so ranking and ledger code never rely on undocumented floating weights.

**δ model:** `δ = 25/27 = 100/108`. After snap, positions materialise as `x = k·δ` with integer `k`.

---

## 1. Ingress rules (lattice invariance)

### Location — `GEO-PROJ-001` only

- **Never** pass raw floating latitude/longitude into triadic ranking.
- **Only** documented path: quantize WGS84 to integers `lat_e7`, `lon_e7` (e.g. `round(lat_deg * 1e7)`) **outside** the triadic core, then call `geo_cell_overlay_from_wgs84_e7(lat_e7, lon_e7)`.
- That function returns a **`GeoCellOverlay`**: fixed grid cell indices, canonical JSON for the cell, SHA-256 of that string, `n = first_8_bytes(digest) mod 217`, then `k = n − 108` (clamped). This is the **reproducible location overlay**; ranking consumes the overlay, not raw coordinates.

### Language — `LANG-MATCH-001` only

- **Onboarding:** user must **explicitly select** a two-letter **ISO 639-1** tag (e.g. `en`, `es`). No free-text language names, no locale inference, no default/fallback if the user did not confirm a tag.
- **Validation:** exactly two ASCII letters `a-z` after `lower()`; no leading/trailing whitespace; no interior whitespace.
- **Mapping:** canonical JSON `{"iso639_1":"<tag>","lang_policy":"LANG-MATCH-001"}` (sorted keys), SHA-256, `n = first_8_bytes(digest) mod 217`, `k = n − 108` (clamped).
- **Audit:** `audit_evidence_binding(result)` logs geo + language hashes, canonical strings, policies, and triadic indices for the ledger.

---

## 2. Policy codes (exhaustive for this bundle)

| Code | Role |
|------|------|
| `GEO-PROJ-001` | Fixed grid on WGS84×1e7 integers → cell `(i_lat, i_lon)` → hash cell → `n mod 217` → `k_A`. |
| `BAT-ANC-001` | BAT tier → fixed anchor `k_B` (integer δ-steps). |
| `LANG-MATCH-001` | User-confirmed ISO 639-1 tag → hash → `n mod 217` → `k_C`. |
| `TRIAD-ORDER-001` | Semantic assignment `A=location overlay`, `B=BAT`, `C=language overlay`. |
| `TRIAD-CHILD-001` | Child index `k_* = snap_k(x(k_A)+x(k_B)+x(k_C))` with rational `x_at_frac`. |
| `PBOOST-000` | Proximity boost `Δk = 0`. |
| `PBOOST-COHORT-001` | `Δk = (F mod 5) − 2` with `F` = `evidence_fingerprint` (UInt64 from binding payload). |
| `TR-SNAP-FLOAT-001` | One `float` coercion at **final** `nearest_n` for the child only (documented). |

**Removed from normative path (do not use for δ-closure):** LOC-SNAP-001, LANG-ISO-001 (superseded by hash-to-ring under GEO / LANG policies above).

**Version bump:** Any change to grid step, canonical JSON shape, or hash extraction requires a new `JANET-EVTRIAD-00x` bundle and new golden vectors.

---

## 3. Normative constants

| Symbol | Value | Meaning |
|--------|-------|---------|
| `GEO_PROJ_GRID_STEP_E7` | `100_000` | Cell width in **1e7·degree** integer units (= **0.01°**). |
| `N_NODES` | `217` | Ring size; `n ∈ {0,…,216}`. |
| `k` | `n − 108` | JANET index in `[-108, 108]`. |

WGS84 ranges enforced on `lat_e7`, `lon_e7`: latitude `[-900_000_000, 900_000_000]`, longitude `[-1_800_000_000, 1_800_000_000]`.

---

## 4. `GEO-PROJ-001` (detail)

1. `cell_i_lat = lat_e7 // GEO_PROJ_GRID_STEP_E7` (integer floor toward −∞).  
2. `cell_i_lon = lon_e7 // GEO_PROJ_GRID_STEP_E7`.  
3. Canonical UTF-8 (sorted keys, no spaces):  
   `{"geo_policy":"GEO-PROJ-001","grid_step_e7":100000,"i_lat":<int>,"i_lon":<int>}`  
4. `digest = SHA256(canonical)`.  
5. `n = int_from_big_endian_uint64(digest[0:8]) mod 217`.  
6. `k_location = clamp(n − 108, −108, 108)` (same as `family_n_to_janet_k` for `n` in range).

---

## 5. `LANG-MATCH-001` (detail)

1. Reject unless tag is exactly two letters `a-z` (post-validation string is canonical lower).  
2. Canonical UTF-8:  
   `{"iso639_1":"<tag>","lang_policy":"LANG-MATCH-001"}`  
3. Same hash → `n mod 217` → `k_language` as for geo.

---

## 6. `BAT-ANC-001` (unchanged)

| `bat_tier` | `k_bat` |
|------------|---------|
| `hot` | `+36` |
| `warm` | `0` |
| `cold` | `−36` |

---

## 7. Triadic assembly and audit payload

Per `TRIAD-ORDER-001`:

- `k_A ← geo.k_location`
- `k_B ← k_bat`
- `k_C ← lang.k_language`

**Canonical binding payload** (sorted keys, compact JSON) for `evidence_fingerprint`:

- Includes: `geo_policy`, `geo_grid_step_e7`, `geo_cell_i_lat`, `geo_cell_i_lon`, `geo_cell_hash`, `lang_policy`, `iso639_1`, `lang_tag_hash`, `bat_tier`, `policy_bundle`.

`evidence_fingerprint = first_8_bytes(SHA256(payload_utf8))` as unsigned int.

**Ledger provenance:** call `audit_evidence_binding(result)` to emit a JSON-serializable dict (hex hashes, canonical cell/tag strings, `n_ring`, policies).

---

## 8. Proximity boosts (integer ring steps only)

Applied **after** triadic child `k_*`, in **declaration order**:

```
k_rank = clamp(k_* + Σ Δk_i , −108, 108)
```

- `PBOOST-000` → `0`  
- `PBOOST-COHORT-001` → `(F mod 5) − 2`

Undocumented scalar weights are forbidden.

---

## 9. Reference implementation

`janet_ledger/evidence_triad.py`, `tests/test_evidence_triad.py`.

**Primary API:** `geo_cell_overlay_from_wgs84_e7` → `triadic_parents_from_bound_evidence(geo=..., bat_tier=..., iso639_1_confirmed=...)`.
