# Demo identity — live hardware & production relays

This document norms the **native coordinator** (iOS / Android / Windows / Linux+TPM) that sits **above** `janet_ledger.demo_identity`. The Python package continues to supply **sorted canonical JSON**, **policy codes**, and **state transitions**; it does **not** embed SecKey, Keystore, WebSockets, or relay URLs.

---

## 1. Responsibility split

| Layer | Owns |
|-------|------|
| **OS** | `nonExtractable` secp256k1 (or BIP340-capable) key generation, `DeleteKey`, attestation (DeviceCheck, Play Integrity, TPM quotes). |
| **Coordinator (native)** | WebSocket pool, NIP-01/42 `AUTH` if required, NIP-33/29 publish/subscribe, SQLite/Keychain rows, trigger wiring. |
| **janet_ledger (Python)** | `nip33_*_canonical`, `execute_demo_retirement` ordering contract, `demo_retired_audit_row_canonical`, monotonic policy fields. |

**Forbidden in production demo paths:** in-process “software vaults” holding long-lived demo scalars; `InMemoryDemoKeyVault` is **CI-only** (see `janet_ledger.demo_identity_production.assert_no_ci_memory_vault_in_production`).

---

## 2. Production state machine (fine-grained)

Maps onto `DemoLifecycleState` where noted; native code may track substates before entering `demo_provision`.

```
first_launch
    → hardware_key_gen          [OS: generate demo key; tag DEMO-IDENTITY-001]
    → live_relay_connect        [WS: connect allowlist; NIP-01 OK / NIP-42 AUTH if policy]
    → demo_provision            [DemoLifecycleState.demo_provision: publish NIP-33 d:demo-provision]
    → relay_ping                [DemoLifecycleState.relay_ping: EVENT echo or filter probe]
    → demo_active               [DemoLifecycleState.demo_active: NIP-17/29 on demo_ namespace]
        │
        │ user_initiated_real_identity | family_invite_accepted
        ▼
trigger_capture             [queue single-flight; no new demo publishes]
    → retire_sequence           [atomic sub-steps below]
    → hardware_wipe           [DeleteKey after signed relay ops]
    → retired_final           [DemoLifecycleState.retired_final]
    → relay_disconnect        [close demo pool only; never share sockets with real pool]
    → real_init               [DemoLifecycleState.real_init]
```

**Collision rule:** real identity uses a **separate** relay pool object and **separate** keystore access group / key alias namespace so demo sockets and handles never overlap.

---

## 3. Hardware-backed key generation (pseudocode)

```
// iOS (conceptual)
let tag = "DEMO-IDENTITY-001"
let attrs: [String: Any] = [
  kSecAttrKeyType: kSecAttrKeyTypeECSECPrimeRandom, // or secp256k1-capable path per product choice
  kSecPrivateKeyAttrs: [
    kSecAttrIsPermanent: true,
    kSecAttrAccessControl: SecAccessControlCreateWithFlags(..., .privateKeyUsage, ...),
    kSecAttrApplicationTag: tag.data(using: .utf8)!,
  ],
  kSecAttrKeyClass: kSecAttrKeyClassPrivate,
]
let key = SecKeyCreateRandomKey(attrs as CFDictionary, &err)
// Export pubkey only → hex for janet_ledger payload fields
// Never export nsec / raw scalar
```

Android: `KeyGenParameterSpec.Builder(alias, PURPOSE_SIGN).setIsStrongBoxBacked(true)` when available; alias prefix `demo_` + application id.

Windows: `NCryptCreatePersistedKey` with TPM-backed provider; same non-exportability flags.

Linux: TPM2 `tpm2_create` sealed to policy PCR set appropriate for product; no plain `~/.demo_nsec`.

---

## 4. Live relay pool (pseudocode)

```
class DemoRelayPool:
    urls: [URL]           // user-configured + optional curated defaults from YOUR config server, not hardcoded in janet-ledger
    ws: [WebSocket]
    demo_tag: "demo_"    // filter prefix for subscriptions

    func connect_all():
        for u in urls:
            ws = open(u, subprotocols=["nostr"])
            await handshake_nip01_ok_or_auth(ws, timeout: T_ok)
            assert ws.readyState == OPEN

    func publish_demo_replaceable(kind, d_tag, signed_json):
        assert signed_json.pubkey == demo_pubkey
        send(["EVENT", signed_json])
        await expect_ok_or_event(ws, timeout: T_event)

    func disconnect_all():
        for w in ws: w.close(code=1000, reason="demo_retire")
        ws.clear()
```

**NIP-01:** after `EVENT`, expect `OK` with `true` before advancing local `last_demo_event_id_hex`.

**NIP-42:** if relay returns `AUTH`, complete challenge with **demo** key only; never reuse real pool credentials.

**Resilience:** on disconnect mid-session, **do not** rotate demo keys automatically; reconnect same pool id; if reconnect fails past `N` attempts, surface error **without** wiping hardware key (orphan risk). Only `execute_demo_retirement` path deletes the key.

---

## 5. Atomic teardown (production order)

Extension of `RETIREMENT_STEP_ORDER` — see `janet_ledger.demo_identity_production.RETIREMENT_STEP_ORDER_LIVE`:

1. `build_nip33_demo_retired`  
2. `sign_and_publish_retired` — **hardware** `Sign(SHA256(serialized_unsigned))`  
3. `build_nip29_leave`  
4. `sign_and_publish_leave`  
5. `await_relay_propagation` — optional: re-query until `EVENT` visible on **K** of **N** relays or timeout (product policy)  
6. `delete_demo_key` — `DeleteKey(demo_handle)`  
7. `purge_demo_local_store`  
8. `append_local_audit_demo_retired` — `entry_hash` chain  
9. `disconnect_relay_pool` — close **demo** WebSockets only  

Steps 2–4 **must** complete while the private key still exists in hardware. Step 6 is irreversible; if step 2 fails, **abort** teardown and keep demo active (or app-defined safe mode).

---

## 6. Secure storage layout (production)

| Field | Storage | Notes |
|-------|---------|--------|
| `demo_active` | Keychain/EncryptedPrefs | Bool; false after `retired_final`. |
| `demo_key_handle_id` | Secure enclave alias / TPM name | Opaque; `DEMO-IDENTITY-001` tag in ACL metadata. |
| `demo_pubkey_hex` | Keychain (public only) | For UI + payload builders. |
| `nip29_group_id` | Encrypted DB | Must start `demo_`. |
| `last_demo_event_id_hex` | Encrypted DB | Updated only after relay `OK` + optional `EVENT` echo. |
| `relay_pool_state` | In-memory + small persisted cursor | Last connected URL index for reconnect; **not** secret. |
| Trigger hooks | Main-thread queue | `CREATE_REAL_ACCOUNT` / `ACCEPT_FAMILY_INVITE` single-flight into retire pipeline. |

---

## 7. Live integration test strategy (no default CI dependency)

| Suite | Environment | Assertions |
|-------|-------------|--------------|
| **Unit** | GitHub Actions / local | Canonical JSON, state machine, `InMemoryDemoKeyVault` **only** with `JANET_ALLOW_CI_DEMO_MEMORY_VAULT=1` unset is allowed for memory vault; production guard tests set/unset env. |
| **Hardware lab** | Physical device farm | Key `nonExtractable` attestation; `DeleteKey` → subsequent `Sign` fails. |
| **Relay soak** | Tagged job `relay_live` | Real URLs from CI secret `NOSTR_TEST_RELAYS`; publish provision + retire; wait `OK`/`EVENT` within timeout; verify monotonic counters on relay-returned ids. |
| **Chaos** | Staging | Kill random relay during `demo_active`; ensure no auto-wipe; reconnect succeeds; teardown still completes when user triggers retire. |

Default `pytest` in janet-ledger **does not** open WAN sockets. Live jobs opt in via marker and secrets.

---

## 8. Schnorr / platform note

Same as Nostr handoff: if hardware exposes ECDSA P-256 only, product must document BIP340 bridge; **never** claim hardware Schnorr without API proof.

---

## 9. Cross-references

- Canonical builders: `janet_ledger.demo_identity`  
- Production guard + Protocol names: `janet_ledger.demo_identity_production`  
- Policy BOM includes backtick codes from this doc when referenced in-repo.
