"""
Verified knowledge-gap closure attested as a **badge voucher** on the JANET audit chain.

The ledger records **cryptographic proof** only. Badges / points / UI are issued by
off-ledger engines that verify ``GAP-REWARD-001`` rows and this canonical JSON shape.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from typing import Any, Literal, Sequence, cast

from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001

GAP_REWARD_001 = "GAP-REWARD-001"
"""One voucher row per verified gap closure (dedup by coordinator using ``gap_reward_dedup_key``)."""

BADGE_ATTEST_001 = "BADGE-ATTEST-001"
"""Payload includes ``badge_slug`` attesting which badge the settlement engine may grant."""

_SCHEMA = "janet_gap_reward_badge_v1"

_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_HEX128 = re.compile(r"^[0-9a-f]{128}$")
_BADGE_SLUG = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}[a-z0-9]$|^[a-z0-9]{1,64}$")


def _hex64(name: str, value: str) -> str:
    v = value.lower()
    if not _HEX64.match(v):
        raise ValueError(f"{name} must be 64 lowercase hex chars")
    return v


def _sorted_policies(codes: Sequence[str]) -> list[str]:
    if not codes:
        raise ValueError("janet_policy_codes must be non-empty")
    out = sorted({str(c).strip() for c in codes if str(c).strip()})
    if not out:
        raise ValueError("janet_policy_codes must be non-empty")
    return out


def _sorted_quorum_sigs(sigs: Sequence[str]) -> list[str]:
    out: list[str] = []
    for i, s in enumerate(sigs):
        v = s.lower().strip()
        if not _HEX128.match(v):
            raise ValueError(f"quorum_sigs[{i}] must be 128 lowercase hex chars (Schnorr wire sig)")
        out.append(v)
    return sorted(out)


def _normalize_badge_slug(slug: str) -> str:
    s = slug.strip().lower()
    if not s or len(s) > 64:
        raise ValueError("badge_slug must be 1..64 chars after trim")
    if not _BADGE_SLUG.match(s):
        raise ValueError("badge_slug must be lowercase [a-z0-9-] with no leading/trailing hyphen")
    return s


def assert_verifier_passed_before_reward(verifier_result: str) -> None:
    """Coordinator MUST call this (or equivalent) before emitting a reward row."""
    if verifier_result.upper() != "PASS":
        raise ValueError("verifier_result must be PASS before GAP-REWARD-001 badge voucher")


def gap_reward_dedup_key(*, triad_hash_hex: str, badge_slug: str) -> str:
    """Stable key for local dedup: one voucher per triad + badge class (coordinator policy)."""
    return f"{_hex64('triad_hash_hex', triad_hash_hex)}:{_normalize_badge_slug(badge_slug)}"


def gap_reward_badge_payload_canonical(
    *,
    gap_id: str,
    triad_hash: str,
    binder_pubkey_hex: str,
    badge_slug: str,
    quorum_sigs: Sequence[str],
    verifier_result: Literal["PASS"],
    epoch: int,
    prev_event_id: str,
    janet_policy_codes: Sequence[str] | None = None,
    monotonic_counter: int | None = None,
) -> str:
    """
    Sorted JSON for NIP-33 ``d: gap-closed`` **content** (or local audit mirror).

    ``gap_id`` / ``triad_hash`` / ``prev_event_id`` / ``binder_pubkey_hex`` are 64-hex.
    ``quorum_sigs`` are Schnorr signatures (128-hex each), sorted for determinism.
    """
    assert_verifier_passed_before_reward(verifier_result)
    pol = _sorted_policies(
        janet_policy_codes
        or (GAP_REWARD_001, BADGE_ATTEST_001, NIP33_JANET_CONTENT_001)
    )
    for req in (GAP_REWARD_001, BADGE_ATTEST_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if not isinstance(epoch, int) or epoch < 0:
        raise ValueError("epoch must be int >= 0")
    if monotonic_counter is not None and (not isinstance(monotonic_counter, int) or monotonic_counter < 0):
        raise ValueError("monotonic_counter must be int >= 0 or None")
    if not quorum_sigs:
        raise ValueError("quorum_sigs must be non-empty")
    obj: dict[str, Any] = {
        "badge_slug": _normalize_badge_slug(badge_slug),
        "binder_pubkey_hex": _hex64("binder_pubkey_hex", binder_pubkey_hex),
        "epoch": int(epoch),
        "gap_id": _hex64("gap_id", gap_id),
        "janet_policy_codes": pol,
        "prev_event_id": _hex64("prev_event_id", prev_event_id),
        "quorum_sigs": _sorted_quorum_sigs(quorum_sigs),
        "schema": _SCHEMA,
        "triad_hash": _hex64("triad_hash", triad_hash),
        "verifier_result": verifier_result,
    }
    if monotonic_counter is not None:
        obj["monotonic_counter"] = int(monotonic_counter)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def verify_gap_reward_voucher_canonical(canonical_json: str) -> dict[str, Any]:
    """
    Parse a coordinator-emitted voucher string and ensure it is **bit-identical**
    to the output of :func:`gap_reward_badge_payload_canonical` (no extra keys,
    correct ordering via canonical equality).
    """
    raw = canonical_json.strip()
    obj = json.loads(raw)
    if not isinstance(obj, Mapping):
        raise ValueError("voucher must be a JSON object")
    if obj.get("schema") != _SCHEMA:
        raise ValueError(f"schema must be {_SCHEMA!r}")
    try:
        pol = obj["janet_policy_codes"]
        mc = obj.get("monotonic_counter")
        rebuilt = gap_reward_badge_payload_canonical(
            gap_id=str(obj["gap_id"]),
            triad_hash=str(obj["triad_hash"]),
            binder_pubkey_hex=str(obj["binder_pubkey_hex"]),
            badge_slug=str(obj["badge_slug"]),
            quorum_sigs=list(obj["quorum_sigs"]),
            verifier_result=cast(Literal["PASS"], str(obj["verifier_result"])),
            epoch=int(obj["epoch"]),
            prev_event_id=str(obj["prev_event_id"]),
            janet_policy_codes=list(pol) if pol is not None else None,
            monotonic_counter=int(mc) if mc is not None else None,
        )
    except (KeyError, TypeError, ValueError) as e:
        raise ValueError(f"invalid GAP-REWARD-001 voucher: {e}") from e
    if rebuilt != raw:
        raise ValueError("canonical JSON mismatch (tampering or non-canonical input)")
    return dict(obj)
