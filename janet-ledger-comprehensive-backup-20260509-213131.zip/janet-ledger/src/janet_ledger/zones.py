"""Zone routing per FINAL spec + ZONE-TIE-001 at c = -25."""

from __future__ import annotations


def route_zone(c: float, *, tie_coord: float = -25.0) -> str:
    """
    Half-open / closed composition.

    ``tie_coord`` defaults to **-25** (ZONE-TIE-001). Override via manifest ``policy_config``.
    """
    if c <= -75:
        return "Fundamental"
    if c <= -50:
        return "Structural"
    if c < tie_coord:
        return "Categorical"
    if c == tie_coord:
        return "Attributive"  # ZONE-TIE-001
    if c < 0:
        return "Attributive"
    if c <= 25:
        return "Definitional"
    if c <= 50:
        return "Compositional"
    if c <= 75:
        return "Instantial"
    return "Expressive"


def route_zone_with_tie_meta(c: float, *, tie_coord: float = -25.0) -> tuple[str, bool]:
    """Returns (zone, tie_break_applied)."""
    tie = c == float(tie_coord)
    return route_zone(c, tie_coord=tie_coord), tie
