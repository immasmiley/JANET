"""
HITL pattern knowledge: immutable ledger events + convergence + audit bundles.

Intelligence = auditable coverage growth: explicit overrides, no hidden weights,
deterministic payloads suitable for the same SHA-256 ledger chain as core rows.

Event types:
  - ``pattern_observation``: one HITL-validated coordinate→frame override.
  - ``pattern_confirmed``: emitted once when ≥3 *distinct* sessions share the
    same ``coord_frame_v1`` mapping (canonical key digest).

DAG edges are prior **64-hex ledger entry hashes** (``parent_entry_hashes`` /
``parent_observation_entry_hashes``). Sub-lattice recursion is an optional dotted
path string (default ``"0"`` = root overlay) without growing runtime deps.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any, Sequence

SCHEMA_HITL_KNOWLEDGE_V1 = "hitl_knowledge_v1"
EVENT_PATTERN_OBSERVATION = "pattern_observation"
EVENT_PATTERN_CONFIRMED = "pattern_confirmed"
COORD_FRAME_MAPPING_SCHEMA = "coord_frame_v1"

_HEX64 = re.compile(r"^[0-9a-f]{64}$")


def mapping_key_digest(mapping_key_canonical_utf8: str) -> str:
    """SHA-256 hex of the canonical coord→frame key string (stable id)."""
    return hashlib.sha256(mapping_key_canonical_utf8.encode("utf-8")).hexdigest()


def coord_frame_mapping_canonical(*, frame_id: str, geo_cell_sha256_hex: str) -> str:
    """
    Canonical **coord → frame** identity for convergence (no raw coordinates).

    ``geo_cell_sha256_hex`` must be the 64-char lowercase hex from GEO-PROJ-001.
    """
    g = geo_cell_sha256_hex.lower()
    if not _HEX64.match(g):
        raise ValueError("geo_cell_sha256_hex must be 64 lowercase hex chars")
    obj: dict[str, Any] = {
        "frame_id": frame_id,
        "geo_cell_sha256_hex": g,
        "mapping_schema": COORD_FRAME_MAPPING_SCHEMA,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def _sorted_hex_parents(parents: Sequence[str]) -> list[str]:
    out = [p.lower() for p in parents]
    for p in out:
        if not _HEX64.match(p):
            raise ValueError("parent_entry_hashes must be 64-char lowercase hex")
    return sorted(out)


def pattern_observation_payload(
    *,
    hitl_token: str,
    session_id: str,
    frame_id: str,
    geo_cell_sha256_hex: str,
    triad_evidence_fingerprint: int,
    k_a: int,
    k_b: int,
    k_c: int,
    k_rank: int,
    parent_entry_hashes: Sequence[str],
    sub_lattice_path: str = "0",
) -> str:
    """
    Canonical JSON for one ``pattern_observation`` ledger row (UTF-8 sorted keys).

    Links to the δ-line via integer ``k_*`` and to triadic audit via
    ``triad_evidence_fingerprint`` (same UInt64 as ``EvidenceTriadResult``).
    """
    if not hitl_token.strip():
        raise ValueError("hitl_token must be non-empty")
    if not session_id.strip():
        raise ValueError("session_id must be non-empty")
    if not frame_id.strip():
        raise ValueError("frame_id must be non-empty")
    if not sub_lattice_path.strip():
        raise ValueError("sub_lattice_path must be non-empty")
    mk = coord_frame_mapping_canonical(frame_id=frame_id, geo_cell_sha256_hex=geo_cell_sha256_hex)
    obj: dict[str, Any] = {
        "event_type": EVENT_PATTERN_OBSERVATION,
        "frame_id": frame_id,
        "geo_cell_sha256_hex": geo_cell_sha256_hex.lower(),
        "hitl_token": hitl_token,
        "k_a": int(k_a),
        "k_b": int(k_b),
        "k_c": int(k_c),
        "k_rank": int(k_rank),
        "mapping_key_canonical": mk,
        "mapping_key_sha256": mapping_key_digest(mk),
        "parent_entry_hashes": _sorted_hex_parents(parent_entry_hashes),
        "schema": SCHEMA_HITL_KNOWLEDGE_V1,
        "session_id": session_id,
        "sub_lattice_path": sub_lattice_path,
        "triad_evidence_fingerprint": int(triad_evidence_fingerprint),
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def pattern_confirmed_payload(
    *,
    mapping_key_canonical: str,
    session_ids: Sequence[str],
    parent_observation_entry_hashes: Sequence[str],
    triad_evidence_fingerprint: int,
    k_rank: int,
    sub_lattice_path: str = "0",
) -> str:
    """
    Canonical JSON for ``pattern_confirmed`` (one row appended to the ledger).

    Emitted when convergence criteria are met (see ``pattern_state_after_observation``).
    """
    if not sub_lattice_path.strip():
        raise ValueError("sub_lattice_path must be non-empty")
    mk = mapping_key_canonical
    d = mapping_key_digest(mk)
    sess = sorted({s.strip() for s in session_ids if s.strip()})
    if len(sess) < 3:
        raise ValueError("pattern_confirmed requires at least 3 distinct session_ids")
    obj: dict[str, Any] = {
        "distinct_session_count": len(sess),
        "event_type": EVENT_PATTERN_CONFIRMED,
        "k_rank": int(k_rank),
        "mapping_key_canonical": mk,
        "mapping_key_sha256": d,
        "parent_observation_entry_hashes": _sorted_hex_parents(parent_observation_entry_hashes),
        "schema": SCHEMA_HITL_KNOWLEDGE_V1,
        "session_ids": sess,
        "sub_lattice_path": sub_lattice_path,
        "triad_evidence_fingerprint": int(triad_evidence_fingerprint),
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


@dataclass(frozen=True)
class PatternConvergenceState:
    """
    Immutable snapshot: per mapping digest, distinct sessions and observation row
    hashes appended in arrival order.
    """

    # digest -> (frozenset sessions, tuple of observation entry_hash in order)
    rows: tuple[tuple[str, frozenset[str], tuple[str, ...]], ...]
    confirmed_digests: frozenset[str]


def pattern_state_initial() -> PatternConvergenceState:
    return PatternConvergenceState((), frozenset())


def _rows_as_dict(state: PatternConvergenceState) -> dict[str, tuple[set[str], list[str]]]:
    out: dict[str, tuple[set[str], list[str]]] = {}
    for digest, sessions, hashes in state.rows:
        out[digest] = (set(sessions), list(hashes))
    return out


def _dict_to_rows(d: dict[str, tuple[set[str], list[str]]]) -> tuple[tuple[str, frozenset[str], tuple[str, ...]], ...]:
    return tuple(
        (digest, frozenset(sessions), tuple(hashes))
        for digest, (sessions, hashes) in sorted(d.items(), key=lambda x: x[0])
    )


def pattern_state_after_observation(
    state: PatternConvergenceState,
    *,
    mapping_key_canonical: str,
    session_id: str,
    observation_entry_hash: str,
    triad_evidence_fingerprint: int,
    k_rank: int,
    sub_lattice_path: str = "0",
) -> tuple[PatternConvergenceState, str | None]:
    """
    Record one validated observation in memory.

    Returns ``(new_state, confirmed_payload_or_none)``.
    ``confirmed_payload`` is non-None exactly **once** when the set of *distinct*
    ``session_id`` values for that mapping digest first reaches **3**. The
    confirming row uses ``triad_evidence_fingerprint`` and ``k_rank`` from **this**
    call (the HITL observation that completed the quorum).

    Coordinators must persist ``confirmed_digests`` with the ledger so restarts
    do not double-emit ``pattern_confirmed``.
    """
    if not session_id.strip():
        raise ValueError("session_id must be non-empty")
    obs = observation_entry_hash.lower()
    if not _HEX64.match(obs):
        raise ValueError("observation_entry_hash must be 64 lowercase hex chars")
    digest = mapping_key_digest(mapping_key_canonical)
    d = _rows_as_dict(state)
    if digest not in d:
        d[digest] = (set(), [])
    sessions, hashes = d[digest]
    sessions = set(sessions)
    sessions.add(session_id.strip())
    hashes = list(hashes)
    hashes.append(obs)
    d[digest] = (sessions, hashes)

    confirmed_json: str | None = None
    new_confirmed = set(state.confirmed_digests)
    if len(sessions) >= 3 and digest not in state.confirmed_digests:
        new_confirmed.add(digest)
        confirmed_json = pattern_confirmed_payload(
            mapping_key_canonical=mapping_key_canonical,
            session_ids=sorted(sessions),
            parent_observation_entry_hashes=hashes,
            triad_evidence_fingerprint=triad_evidence_fingerprint,
            k_rank=k_rank,
            sub_lattice_path=sub_lattice_path,
        )

    new_state = PatternConvergenceState(_dict_to_rows(d), frozenset(new_confirmed))
    return new_state, confirmed_json


def audit_bundle_canonical(*, event_payload_json_strings: Sequence[str]) -> str:
    """
    Deterministic bundle of independent canonical event JSON strings (sorted).

    Use for export / handoff: same multiset of events → same bundle string.
    Empty input yields an empty ``events`` list.
    """
    obj: dict[str, Any] = {
        "audit_bundle_schema": "audit_bundle_v1",
        "events": sorted(event_payload_json_strings),
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))
