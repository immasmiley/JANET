"""
Local **settlement engine stub** for ``GAP-REWARD-001`` end-to-end checks.

This is **not** a production issuer: no Schnorr verification, no relay I/O.
It re-validates the canonical voucher shape, applies a **demo hash-chain**
(``prev_event_id`` must link to the previous settled voucher's content hash,
or to the genesis digest on first mint), dedups on ``triad:slug``, and writes
a JSON badge file under ``out_dir / "badges"``.
"""

from __future__ import annotations

import hashlib
import json
import re
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from janet_ledger.gap_reward import (
    gap_reward_dedup_key,
    verify_gap_reward_voucher_canonical,
)
from janet_ledger.pwa_gap_bridge import parse_desktop_settlement_http_body

STUB_ROOT_PREV = "0" * 64
"""First voucher in a fresh data dir must use this ``prev_event_id`` (stub chain genesis)."""

MINT_SCHEMA = "janet_settlement_test_badge_v1"

_CHAIN_STATE = "chain_state.json"
_BADGES_DIR = "badges"


@lru_cache(maxsize=1)
def _qrcode_vendor_js() -> bytes:
    """Vendored qrcodejs (MIT) for the /test page; works offline after install."""
    return resources.files("janet_ledger").joinpath("static", "qrcode.min.js").read_bytes()


_TEST_PAGE_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<meta name="color-scheme" content="light dark"/>
<title>JANET settlement stub</title>
<style>
:root{
  --bg:#f8fafc;--card:#fff;--text:#0f172a;--muted:#64748b;--border:#e2e8f0;
  --accent:#2563eb;--accent-hi:#1d4ed8;--ok:#15803d;--err:#b91c1c;
}
@media (prefers-color-scheme: dark){
  :root{--bg:#0f172a;--card:#1e293b;--text:#f1f5f9;--muted:#94a3b8;--border:#334155;
        --accent:#60a5fa;--accent-hi:#93c5fd;--ok:#4ade80;--err:#f87171;}
}
*{box-sizing:border-box;}
body{
  font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  margin:0;padding:1rem 1rem 2rem;background:var(--bg);color:var(--text);
  line-height:1.45;
}
.wrap{max-width:56rem;margin:0 auto;}
header{margin-bottom:1.25rem;}
header h1{font-size:1.35rem;font-weight:700;margin:0 0 .35rem;}
header p{margin:0;color:var(--muted);font-size:.95rem;}
.grid{
  display:grid;gap:1rem;
  grid-template-columns:minmax(0,1fr);
}
@media(min-width:720px){
  .grid{grid-template-columns:minmax(220px,280px) minmax(0,1fr);}
}
.card{
  background:var(--card);border:1px solid var(--border);border-radius:12px;
  padding:1rem 1.1rem;box-shadow:0 1px 2px rgba(15,23,42,.06);
}
.card h2{font-size:1rem;margin:0 0 .65rem;font-weight:600;}
.qrbox{
  display:flex;justify-content:center;align-items:center;
  min-height:212px;padding:.5rem;background:var(--bg);border-radius:8px;border:1px dashed var(--border);
}
.qrbox table{margin:0 auto;}
.url-line{
  word-break:break-all;font-size:.8rem;font-family:ui-monospace,monospace;
  background:var(--bg);padding:.5rem .6rem;border-radius:8px;border:1px solid var(--border);
  margin:.5rem 0;
}
.btnrow{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin-top:.5rem;}
button,.btnlink{
  font:inherit;cursor:pointer;border-radius:8px;padding:.5rem .85rem;
  border:1px solid var(--border);background:var(--card);color:var(--text);
}
button.primary,.btnlink.primary{
  background:var(--accent);border-color:var(--accent-hi);color:#fff;font-weight:600;
}
button.primary:hover{background:var(--accent-hi);}
.hint{font-size:.8rem;color:var(--muted);margin:.35rem 0 0;}
.err{font-size:.8rem;color:var(--err);min-height:1.2em;}
label{display:block;margin:.75rem 0 .35rem;font-weight:600;font-size:.9rem;}
pre{
  background:#111;color:#eee;padding:.85rem;border-radius:8px;overflow:auto;
  font-size:.78rem;max-height:22rem;margin:0;
}
textarea{
  width:100%;min-height:7rem;font-family:ui-monospace,monospace;font-size:.78rem;
  padding:.6rem;border-radius:8px;border:1px solid var(--border);background:var(--card);color:var(--text);
}
#copyHint{font-size:.8rem;color:var(--ok);margin-left:.25rem;}
</style>
</head>
<body>
<div class="wrap">
<header>
<h1>JANET settlement stub</h1>
<p>Local dev helper: health check, voucher POST, and a scannable link to this page.</p>
</header>
<div class="grid">
<section class="card">
<h2>Open on another device</h2>
<p class="hint" style="margin-top:0">Scan to open this test page in a phone browser.</p>
<div id="qr" class="qrbox" aria-label="QR code for this page URL"></div>
<p id="qrErr" class="err" role="status"></p>
<p class="hint"><strong>Tip:</strong> <code>127.0.0.1</code> only reaches this machine. To scan from a phone on Wi‑Fi, run the stub with <code>--host 0.0.0.0</code> and open <code>http://&lt;your-PC-LAN-IP&gt;:&lt;port&gt;/test</code> (then refresh this page on the PC so the QR matches).</p>
<div class="url-line" id="pageUrl"></div>
<div class="btnrow">
<button type="button" class="primary" id="copyUrlBtn">Copy page link</button>
<span id="copyHint"></span>
</div>
<p class="hint">JSON: <code id="origin"></code></p>
</section>
<section class="card">
<h2>Try the API</h2>
<div class="btnrow">
<button type="button" class="primary" id="btnHealth">GET /health</button>
<button type="button" id="btnPost">POST /webhooks/gap-reward</button>
</div>
<label for="body">Voucher POST body</label>
<p class="hint" style="margin-top:0">Paste raw canonical JSON, or <code>{"voucher_canonical":"..."}</code>, or Desktop dispatch with <code>desktop_schnorr_sig_hex</code> (stub checks length only).</p>
<textarea id="body" placeholder="Paste voucher JSON here"></textarea>
<label for="out">Response</label>
<pre id="out">Use the buttons above. POST sends JSON: if the textarea does not start with <code>{</code>, it is wrapped as <code>{"voucher_canonical": ...}</code>.</pre>
</section>
</div>
</div>
<script src="/static/qrcode.min.js"></script>
<script>
(function(){
  var pageUrl = location.href.split("#")[0];
  document.getElementById("pageUrl").textContent = pageUrl;
  document.getElementById("origin").textContent = location.origin;
  function showCopy(msg){
    var el = document.getElementById("copyHint");
    el.textContent = msg;
    clearTimeout(showCopy._t);
    showCopy._t = setTimeout(function(){ el.textContent = ""; }, 2800);
  }
  document.getElementById("copyUrlBtn").onclick = function(){
    if(navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(pageUrl).then(function(){
        showCopy("Copied.");
      }).catch(function(){
        showCopy("Select the URL in the box and copy manually.");
      });
    }else{
      showCopy("Select the URL in the box and copy manually.");
    }
  };
  function paintQr(){
    var err = document.getElementById("qrErr");
    if(typeof QRCode === "undefined"){
      err.textContent = "QR library failed to load.";
      return;
    }
    err.textContent = "";
    var host = document.getElementById("qr");
    host.innerHTML = "";
    try{
      new QRCode(host, {
        text: pageUrl,
        width: 200,
        height: 200,
        colorDark: "#0f172a",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.M
      });
    }catch(e){
      err.textContent = "Could not build QR: " + (e && e.message ? e.message : String(e));
    }
  }
  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", paintQr);
  }else{
    paintQr();
  }
  document.getElementById("btnHealth").onclick = function(){
    fetch("/health").then(function(r){
      return r.text().then(function(t){
        document.getElementById("out").textContent = r.status + " " + r.statusText + "\\n" + t;
      });
    }).catch(function(e){
      document.getElementById("out").textContent = "Request failed: " + e;
    });
  };
  document.getElementById("btnPost").onclick = function(){
    var raw = document.getElementById("body").value.trim();
    if(!raw){
      document.getElementById("out").textContent = "Paste a body first.";
      return;
    }
    var payload = raw.charAt(0) === "{" ? raw : JSON.stringify({ voucher_canonical: raw });
    fetch("/webhooks/gap-reward", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: payload
    }).then(function(r){
      return r.text().then(function(t){
        document.getElementById("out").textContent = r.status + " " + r.statusText + "\\n" + t;
      });
    }).catch(function(e){
      document.getElementById("out").textContent = "Request failed: " + e;
    });
  };
})();
</script>
</body>
</html>
"""


def _content_hash_hex(canonical_json: str) -> str:
    return hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()


def _safe_dedup_filename(dedup_key: str) -> str:
    return re.sub(r"[^0-9a-f:_-]", "_", dedup_key, flags=re.I)


@dataclass(frozen=True)
class SettlementDecision:
    http_status: int
    payload: dict[str, Any]


def load_chain_state(out_dir: Path) -> str | None:
    p = out_dir / _CHAIN_STATE
    if not p.is_file():
        return None
    data = json.loads(p.read_text(encoding="utf-8"))
    last = data.get("last_settled_content_hash")
    if last is None:
        return None
    s = str(last).lower()
    if len(s) != 64 or any(c not in "0123456789abcdef" for c in s):
        raise ValueError("chain_state.json: invalid last_settled_content_hash")
    return s


def save_chain_state(out_dir: Path, content_hash_hex: str) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / _CHAIN_STATE).write_text(
        json.dumps({"last_settled_content_hash": content_hash_hex}, sort_keys=True, indent=2)
        + "\n",
        encoding="utf-8",
    )


def mint_local_test_badge(
    *,
    voucher: dict[str, Any],
    voucher_canonical: str,
    out_dir: Path,
) -> Path:
    """Write ``janet_settlement_test_badge_v1`` JSON next to the voucher hash."""
    badges = out_dir / _BADGES_DIR
    badges.mkdir(parents=True, exist_ok=True)
    dedup = gap_reward_dedup_key(
        triad_hash_hex=str(voucher["triad_hash"]),
        badge_slug=str(voucher["badge_slug"]),
    )
    path = badges / f"{_safe_dedup_filename(dedup)}.json"
    ch = _content_hash_hex(voucher_canonical)
    record = {
        "binder_pubkey_hex": voucher["binder_pubkey_hex"],
        "dedup_key": dedup,
        "gap_id": voucher["gap_id"],
        "granted_slug": voucher["badge_slug"],
        "schema": MINT_SCHEMA,
        "settled_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "source_voucher_content_hash": ch,
        "triad_hash": voucher["triad_hash"],
    }
    path.write_text(json.dumps(record, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return path


def settle_gap_reward_voucher(
    *,
    voucher_canonical: str,
    out_dir: Path,
) -> SettlementDecision:
    """
    Structural verification + stub chain + dedup. Returns HTTP-shaped status for the listener.
    """
    try:
        voucher = verify_gap_reward_voucher_canonical(voucher_canonical)
    except (json.JSONDecodeError, ValueError) as e:
        return SettlementDecision(400, {"ok": False, "error": str(e)})

    dedup = gap_reward_dedup_key(
        triad_hash_hex=str(voucher["triad_hash"]),
        badge_slug=str(voucher["badge_slug"]),
    )
    badge_path = out_dir / _BADGES_DIR / f"{_safe_dedup_filename(dedup)}.json"
    if badge_path.is_file():
        return SettlementDecision(
            409,
            {"ok": False, "error": "duplicate settlement for triad:slug", "dedup_key": dedup},
        )

    expected_prev = load_chain_state(out_dir)
    prev = str(voucher["prev_event_id"]).lower()
    if expected_prev is None:
        if prev != STUB_ROOT_PREV:
            return SettlementDecision(
                400,
                {
                    "ok": False,
                    "error": f"first mint must use prev_event_id == {STUB_ROOT_PREV!r} (stub genesis)",
                },
            )
    else:
        if prev != expected_prev:
            return SettlementDecision(
                400,
                {
                    "ok": False,
                    "error": "prev_event_id does not match stub chain head (expected prior voucher content hash)",
                    "expected_prev_event_id": expected_prev,
                },
            )

    try:
        path = mint_local_test_badge(
            voucher=voucher,
            voucher_canonical=voucher_canonical.strip(),
            out_dir=out_dir,
        )
    except OSError as e:
        return SettlementDecision(500, {"ok": False, "error": str(e)})

    save_chain_state(out_dir, _content_hash_hex(voucher_canonical.strip()))
    return SettlementDecision(
        200,
        {
            "ok": True,
            "badge_path": str(path.resolve()),
            "dedup_key": dedup,
            "voucher_content_hash": _content_hash_hex(voucher_canonical.strip()),
        },
    )


def parse_settlement_post_body(body: bytes) -> str:
    """
    Accept:
    - raw UTF-8 ``voucher_canonical`` string
    - ``{\"voucher_canonical\": \"...\"}`` (legacy)
    - ``{\"settlement_dispatch_canonical\": \"...\", \"desktop_schnorr_sig_hex\": \"128hex\"}``
      (Desktop-only path; stub checks **format** of sig, not secp).
    """
    text = body.decode("utf-8").strip()
    if not text:
        raise ValueError("empty body")
    if text.startswith("{"):
        obj = json.loads(text)
        if isinstance(obj, dict) and "settlement_dispatch_canonical" in obj:
            vc, sig = parse_desktop_settlement_http_body(body)
            if not sig:
                raise ValueError("desktop_schnorr_sig_hex required with settlement_dispatch_canonical")
            return vc
        if isinstance(obj, dict) and "voucher_canonical" in obj:
            inner = obj["voucher_canonical"]
            if not isinstance(inner, str):
                raise ValueError("voucher_canonical must be a string")
            return inner
    return text


def make_handler(out_dir: Path) -> type[BaseHTTPRequestHandler]:
    out_abs = out_dir.resolve()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:  # noqa: A003
            return

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/static/qrcode.min.js":
                try:
                    data = _qrcode_vendor_js()
                except OSError:
                    self._send_json(500, {"ok": False, "error": "missing vendored qrcode.min.js"})
                    return
                self.send_response(200)
                self.send_header("Content-Type", "application/javascript; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "public, max-age=86400")
                self.end_headers()
                self.wfile.write(data)
                return
            if parsed.path == "/test":
                data = _TEST_PAGE_HTML.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            if parsed.path in ("/health", "/"):
                self._send_json(200, {"ok": True, "service": "janet-settlement-stub"})
                return
            self._send_json(404, {"ok": False, "error": "not found"})

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path not in ("/webhooks/gap-reward", "/"):
                self._send_json(404, {"ok": False, "error": "not found"})
                return
            length = int(self.headers.get("Content-Length", "0") or 0)
            body = self.rfile.read(length) if length > 0 else b""
            try:
                canonical = parse_settlement_post_body(body)
            except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as e:
                self._send_json(400, {"ok": False, "error": str(e)})
                return
            decision = settle_gap_reward_voucher(voucher_canonical=canonical, out_dir=out_abs)
            self._send_json(decision.http_status, decision.payload)

        def _send_json(self, status: int, obj: dict[str, Any]) -> None:
            data = json.dumps(obj, sort_keys=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    return Handler


def run_stub_server(
    host: str,
    port: int,
    out_dir: Path,
    *,
    shutdown_event: threading.Event | None = None,
) -> ThreadingHTTPServer:
    """Start ``ThreadingHTTPServer``; caller runs ``serve_forever`` or uses tests."""
    out_dir.mkdir(parents=True, exist_ok=True)
    handler = make_handler(out_dir)
    server = ThreadingHTTPServer((host, port), handler)
    if shutdown_event is not None:

        def _watch() -> None:
            shutdown_event.wait()
            server.shutdown()

        threading.Thread(target=_watch, daemon=True).start()
    return server


def main(argv: list[str] | None = None) -> None:
    import argparse

    p = argparse.ArgumentParser(description="JANET GAP-REWARD-001 settlement stub (local JSON badges)")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument(
        "--out-dir",
        type=Path,
        default=Path("settlement_data"),
        help="Badge files and chain_state.json",
    )
    ns = p.parse_args(argv)
    out = ns.out_dir.resolve()
    srv = run_stub_server(ns.host, ns.port, out)
    print(
        f"settlement stub  UI: http://{ns.host}:{ns.port}/test  "
        f"static: http://{ns.host}:{ns.port}/static/qrcode.min.js  "
        f"POST http://{ns.host}:{ns.port}/webhooks/gap-reward  (out_dir={out})"
    )
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
