"""Convergence predicates from TEST_MANIFEST."""

from __future__ import annotations

from janet_ledger.policy_config import PolicyConfig


def convergence_strict(sessions: list[dict]) -> bool:
    ks = [int(s["k_final"]) for s in sessions]
    if len(ks) < 3:
        return False
    return len(set(ks)) == 1


def convergence_adj001(sessions: list[dict]) -> bool:
    """CONV-ADJ-001: all k within 1 of median of three."""
    ks = sorted(int(s["k_final"]) for s in sessions)
    if len(ks) < 3:
        return False
    k_star = ks[1]
    return all(abs(k - k_star) <= 1 for k in ks)


def evaluate_scenario(scenario: dict, policy_config: PolicyConfig | None = None) -> bool:
    """
    Evaluate one manifest-style scenario.

    If ``policy_config.convergence_default_active_policy`` is set and the scenario
    has no ``active_policy``, the default is applied (policy-as-config).
    """
    s = dict(scenario)
    sessions = s["sessions"]
    policy = s.get("active_policy")
    if policy is None and policy_config is not None:
        dap = policy_config.convergence_default_active_policy
        if dap:
            policy = dap
    if policy == "CONV-ADJ-001":
        return convergence_adj001(sessions)
    return convergence_strict(sessions)
