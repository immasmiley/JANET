"""What-if convergence: ``python -m janet_ledger.whatif`` (no storage)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from janet_ledger.convergence import evaluate_scenario
from janet_ledger.policy_config import policy_config_from_manifest


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Evaluate one convergence scenario (manifest shape).")
    p.add_argument(
        "--scenario-json",
        required=True,
        help='JSON object or array, e.g. \'{"sessions":[...]}\' or \'[{"session_id":"A","k_final":17},...]\'',
    )
    p.add_argument(
        "--policy-manifest",
        type=Path,
        default=None,
        help="Optional full manifest JSON to read policy_config (convergence defaults, zone tie).",
    )
    args = p.parse_args(argv)
    raw = json.loads(args.scenario_json)
    if isinstance(raw, list):
        scenario: dict = {"sessions": raw}
    else:
        scenario = raw
    pc = None
    if args.policy_manifest is not None:
        root = json.loads(args.policy_manifest.read_text(encoding="utf-8"))
        pc = policy_config_from_manifest(root)
    result = evaluate_scenario(scenario, pc)
    print(json.dumps({"converged": result}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
