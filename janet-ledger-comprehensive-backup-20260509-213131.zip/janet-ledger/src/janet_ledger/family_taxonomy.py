"""Canonical 31 relationship types (Family Graph2 / family-taxonomy.js)."""

from __future__ import annotations

from enum import IntEnum


class RelationshipType(IntEnum):
    ADOPTIVE_CHILD = 1
    PARENT = 2
    GRANDPARENT = 3
    GREAT_GRANDPARENT = 4
    GREAT2_GRANDPARENT = 5
    GREAT3_GRANDPARENT = 6
    STEP_PARENT = 7
    ADOPTIVE_PARENT = 8
    FOSTER_PARENT = 9
    GUARDIAN = 10
    CHILD = 11
    GRANDCHILD = 12
    GREAT_GRANDCHILD = 13
    GREAT2_GRANDCHILD = 14
    GREAT3_GRANDCHILD = 15
    STEP_CHILD = 16
    FOSTER_CHILD = 17
    WARD = 18
    GODCHILD = 19
    GODPARENT = 20
    SIBLING = 21
    HALF_SIBLING = 22
    STEP_SIBLING = 23
    COUSIN_FIRST = 24
    COUSIN_SECOND = 25
    COUSIN_REMOVED = 26
    AUNT_UNCLE = 27
    NIECE_NEPHEW = 28
    GRAND_NIECE_NEPHEW = 29
    PARENT_IN_LAW = 30
    SIBLING_IN_LAW = 31


REL_TYPE_NAMES: dict[int, str] = {int(v): k for k, v in RelationshipType.__members__.items()}

REL_CATEGORIES: dict[str, tuple[str, tuple[int, int]]] = {
    "ancestors": ("Parents & Ancestors", (1, 10)),
    "descendants": ("Children & Descendants", (11, 20)),
    "lateral": ("Siblings & Lateral", (21, 29)),
    "inlaws": ("In-Laws", (30, 31)),
}


def is_valid_rel_type(rel_type: int) -> bool:
    return isinstance(rel_type, int) and 1 <= rel_type <= 31


def category_of(rel_type_id: int) -> str | None:
    for key, (_label, (lo, hi)) in REL_CATEGORIES.items():
        if lo <= rel_type_id <= hi:
            return key
    return None


def types_in_category(cat: str) -> list[int]:
    entry = REL_CATEGORIES.get(cat)
    if not entry:
        return []
    _label, (lo, hi) = entry
    return list(range(lo, hi + 1))


def rel_type_name(rel_id: int) -> str | None:
    return REL_TYPE_NAMES.get(rel_id)


def rel_type_label(rel_id: int) -> str | None:
    n = rel_type_name(rel_id)
    if not n:
        return None
    return n.lower().replace("_", " ").title()
