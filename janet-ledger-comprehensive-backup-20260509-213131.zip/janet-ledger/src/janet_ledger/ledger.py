"""SHA-256 ledger step matching TEST_MANIFEST golden vectors."""

from __future__ import annotations

import hashlib


def entry_hash(prev_hash_hex: str, payload_canonical_utf8: str) -> str:
    """
    entry_hash = SHA-256( (prev_hash_hex || payload_canonical) encoded as UTF-8 ).

    Per TEST_MANIFEST golden vector: ``prev_hash`` is the 64-char lowercase hex
    *string* (genesis zeros), concatenated with the canonical JSON string, then
    UTF-8 encoded and hashed.

    If your deployment instead chains raw 32-byte prev digests, use
    ``entry_hash_binary_prev`` below and maintain a separate golden vector.
    """
    if len(prev_hash_hex) != 64:
        raise ValueError("prev_hash_hex must be 64 hex characters")
    material = (prev_hash_hex + payload_canonical_utf8).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


def entry_hash_binary_prev(prev_digest: bytes, payload_canonical_utf8: str) -> str:
    """Alternate: SHA-256(prev_digest || payload_bytes)."""
    if len(prev_digest) != 32:
        raise ValueError("prev_digest must be 32 bytes")
    payload_bytes = payload_canonical_utf8.encode("utf-8")
    return hashlib.sha256(prev_digest + payload_bytes).hexdigest()
