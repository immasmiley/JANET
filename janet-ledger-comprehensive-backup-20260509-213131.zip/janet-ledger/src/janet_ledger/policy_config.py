"""Optional policy overrides loaded from manifest JSON (policy-as-config)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class PolicyConfig:
    """
    Swappable knobs read from manifest ``policy_config`` (defaults = current core).

    - ``zone_tie_break_coord``: ZONE-TIE-001 coordinate (default ``-25.0``).
    - ``convergence_default_active_policy``: applied when a scenario omits ``active_policy``.
    """

    zone_tie_break_coord: float = -25.0
    convergence_default_active_policy: str | None = None


def policy_config_from_manifest(root: Mapping[str, Any]) -> PolicyConfig:
    """Parse ``policy_config`` block; missing keys use normative defaults."""
    pc = root.get("policy_config")
    if not pc or not isinstance(pc, Mapping):
        return PolicyConfig()
    zr = pc.get("zone_router")
    tie = -25.0
    if isinstance(zr, Mapping) and "tie_break_coord" in zr:
        tie = float(zr["tie_break_coord"])
    conv = pc.get("convergence")
    dap: str | None = None
    if isinstance(conv, Mapping):
        raw = conv.get("default_active_policy")
        if raw is None:
            dap = None
        elif isinstance(raw, str) and raw.strip() == "":
            dap = None
        else:
            dap = str(raw)
    return PolicyConfig(zone_tie_break_coord=tie, convergence_default_active_policy=dap)
