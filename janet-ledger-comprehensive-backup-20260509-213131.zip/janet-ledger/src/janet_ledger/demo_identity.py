"""
Temporary demo identity for relay/connectivity validation (JANET + Nostr handoff).

Provides **deterministic canonical JSON**, a **lifecycle state machine**, and
**retirement ordering** for coordinators. **Native** crypto and **live** relays
are specified in ``docs/DEMO_IDENTITY_LIVE.md`` and typed as
``janet_ledger.demo_identity_production`` Protocols — not implemented here.

``InMemoryDemoKeyVault`` exists **only** for unit tests and is **forbidden** in
production demo wiring unless env ``JANET_ALLOW_CI_DEMO_MEMORY_VAULT=1`` (see
``demo_identity_production.assert_no_ci_memory_vault_in_production``).
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal, Protocol, Sequence, runtime_checkable

from janet_ledger.ledger import entry_hash
from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001

DEMO_IDENTITY_001 = "DEMO-IDENTITY-001"
"""Keystore / policy tag: demo-only key handles and derived sessions."""

DEMO_PROVISION_001 = "DEMO-PROVISION-001"
"""NIP-33 ``d: demo-provision`` inner content."""

DEMO_RETIRE_001 = "DEMO-RETIRE-001"
"""NIP-33 ``d: demo-retired`` inner content; irreversible teardown."""

NIP17_DEMO_SESSION_001 = "NIP17-DEMO-SESSION-001"
"""Demo-scoped NIP-17 session envelope (connectivity / roundtrip tests)."""

_SCHEMA_PROVISION = "nip33_janet_demo_provision_v1"
_SCHEMA_RETIRED = "nip33_janet_demo_retired_v1"
_SCHEMA_LEAVE = "nip29_janet_demo_leave_v1"
_SCHEMA_NIP17 = "nip17_janet_demo_session_v1"
_SCHEMA_AUDIT = "janet_audit_demo_retired_v1"

_HEX64 = re.compile(r"^[0-9a-f]{64}$")

DemoRetireReason = Literal["user_promoted", "family_invite_accepted"]
RealIdentityTrigger = Literal["CREATE_REAL_ACCOUNT", "ACCEPT_FAMILY_INVITE"]

_TRIGGER_TO_REASON: dict[RealIdentityTrigger, DemoRetireReason] = {
    "CREATE_REAL_ACCOUNT": "user_promoted",
    "ACCEPT_FAMILY_INVITE": "family_invite_accepted",
}

_DEFAULT_PROVISION_POLICIES = (
    DEMO_IDENTITY_001,
    DEMO_PROVISION_001,
    NIP33_JANET_CONTENT_001,
)


def _hex64(name: str, value: str) -> str:
    v = value.lower()
    if not _HEX64.match(v):
        raise ValueError(f"{name} must be 64 lowercase hex chars")
    return v


def _sorted_policies(codes: Sequence[str]) -> list[str]:
    if not codes:
        raise ValueError("janet_policy_codes must be non-empty")
    out = sorted({str(c).strip() for c in codes if str(c).strip()})
    if not out:
        raise ValueError("janet_policy_codes must be non-empty")
    return out


def nip33_demo_provision_payload_canonical(
    *,
    demo_pubkey_hex: str,
    nip29_group_id: str,
    epoch: int,
    monotonic_counter: int,
    janet_policy_codes: Sequence[str],
    last_known_chain_event_id_hex: str | None = None,
) -> str:
    """NIP-33 replaceable ``d: demo-provision`` **content** JSON (sorted keys)."""
    pol = _sorted_policies(janet_policy_codes)
    for req in (DEMO_IDENTITY_001, DEMO_PROVISION_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if not nip29_group_id.startswith("demo_"):
        raise ValueError("nip29_group_id must start with 'demo_'")
    if not isinstance(epoch, int) or epoch < 0:
        raise ValueError("epoch must be int >= 0")
    if not isinstance(monotonic_counter, int) or monotonic_counter < 0:
        raise ValueError("monotonic_counter must be int >= 0")
    obj: dict[str, Any] = {
        "demo_pubkey_hex": _hex64("demo_pubkey_hex", demo_pubkey_hex),
        "epoch": int(epoch),
        "janet_policy_codes": pol,
        "monotonic_counter": int(monotonic_counter),
        "namespace": "demo_",
        "nip29_group_id": nip29_group_id,
        "relay_pool_tag": "demo_",
        "schema": _SCHEMA_PROVISION,
    }
    if last_known_chain_event_id_hex is not None:
        obj["last_known_chain_event_id_hex"] = _hex64(
            "last_known_chain_event_id_hex", last_known_chain_event_id_hex
        )
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def nip33_demo_retired_payload_canonical(
    *,
    chain_prev_event_id_hex: str,
    reason: DemoRetireReason,
    epoch: int,
    monotonic_counter: int,
    janet_policy_codes: Sequence[str],
    d_tag: str = "demo-retired",
) -> str:
    """
    NIP-33 ``d: demo-retired`` **content** JSON.

    Coordinator MUST sign this with the demo key **before** ``DeleteKey``.
    """
    pol = _sorted_policies(janet_policy_codes)
    for req in (DEMO_RETIRE_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if not isinstance(epoch, int) or epoch < 0:
        raise ValueError("epoch must be int >= 0")
    if not isinstance(monotonic_counter, int) or monotonic_counter < 0:
        raise ValueError("monotonic_counter must be int >= 0")
    if reason not in ("user_promoted", "family_invite_accepted"):
        raise ValueError("invalid reason")
    dt = d_tag.strip()
    if dt != "demo-retired":
        raise ValueError("d_tag must be 'demo-retired' for this schema")
    obj: dict[str, Any] = {
        "chain_prev_event_id_hex": _hex64("chain_prev_event_id_hex", chain_prev_event_id_hex),
        "d_tag": dt,
        "epoch": int(epoch),
        "janet_policy_codes": pol,
        "monotonic_counter": int(monotonic_counter),
        "reason": reason,
        "schema": _SCHEMA_RETIRED,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def nip29_demo_leave_payload_canonical(
    *,
    nip29_group_id: str,
    janet_policy_codes: Sequence[str],
) -> str:
    """NIP-29 ``leave`` action body for demo family (after retire NIP-33, before key delete)."""
    pol = _sorted_policies(janet_policy_codes)
    for req in (DEMO_RETIRE_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if not nip29_group_id.startswith("demo_"):
        raise ValueError("nip29_group_id must start with 'demo_'")
    obj: dict[str, Any] = {
        "action": "leave",
        "janet_policy_codes": pol,
        "namespace": "demo_",
        "nip29_group_id": nip29_group_id,
        "schema": _SCHEMA_LEAVE,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def nip17_demo_session_payload_canonical(
    *,
    peer_pubkey_hex: str,
    session_epoch: int,
    janet_policy_codes: Sequence[str],
) -> str:
    """Deterministic demo-scoped NIP-17 session probe envelope (no ciphertext)."""
    pol = _sorted_policies(janet_policy_codes)
    for req in (DEMO_IDENTITY_001, NIP17_DEMO_SESSION_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if not isinstance(session_epoch, int) or session_epoch < 0:
        raise ValueError("session_epoch must be int >= 0")
    obj: dict[str, Any] = {
        "janet_policy_codes": pol,
        "namespace": "demo_",
        "peer_pubkey_hex": _hex64("peer_pubkey_hex", peer_pubkey_hex),
        "schema": _SCHEMA_NIP17,
        "session_epoch": int(session_epoch),
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def demo_retired_audit_row_canonical(
    *,
    retire_event_id_hex: str,
    prior_demo_chain_tip_hex: str,
    audit_ledger_prev_hash_hex: str,
    reason: DemoRetireReason,
    phase: Literal["post_teardown"],
) -> str:
    """
    Local JANET audit row after teardown (unsigned; chained via ``entry_hash``).

    ``audit_ledger_prev_hash_hex`` is the prior row's 64-hex ledger head.
    ``prior_demo_chain_tip_hex`` is the last demo Nostr event id before retire.
    """
    obj: dict[str, Any] = {
        "audit_ledger_prev_hash_hex": _hex64("audit_ledger_prev_hash_hex", audit_ledger_prev_hash_hex),
        "event": "demo_retired",
        "phase": phase,
        "prior_demo_chain_tip_hex": _hex64("prior_demo_chain_tip_hex", prior_demo_chain_tip_hex),
        "reason": reason,
        "retire_event_id_hex": _hex64("retire_event_id_hex", retire_event_id_hex),
        "schema": _SCHEMA_AUDIT,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


class DemoLifecycleState(str, Enum):
    first_launch = "first_launch"
    demo_provision = "demo_provision"
    relay_ping = "relay_ping"
    demo_active = "demo_active"
    retire_sequence = "retire_sequence"
    retired_final = "retired_final"
    real_init = "real_init"


_VALID_TRANSITIONS: dict[DemoLifecycleState, frozenset[DemoLifecycleState]] = {
    DemoLifecycleState.first_launch: frozenset({DemoLifecycleState.demo_provision}),
    DemoLifecycleState.demo_provision: frozenset({DemoLifecycleState.relay_ping}),
    DemoLifecycleState.relay_ping: frozenset({DemoLifecycleState.demo_active}),
    DemoLifecycleState.demo_active: frozenset({DemoLifecycleState.retire_sequence}),
    DemoLifecycleState.retire_sequence: frozenset({DemoLifecycleState.retired_final}),
    DemoLifecycleState.retired_final: frozenset({DemoLifecycleState.real_init}),
    DemoLifecycleState.real_init: frozenset(),
}


def assert_transition_ok(from_s: DemoLifecycleState, to_s: DemoLifecycleState) -> None:
    allowed = _VALID_TRANSITIONS.get(from_s)
    if allowed is None or to_s not in allowed:
        raise ValueError(f"invalid demo lifecycle transition {from_s!r} -> {to_s!r}")


@dataclass
class DemoIdentitySession:
    state: DemoLifecycleState = DemoLifecycleState.first_launch
    demo_key_handle_id: str | None = None
    demo_pubkey_hex: str | None = None
    nip29_group_id: str | None = None
    last_demo_event_id_hex: str | None = None
    monotonic_counter: int = 0
    epoch: int = 0
    retired_irreversibly: bool = False

    def transition(self, to: DemoLifecycleState) -> None:
        assert_transition_ok(self.state, to)
        self.state = to

    def bump_counter(self) -> int:
        self.monotonic_counter += 1
        return self.monotonic_counter


@runtime_checkable
class DemoKeyVault(Protocol):
    def register_demo_key(self, handle_id: str, pubkey_hex: str) -> None: ...
    def delete_demo_key(self, handle_id: str) -> None: ...
    def has_demo_key(self, handle_id: str) -> bool: ...


@dataclass
class InMemoryDemoKeyVault:
    """
    **CI / unit tests only.** Holds pubkey map in RAM — **not** hardware-backed.

    Production apps must call ``assert_no_ci_memory_vault_in_production`` when
    wiring vaults; use platform keystore adapters implementing
    ``HardwareDemoSigning`` instead.
    """
    _handles: dict[str, str] = field(default_factory=dict)

    def register_demo_key(self, handle_id: str, pubkey_hex: str) -> None:
        self._handles[handle_id] = _hex64("pubkey_hex", pubkey_hex)

    def delete_demo_key(self, handle_id: str) -> None:
        self._handles.pop(handle_id, None)

    def has_demo_key(self, handle_id: str) -> bool:
        return handle_id in self._handles


RETIREMENT_STEP_ORDER: tuple[str, ...] = (
    "build_nip33_demo_retired",
    "sign_and_publish_retired",
    "build_nip29_leave",
    "sign_and_publish_leave",
    "delete_demo_key",
    "purge_demo_local_store",
    "append_local_audit_demo_retired",
)


@dataclass(frozen=True)
class RetirementExecutionResult:
    retire_content_canonical: str
    retire_event_id_hex: str
    leave_content_canonical: str
    leave_event_id_hex: str
    audit_row_canonical: str
    final_ledger_hash_hex: str


def simulate_nostr_event_id(content_canonical: str) -> str:
    """Deterministic stand-in for NIP-01 ``id`` (SHA-256 of canonical content)."""
    return hashlib.sha256(content_canonical.encode("utf-8")).hexdigest()


def execute_demo_retirement(
    session: DemoIdentitySession,
    vault: DemoKeyVault,
    *,
    trigger: RealIdentityTrigger,
    audit_ledger_prev_hash_hex: str,
    janet_policy_codes_retire: Sequence[str] | None = None,
    janet_policy_codes_leave: Sequence[str] | None = None,
) -> RetirementExecutionResult:
    """
    Ordered teardown: retire payload + synthetic ids → leave → **DeleteKey** →
    purge session → local audit row + ``entry_hash`` continuation.

    Signing hooks are implicit: ``retire_event_id_hex`` / ``leave_event_id_hex``
    are computed **before** ``delete_demo_key`` so native code signs in that order.
    """
    if session.retired_irreversibly:
        raise RuntimeError("demo identity already retired")
    if session.state != DemoLifecycleState.demo_active:
        raise ValueError("retirement requires session.state == demo_active")
    if not session.demo_key_handle_id or not session.demo_pubkey_hex or not session.nip29_group_id:
        raise ValueError("incomplete demo session")
    tip = session.last_demo_event_id_hex
    if not tip:
        raise ValueError("last_demo_event_id_hex required for chain_prev")
    handle = session.demo_key_handle_id
    group = session.nip29_group_id

    session.transition(DemoLifecycleState.retire_sequence)

    reason = _TRIGGER_TO_REASON[trigger]
    pol_r = janet_policy_codes_retire or (DEMO_RETIRE_001, NIP33_JANET_CONTENT_001)
    pol_l = janet_policy_codes_leave or (DEMO_RETIRE_001, NIP33_JANET_CONTENT_001)
    mc = session.bump_counter()
    retire_body = nip33_demo_retired_payload_canonical(
        chain_prev_event_id_hex=tip,
        reason=reason,
        epoch=session.epoch,
        monotonic_counter=mc,
        janet_policy_codes=pol_r,
    )
    retire_eid = simulate_nostr_event_id(retire_body)
    leave_body = nip29_demo_leave_payload_canonical(
        nip29_group_id=group,
        janet_policy_codes=pol_l,
    )
    leave_eid = simulate_nostr_event_id(leave_body)

    vault.delete_demo_key(handle)

    session.demo_key_handle_id = None
    session.demo_pubkey_hex = None
    session.nip29_group_id = None
    session.last_demo_event_id_hex = None
    session.retired_irreversibly = True

    audit_body = demo_retired_audit_row_canonical(
        retire_event_id_hex=retire_eid,
        prior_demo_chain_tip_hex=tip,
        audit_ledger_prev_hash_hex=audit_ledger_prev_hash_hex,
        reason=reason,
        phase="post_teardown",
    )
    final_hash = entry_hash(audit_ledger_prev_hash_hex, audit_body)

    session.transition(DemoLifecycleState.retired_final)

    return RetirementExecutionResult(
        retire_content_canonical=retire_body,
        retire_event_id_hex=retire_eid,
        leave_content_canonical=leave_body,
        leave_event_id_hex=leave_eid,
        audit_row_canonical=audit_body,
        final_ledger_hash_hex=final_hash,
    )


def auto_provision_demo_session(
    session: DemoIdentitySession,
    vault: DemoKeyVault,
    *,
    demo_key_handle_id: str,
    demo_pubkey_hex: str,
    nip29_group_id: str,
    janet_policy_codes: Sequence[str] | None = None,
) -> tuple[str, str]:
    """
    ``first_launch`` → ``demo_provision``: register vault, build provision canonical.

    Returns ``(provision_content_canonical, synthetic_event_id_hex)`` and sets
    ``session.last_demo_event_id_hex`` to the synthetic id (coordinator replaces
    with relay-assigned id when connected).
    """
    if session.state != DemoLifecycleState.first_launch:
        raise ValueError("auto_provision requires first_launch")
    if not nip29_group_id.startswith("demo_"):
        raise ValueError("nip29_group_id must start with 'demo_'")
    pol = janet_policy_codes or _DEFAULT_PROVISION_POLICIES
    session.transition(DemoLifecycleState.demo_provision)
    vault.register_demo_key(demo_key_handle_id, demo_pubkey_hex)
    session.demo_key_handle_id = demo_key_handle_id
    session.demo_pubkey_hex = _hex64("demo_pubkey_hex", demo_pubkey_hex)
    session.nip29_group_id = nip29_group_id
    mc = session.bump_counter()
    body = nip33_demo_provision_payload_canonical(
        demo_pubkey_hex=demo_pubkey_hex,
        nip29_group_id=nip29_group_id,
        epoch=session.epoch,
        monotonic_counter=mc,
        janet_policy_codes=pol,
    )
    eid = simulate_nostr_event_id(body)
    session.last_demo_event_id_hex = eid
    return body, eid


def advance_demo_relay_ping(session: DemoIdentitySession) -> None:
    """``demo_provision`` → ``relay_ping``."""
    if session.state != DemoLifecycleState.demo_provision:
        raise ValueError("expected demo_provision")
    session.transition(DemoLifecycleState.relay_ping)


def advance_demo_active(session: DemoIdentitySession) -> None:
    """``relay_ping`` → ``demo_active`` (connectivity validated)."""
    if session.state != DemoLifecycleState.relay_ping:
        raise ValueError("expected relay_ping")
    session.transition(DemoLifecycleState.demo_active)


def advance_real_init(session: DemoIdentitySession) -> None:
    """``retired_final`` → ``real_init`` (real account flow may start)."""
    if session.state != DemoLifecycleState.retired_final:
        raise ValueError("expected retired_final")
    session.transition(DemoLifecycleState.real_init)
