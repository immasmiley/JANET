"""
Small deterministic helpers: audit bundles, replay diff, ring neighbors,
coherence snapshots, kin cards — no new crypto, minimal surface.

See README “Toolbox” and tests/test_toolbox.py.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence, cast

from janet_ledger.convergence import evaluate_scenario
from janet_ledger.evidence_triad import EvidenceTriadResult
from janet_ledger.family_graph import (
    SelfDegreeType,
    SlotBinding,
    bat_tier_for_degree,
    degree_and_type_for,
    polling_steps_for_degree,
    vouch_threshold_for_degree,
)
from janet_ledger.lattice217 import HALF_IDX, N_NODES, family_n_to_janet_k
from janet_ledger.zones import route_zone_with_tie_meta


def cache_key_evidence_fingerprint(fingerprint: int) -> str:
    """Stable string key for caches / dedup (no new hashing)."""
    return f"janet:evidence_fp:{int(fingerprint)}"


def audit_session_bundle_canonical(
    *,
    evidence_bindings: Sequence[dict[str, Any]],
    ledger_row_payloads: Sequence[str],
    zone_outcomes: Sequence[dict[str, Any]],
) -> str:
    """
    One canonical JSON: triad/ledger audit dicts + ledger payload strings + zone rows.

    Each inner object is re-serialized with sorted keys so callers may pass
    ``audit_evidence_binding`` dicts directly.
    """
    canon_bindings = sorted(
        json.dumps(dict(sorted(b.items())), sort_keys=True, separators=(",", ":"))
        for b in evidence_bindings
    )
    canon_zones = sorted(
        json.dumps(dict(sorted(z.items())), sort_keys=True, separators=(",", ":"))
        for z in zone_outcomes
    )
    obj: dict[str, Any] = {
        "audit_session_bundle_schema": "session_audit_v1",
        "evidence_bindings": canon_bindings,
        "ledger_row_payloads": sorted(ledger_row_payloads),
        "zone_outcomes": canon_zones,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def neighbor_n_ring(n: int) -> tuple[int | None, int, int | None]:
    """Ring adjacency on 0..216: ``(n-1, n, n+1)`` with ``None`` at ends."""
    if not isinstance(n, int) or n < 0 or n >= N_NODES:
        raise ValueError(f"n must be in [0, {N_NODES - 1}]: {n}")
    left = n - 1 if n > 0 else None
    right = n + 1 if n < N_NODES - 1 else None
    return (left, n, right)


def neighbor_ks_for_k(k: int) -> tuple[int | None, int, int | None]:
    """Symmetric ``k`` in [-108,108] mapped via ``n = k + 108`` to ring neighbors."""
    n = k + HALF_IDX
    left_n, _, right_n = neighbor_n_ring(n)
    k_left = family_n_to_janet_k(left_n) if left_n is not None else None
    k_right = family_n_to_janet_k(right_n) if right_n is not None else None
    return (k_left, k, k_right)


def coherence_binding_vs_zone(
    *,
    coord_post_snap: float,
    zone_claim: str,
    triad: EvidenceTriadResult,
    tie_coord: float = -25.0,
) -> dict[str, Any]:
    """
    Validation-only: routed zone vs explicit claim, alongside triadic audit ids.

    Does not infer zone from ``k_rank`` (no hidden mapping); caller supplies claim.
    ``tie_coord`` must match manifest ``policy_config.zone_router.tie_break_coord`` when used.
    """
    routed, tie = route_zone_with_tie_meta(coord_post_snap, tie_coord=tie_coord)
    return {
        "claim_matches_route": zone_claim == routed,
        "coord_post_snap": float(coord_post_snap),
        "k_rank": triad.k_rank,
        "tie_break_applied": tie,
        "triad_evidence_fingerprint": triad.evidence_fingerprint,
        "zone_claim": zone_claim,
        "zone_routed": routed,
    }


def member_ring_snapshot(n_index: int) -> dict[str, Any]:
    """BAT tier + degree/type (+ polling/vouch) for a family ring index (onboarding card)."""
    info = degree_and_type_for(n_index)
    if info.get("reserved"):
        return {"bat_tier": None, "n_index": n_index, "reserved": True}
    if info.get("self"):
        sd = cast(SelfDegreeType, info)
        d = int(sd["degree"])
        return {
            "bat_tier": bat_tier_for_degree(d),
            "degree": d,
            "n_index": n_index,
            "polling_steps": polling_steps_for_degree(d),
            "rel_type": int(sd["rel_type"]),
            "self": True,
            "vouch_threshold": vouch_threshold_for_degree(d),
        }
    sb = cast(SlotBinding, info)
    d = int(sb["degree"])
    return {
        "bat_tier": bat_tier_for_degree(d),
        "degree": d,
        "n_index": n_index,
        "polling_steps": polling_steps_for_degree(d),
        "rel_type": int(sb["rel_type"]),
        "self": False,
        "vouch_threshold": vouch_threshold_for_degree(d),
    }


def _manifest_load(path: Path) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8")
    return cast(dict[str, Any], json.loads(raw))


def diff_manifest_convergence_scenarios(path_a: Path, path_b: Path) -> list[str]:
    """
    Compare ``convergence_tests.scenarios`` in two TEST_MANIFEST-style JSON files.

    Returns a sorted list of human-readable diff lines (empty if identical).
    """
    a = _manifest_load(path_a).get("convergence_tests", {}).get("scenarios", [])
    b = _manifest_load(path_b).get("convergence_tests", {}).get("scenarios", [])
    by_id_a = {s["id"]: s for s in a}
    by_id_b = {s["id"]: s for s in b}
    lines: list[str] = []
    all_ids = sorted(set(by_id_a) | set(by_id_b))
    for sid in all_ids:
        if sid not in by_id_a:
            lines.append(f"+ scenario missing in A: {sid}")
            continue
        if sid not in by_id_b:
            lines.append(f"- scenario missing in B: {sid}")
            continue
        sa, sb = by_id_a[sid], by_id_b[sid]
        ca = json.dumps(sa, sort_keys=True, separators=(",", ":"))
        cb = json.dumps(sb, sort_keys=True, separators=(",", ":"))
        if ca != cb:
            lines.append(f"~ scenario differs: {sid}")
    return sorted(lines)


def diff_canonical_jsonl_lines(lines_a: Sequence[str], lines_b: Sequence[str]) -> list[str]:
    """
    Multiset diff on canonical JSON lines (sorted JSON strings compared as bags).

    Returns sorted diff lines: ``only_a:``, ``only_b:``, ``count_mismatch:``.
    """
    from collections import Counter

    ca = Counter(sorted(lines_a))
    cb = Counter(sorted(lines_b))
    out: list[str] = []
    for line in sorted(set(ca) | set(cb)):
        na, nb = ca[line], cb[line]
        if na == nb:
            continue
        if na == 0:
            out.append(f"only_b:{nb}:{line}")
        elif nb == 0:
            out.append(f"only_a:{na}:{line}")
        else:
            out.append(f"count_mismatch:a={na},b={nb}:{line}")
    return sorted(out)


def cache_key_ledger_row(prev_hash_hex: str, payload_canonical: str) -> str:
    """Deterministic CDN/Redis-style key from existing ``entry_hash`` (no new crypto)."""
    from janet_ledger.ledger import entry_hash

    return f"janet:ledger:{entry_hash(prev_hash_hex, payload_canonical)}"


def cache_key_render_log(ledger_hash_hex: str, renderer_config: Mapping[str, Any]) -> str:
    """Key from ``render_log_hash`` for edge caches."""
    from janet_ledger.renderer import render_log_hash

    return f"janet:render_log:{render_log_hash(ledger_hash_hex, renderer_config)}"


def whatif_convergence_json(sessions_json: str) -> bool:
    """Parse JSON list of {session_id, k_final} and evaluate CONV-ADJ-001 if policy set."""
    scenario = json.loads(sessions_json)
    if isinstance(scenario, list):
        scenario = {"sessions": scenario}
    return bool(evaluate_scenario(scenario))
