"""
JANET policy codes on Nostr NIP-33-style replaceable payloads (engineering handoff).

Recovery, rotation, tamper response, and delegation semantics are **versioned by
explicit ``*-001`` codes** in canonical JSON so coordinators can swap behavior
via manifest / policy tables without changing serialization shape.

These strings are the **content** of Nostr events (or mirror rows in a local
hash-chained audit log). Relay routing uses normal NIP-01/17/29/33 rules outside
this module.
"""

from __future__ import annotations

import json
import re
from typing import Any, Sequence

# --- Policy codes (reference in NIP-33 JSON field ``janet_policy_codes``) ---

ROTATION_EPOCH_001 = "ROTATION-EPOCH-001"
"""Replay-proof rotation: requires ``epoch`` and ``monotonic_counter`` semantics per verifier."""

RECOVERY_THRESHOLD_001 = "RECOVERY-THRESHOLD-001"
"""Threshold quorum for trustee ACKs before binding ``new_pubkey`` to continuity."""

NIP33_JANET_CONTENT_001 = "NIP33-JANET-CONTENT-001"
"""Canonical JSON shape for JANET-tagged NIP-33 inner payloads (this module's builders)."""

TAMPER_RESPONSE_001 = "TAMPER-RESPONSE-001"
"""Tamper trip → hardware wipe → re-gen sequence; versioned response policy."""

DELEGATION_CHAIN_001 = "DELEGATION-CHAIN-001"
"""Pre-registered successor / hash binding chain while prior key still alive."""

RECOVERY_CHALLENGE_BIND_001 = "RECOVERY-CHALLENGE-BIND-001"
"""Challenge id MUST cryptographically bind to exactly one ``new_pubkey`` for quorum."""

_SCHEMA_ROTATION = "nip33_janet_rotation_v1"
_SCHEMA_RECOVERY = "nip33_janet_recovery_policy_v1"
_SCHEMA_DELEGATION = "nip33_janet_delegation_v1"

_HEX64 = re.compile(r"^[0-9a-f]{64}$")


def _hex64(name: str, value: str) -> str:
    v = value.lower()
    if not _HEX64.match(v):
        raise ValueError(f"{name} must be 64 lowercase hex chars")
    return v


def _sorted_policies(codes: Sequence[str]) -> list[str]:
    if not codes:
        raise ValueError("janet_policy_codes must be non-empty")
    out = sorted({str(c).strip() for c in codes if str(c).strip()})
    if not out:
        raise ValueError("janet_policy_codes must be non-empty")
    return out


def nip33_rotation_payload_canonical(
    *,
    new_pubkey_hex: str,
    epoch: int,
    monotonic_counter: int,
    janet_policy_codes: Sequence[str],
    previous_event_id_hex: str | None = None,
    old_pubkey_hex: str | None = None,
    recovery_challenge_id_hex: str | None = None,
    wipe_reason: str | None = None,
) -> str:
    """
    Replaceable ``identity-rotation`` (or app kind) **content** JSON, sorted keys.

    Verifiers MUST require ``ROTATION-EPOCH-001`` in ``janet_policy_codes`` and
    enforce monotonic ``(epoch, monotonic_counter)`` per ``(author, d-tag)`` scope.
    """
    pol = _sorted_policies(janet_policy_codes)
    if ROTATION_EPOCH_001 not in pol:
        raise ValueError(f"janet_policy_codes must include {ROTATION_EPOCH_001!r}")
    if NIP33_JANET_CONTENT_001 not in pol:
        raise ValueError(f"janet_policy_codes must include {NIP33_JANET_CONTENT_001!r}")
    if not isinstance(epoch, int) or epoch < 0:
        raise ValueError("epoch must be int >= 0")
    if not isinstance(monotonic_counter, int) or monotonic_counter < 0:
        raise ValueError("monotonic_counter must be int >= 0")
    npk = _hex64("new_pubkey_hex", new_pubkey_hex)
    obj: dict[str, Any] = {
        "epoch": int(epoch),
        "janet_policy_codes": pol,
        "monotonic_counter": int(monotonic_counter),
        "new_pubkey_hex": npk,
        "schema": _SCHEMA_ROTATION,
    }
    if previous_event_id_hex is not None:
        obj["previous_event_id_hex"] = _hex64("previous_event_id_hex", previous_event_id_hex)
    if old_pubkey_hex is not None:
        obj["old_pubkey_hex"] = _hex64("old_pubkey_hex", old_pubkey_hex)
    if recovery_challenge_id_hex is not None:
        obj["recovery_challenge_id_hex"] = _hex64("recovery_challenge_id_hex", recovery_challenge_id_hex)
        if RECOVERY_CHALLENGE_BIND_001 not in pol:
            raise ValueError(
                f"janet_policy_codes must include {RECOVERY_CHALLENGE_BIND_001!r} "
                "when recovery_challenge_id_hex is set"
            )
    if wipe_reason is not None and wipe_reason.strip():
        obj["wipe_reason"] = wipe_reason.strip()[:64]
        if TAMPER_RESPONSE_001 not in pol:
            raise ValueError(
                f"janet_policy_codes must include {TAMPER_RESPONSE_001!r} when wipe_reason is set"
            )
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def nip33_recovery_policy_payload_canonical(
    *,
    threshold: int,
    trustee_pubkey_hex: Sequence[str],
    janet_policy_codes: Sequence[str],
    policy_epoch: int,
) -> str:
    """
    Replaceable ``recovery-policy`` **content** JSON.

    ``trustee_pubkey_hex`` is sorted for determinism (set semantics).
    Verifiers MUST require ``RECOVERY_THRESHOLD_001`` in ``janet_policy_codes``.
    """
    pol = _sorted_policies(janet_policy_codes)
    if RECOVERY_THRESHOLD_001 not in pol:
        raise ValueError(f"janet_policy_codes must include {RECOVERY_THRESHOLD_001!r}")
    if NIP33_JANET_CONTENT_001 not in pol:
        raise ValueError(f"janet_policy_codes must include {NIP33_JANET_CONTENT_001!r}")
    if not isinstance(threshold, int) or threshold < 1:
        raise ValueError("threshold must be int >= 1")
    if not isinstance(policy_epoch, int) or policy_epoch < 0:
        raise ValueError("policy_epoch must be int >= 0")
    trustees = sorted({_hex64("trustee_pubkey_hex", t) for t in trustee_pubkey_hex})
    if not trustees:
        raise ValueError("trustee_pubkey_hex must be non-empty")
    if threshold > len(trustees):
        raise ValueError("threshold cannot exceed number of trustees")
    obj: dict[str, Any] = {
        "janet_policy_codes": pol,
        "policy_epoch": int(policy_epoch),
        "schema": _SCHEMA_RECOVERY,
        "threshold": int(threshold),
        "trustee_pubkey_hex": trustees,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def nip33_delegation_snapshot_canonical(
    *,
    delegator_pubkey_hex: str,
    successor_pubkey_hash_hex: str,
    janet_policy_codes: Sequence[str],
    delegation_epoch: int,
    policy_digest_hex: str | None = None,
) -> str:
    """
    Pre-registered successor binding while delegator key is still alive.

    ``successor_pubkey_hash_hex`` is SHA-256(32-byte x-only successor pubkey) as 64-hex,
    or any agreed 32-byte commitment published out-of-band between clients.
    """
    pol = _sorted_policies(janet_policy_codes)
    if DELEGATION_CHAIN_001 not in pol:
        raise ValueError(f"janet_policy_codes must include {DELEGATION_CHAIN_001!r}")
    if NIP33_JANET_CONTENT_001 not in pol:
        raise ValueError(f"janet_policy_codes must include {NIP33_JANET_CONTENT_001!r}")
    if not isinstance(delegation_epoch, int) or delegation_epoch < 0:
        raise ValueError("delegation_epoch must be int >= 0")
    obj: dict[str, Any] = {
        "delegation_epoch": int(delegation_epoch),
        "delegator_pubkey_hex": _hex64("delegator_pubkey_hex", delegator_pubkey_hex),
        "janet_policy_codes": pol,
        "schema": _SCHEMA_DELEGATION,
        "successor_pubkey_hash_hex": _hex64("successor_pubkey_hash_hex", successor_pubkey_hash_hex),
    }
    if policy_digest_hex is not None:
        obj["policy_digest_hex"] = _hex64("policy_digest_hex", policy_digest_hex)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))
