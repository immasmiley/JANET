"""EQ-NULL-001: |c_t| < δ for two consecutive turns."""

from __future__ import annotations

from janet_ledger.constants import DELTA


def equilibrium_null_fires(sequence: list[float]) -> bool:
    if len(sequence) < 2:
        return False
    a, b = sequence[-2], sequence[-1]
    return abs(a) < DELTA and abs(b) < DELTA
