"""
Deterministic exports for UI / compliance: zone samples, kδ line, ledger JSONL rows.

Uses existing ``route_zone``, ``lattice217``, ``constants``, and manifest slices.
"""

from __future__ import annotations

import json
from fractions import Fraction
from typing import Any, Mapping

from janet_ledger.constants import DELTA, K_MAX, K_MIN
from janet_ledger.lattice217 import (
    DELTA_DEN,
    DELTA_NUM,
    N_NODES,
    family_n_to_janet_k,
    x_at_frac,
)
from janet_ledger.zones import route_zone_with_tie_meta


def zone_map_export_dict(*, tie_coord: float = -25.0) -> dict[str, Any]:
    """Sample coordinates → zone + tie flag (frontend / static hosting)."""
    coords = [-100.0, -75.0, -50.0, tie_coord, tie_coord + 0.01, -0.01, 0.0, 25.0, 50.0, 75.0, 100.0]
    samples = []
    for c in coords:
        z, tie = route_zone_with_tie_meta(c, tie_coord=tie_coord)
        samples.append({"coord": c, "tie_break_applied": tie, "zone": z})
    return {
        "tie_break_coord": tie_coord,
        "zone_map_schema": "zone_map_v1",
        "zone_names_order": [
            "Fundamental",
            "Structural",
            "Categorical",
            "Attributive",
            "Definitional",
            "Compositional",
            "Instantial",
            "Expressive",
        ],
        "samples": samples,
    }


def k_delta_line_export_dict() -> dict[str, Any]:
    """Full 217-node n ↔ k ↔ x (rational string + float) for static UI."""
    nodes: list[dict[str, Any]] = []
    for n in range(N_NODES):
        k = family_n_to_janet_k(n)
        xf = x_at_frac(n)
        nodes.append(
            {
                "k": k,
                "n": n,
                "x_float": float(xf),
                "x_frac": str(xf),
            }
        )
    return {
        "delta": str(Fraction(DELTA_NUM, DELTA_DEN)),
        "delta_float": DELTA,
        "k_bounds": {"max": K_MAX, "min": K_MIN},
        "k_delta_line_schema": "line_v1",
        "n_nodes": N_NODES,
        "nodes": nodes,
    }


def equilibrium_rules_export_dict(manifest: Mapping[str, Any]) -> dict[str, Any]:
    """Copy manifest equilibrium / zone tie text for UI (no interpretation)."""
    eq = manifest.get("equilibrium_null_logic")
    zt = manifest.get("zone_tie_breakers")
    return {
        "equilibrium_null_logic": eq if isinstance(eq, Mapping) else {},
        "equilibrium_rules_schema": "equilibrium_rules_v1",
        "zone_tie_breakers": zt if isinstance(zt, Mapping) else {},
    }


def static_ui_bundle_dict(manifest: Mapping[str, Any], *, tie_coord: float = -25.0) -> dict[str, Any]:
    """Single JSON blob: zone map + kδ line + equilibrium copy."""
    return {
        "equilibrium": equilibrium_rules_export_dict(manifest),
        "k_delta_line": k_delta_line_export_dict(),
        "static_ui_bundle_schema": "static_ui_v1",
        "zone_map": zone_map_export_dict(tie_coord=tie_coord),
    }


def ledger_golden_vectors_to_jsonl_lines(manifest: Mapping[str, Any]) -> list[str]:
    """One canonical JSON object per line (pre-serialized ledger chain rows)."""
    out: list[str] = []
    for row in manifest.get("ledger_golden_vectors", []):
        if not isinstance(row, Mapping):
            continue
        obj = {
            "entry_hash": row["entry_hash"],
            "payload_canonical": row["payload_canonical"],
            "prev_hash": row["prev_hash"],
        }
        out.append(json.dumps(obj, sort_keys=True, separators=(",", ":")))
    return out
