"""
NIP-29 **janet-validators** group wiring: canonical roster provision + reputation-weighted quorum.

Relay publish / native Schnorr verification stay **out of package** (see ``docs/NIP29_VALIDATORS.md``).
This module supplies **deterministic inner JSON** and **pure quorum math** for coordinators.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, cast

from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001

NIP29_VALIDATORS_GROUP_001 = "NIP29-VALIDATORS-GROUP-001"
"""Roster row: JANET-managed NIP-29 validator group (``janet-validators``)."""

VALIDATOR_WEIGHT_QUORUM_001 = "VALIDATOR-WEIGHT-QUORUM-001"
"""Quorum is **sum of reputation_weight** for distinct approving pubkeys, not head-count."""

GROUP_SLUG_JANET_VALIDATORS = "janet-validators"
"""Human slug; fixed ``group_address_hex`` binds the logical group across relays."""

_SCHEMA = "nip29_janet_validators_provision_v1"
_MAX_MEMBERS = 256
_MAX_RELAY_HINT_LEN = 256

_HEX64 = re.compile(r"^[0-9a-f]{64}$")


def _hex64(name: str, value: str) -> str:
    v = value.lower()
    if not _HEX64.match(v):
        raise ValueError(f"{name} must be 64 lowercase hex chars")
    return v


def _sorted_policies(codes: Sequence[str]) -> list[str]:
    if not codes:
        raise ValueError("janet_policy_codes must be non-empty")
    out = sorted({str(c).strip() for c in codes if str(c).strip()})
    if not out:
        raise ValueError("janet_policy_codes must be non-empty")
    return out


def janet_validators_group_address_v1() -> str:
    """
    Deterministic **64-hex group address** for ``janet-validators`` (coordinator ``h`` / roster id).

    Stable across processes; use as the canonical NIP-29 group identifier in JANET payloads.
    """
    return hashlib.sha256(b"janet-ledger\0nip29\0janet-validators\0v1").hexdigest()


@dataclass(frozen=True)
class ValidatorMember:
    """One validator row (reputation is an integer weight, not a float score)."""

    pubkey_hex: str
    reputation_weight: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "pubkey_hex", _hex64("pubkey_hex", self.pubkey_hex))
        if not isinstance(self.reputation_weight, int) or self.reputation_weight < 1:
            raise ValueError("reputation_weight must be int >= 1")


def sort_validators_for_round(
    *,
    proposal_id_hex: str,
    members: Sequence[ValidatorMember],
) -> list[ValidatorMember]:
    """
    Deterministic **validation round order**: tie-break via ``SHA-256(proposal_id || pubkey)``.

    Higher-reputation members are **not** auto-sorted first; coordinators may layer policy.
    """
    _hex64("proposal_id_hex", proposal_id_hex)
    lst = list(members)

    def key(m: ValidatorMember) -> tuple[str, str, str]:
        tie = hashlib.sha256(f"{proposal_id_hex}\0{m.pubkey_hex}".encode()).hexdigest()
        return (tie, m.pubkey_hex, str(m.reputation_weight))

    return sorted(lst, key=key)


def accumulated_vote_weight(
    *,
    approved_pubkeys: Sequence[str],
    roster_weights_by_pubkey: Mapping[str, int],
) -> int:
    """Sum ``reputation_weight`` for distinct approving pubkeys present on the roster."""
    seen: set[str] = set()
    total = 0
    roster = {k.lower(): int(v) for k, v in roster_weights_by_pubkey.items()}
    for raw in approved_pubkeys:
        pk = _hex64("approved_pubkey", raw)
        if pk in seen:
            continue
        seen.add(pk)
        w = roster.get(pk)
        if w is None:
            raise ValueError(f"approved pubkey not on roster: {pk}")
        if w < 1:
            raise ValueError("roster weight must be >= 1")
        total += w
    return total


def weighted_quorum_met(*, signed_weight: int, quorum_weight_sum_required: int) -> bool:
    return signed_weight >= quorum_weight_sum_required >= 1


def nip29_validators_provision_payload_canonical(
    *,
    epoch: int,
    monotonic_counter: int,
    members: Sequence[ValidatorMember],
    quorum_weight_sum_required: int,
    janet_policy_codes: Sequence[str] | None = None,
    relay_hints: Sequence[str] | None = None,
) -> str:
    """
    Canonical **provision roster** JSON for the ``janet-validators`` group (sorted keys, sorted members).

    Coordinators publish via normal NIP-29 / relay rules; this string is the **inner** audit payload.
    """
    pol = _sorted_policies(
        janet_policy_codes
        or (NIP29_VALIDATORS_GROUP_001, VALIDATOR_WEIGHT_QUORUM_001, NIP33_JANET_CONTENT_001)
    )
    for req in (NIP29_VALIDATORS_GROUP_001, VALIDATOR_WEIGHT_QUORUM_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if not isinstance(epoch, int) or epoch < 0:
        raise ValueError("epoch must be int >= 0")
    if not isinstance(monotonic_counter, int) or monotonic_counter < 0:
        raise ValueError("monotonic_counter must be int >= 0")
    if not isinstance(quorum_weight_sum_required, int) or quorum_weight_sum_required < 1:
        raise ValueError("quorum_weight_sum_required must be int >= 1")
    if not members:
        raise ValueError("members must be non-empty")
    if len(members) > _MAX_MEMBERS:
        raise ValueError(f"at most {_MAX_MEMBERS} validators")

    by_pk: dict[str, ValidatorMember] = {}
    for m in members:
        if m.pubkey_hex in by_pk:
            raise ValueError("duplicate validator pubkey")
        by_pk[m.pubkey_hex] = m

    sorted_members = sorted(by_pk.values(), key=lambda x: x.pubkey_hex)
    total_w = sum(m.reputation_weight for m in sorted_members)
    if quorum_weight_sum_required > total_w:
        raise ValueError("quorum_weight_sum_required exceeds sum of member weights")

    hs: list[str] = []
    if relay_hints:
        hs = sorted({str(h).strip() for h in relay_hints if str(h).strip()})
        for h in hs:
            if len(h) > _MAX_RELAY_HINT_LEN:
                raise ValueError("relay_hints entry too long")

    addr = janet_validators_group_address_v1()
    rows = [
        {"pubkey_hex": m.pubkey_hex, "reputation_weight": int(m.reputation_weight)} for m in sorted_members
    ]
    obj: dict[str, Any] = {
        "epoch": int(epoch),
        "group_address_hex": addr,
        "group_slug": GROUP_SLUG_JANET_VALIDATORS,
        "janet_policy_codes": pol,
        "members": rows,
        "monotonic_counter": int(monotonic_counter),
        "quorum_weight_sum_required": int(quorum_weight_sum_required),
        "relay_hints": hs,
        "schema": _SCHEMA,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def verify_nip29_validators_provision_canonical(canonical_json: str) -> dict[str, Any]:
    """Parse provision JSON and require bit-identical canonical form (same pattern as gap_reward)."""
    raw = canonical_json.strip()
    obj = json.loads(raw)
    if not isinstance(obj, Mapping):
        raise ValueError("provision must be a JSON object")
    if obj.get("schema") != _SCHEMA:
        raise ValueError(f"schema must be {_SCHEMA!r}")
    try:
        mems = obj["members"]
        if not isinstance(mems, list):
            raise TypeError("members must be a list")
        members = [
            ValidatorMember(
                pubkey_hex=str(row["pubkey_hex"]),
                reputation_weight=int(row["reputation_weight"]),
            )
            for row in mems
        ]
        rh = obj.get("relay_hints")
        if rh is not None and not isinstance(rh, list):
            raise TypeError("relay_hints must be a list or absent")
        hints = cast(Sequence[str] | None, rh)
        rebuilt = nip29_validators_provision_payload_canonical(
            epoch=int(obj["epoch"]),
            monotonic_counter=int(obj["monotonic_counter"]),
            members=members,
            quorum_weight_sum_required=int(obj["quorum_weight_sum_required"]),
            janet_policy_codes=list(obj["janet_policy_codes"]),
            relay_hints=hints,
        )
    except (KeyError, TypeError, ValueError) as e:
        raise ValueError(f"invalid validators provision: {e}") from e
    if rebuilt != raw:
        raise ValueError("canonical JSON mismatch (tampering or non-canonical input)")
    return dict(obj)


def auto_provision_janet_validators_payload(
    *,
    epoch: int,
    monotonic_counter: int,
    members: Sequence[tuple[str, int]],
    quorum_weight_sum_required: int,
    relay_hints: Sequence[str] | None = None,
) -> str:
    """
    Convenience: build ``members`` from ``(pubkey_hex, reputation_weight)`` tuples with default policies.

    Same canonical output as :func:`nip29_validators_provision_payload_canonical`.
    """
    vm = [ValidatorMember(pubkey_hex=a, reputation_weight=b) for a, b in members]
    return nip29_validators_provision_payload_canonical(
        epoch=epoch,
        monotonic_counter=monotonic_counter,
        members=vm,
        quorum_weight_sum_required=quorum_weight_sum_required,
        relay_hints=relay_hints,
    )


def roster_weights_from_provision_dict(provision: Mapping[str, Any]) -> dict[str, int]:
    """``pubkey_hex -> reputation_weight`` for :func:`accumulated_vote_weight`."""
    out: dict[str, int] = {}
    mems = provision.get("members")
    if not isinstance(mems, list):
        raise ValueError("members must be a list")
    for row in mems:
        if not isinstance(row, Mapping):
            raise ValueError("member row must be an object")
        pk = _hex64("pubkey_hex", str(row["pubkey_hex"]))
        w = int(row["reputation_weight"])
        if w < 1:
            raise ValueError("reputation_weight must be >= 1")
        out[pk] = w
    return out
