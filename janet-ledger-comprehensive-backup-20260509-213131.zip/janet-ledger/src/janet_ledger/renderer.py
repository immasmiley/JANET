"""Deterministic surface renderer: variants, safety §5.4 gate, audit hash."""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence


def _sha256_utf8(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def variant_index(frame_id: str, session_id: str, turn: int, n_variants: int) -> int:
    """
    Deterministic index in [0, n_variants). Uses SHA-256, not built-in hash(),
    so results are stable across processes (PYTHONHASHSEED-independent).
    """
    if n_variants <= 0:
        raise ValueError("n_variants must be positive")
    material = f"{frame_id}|{session_id}|{turn}".encode("utf-8")
    digest = hashlib.sha256(material).digest()
    word = int.from_bytes(digest[:8], "big", signed=False)
    return word % n_variants


VARIANT_TAGS: Sequence[str] = ("alpha", "beta", "gamma", "delta")


def canonical_renderer_config(cfg: Mapping[str, Any]) -> str:
    """Sorted keys, compact JSON, UTF-8 — for render_log_hash input."""
    allowed = {
        "persona_id": cfg["persona_id"],
        "safety_54_active": bool(cfg["safety_54_active"]),
        "verbosity": int(cfg["verbosity"]),
    }
    return json.dumps(allowed, sort_keys=True, separators=(",", ":"))


def render_log_hash(ledger_hash_hex: str, renderer_config: Mapping[str, Any]) -> str:
    """
    Auxiliary audit trail: SHA-256(ledger_hash || renderer_config_canonical) as UTF-8,
    matching ASCII-hex ledger chaining style (64-char hex + canonical JSON string).
    """
    if len(ledger_hash_hex) != 64:
        raise ValueError("ledger_hash_hex must be 64 lowercase hex chars")
    cfg = canonical_renderer_config(renderer_config)
    return _sha256_utf8(ledger_hash_hex + cfg)


@dataclass(frozen=True)
class RendererConfig:
    persona_id: str
    verbosity: int  # 0, 1, 2
    safety_54_active: bool = False


@dataclass(frozen=True)
class RenderInput:
    frame_id: str
    session_id: str
    turn: int
    zone: str
    coord_post_snap: float
    ledger_hash_hex: str  # entry_hash for this row (echo-only from coordinator)


@dataclass(frozen=True)
class RenderResult:
    """Surface bundle; coord and ledger identity are never mutated."""

    surface_text: str
    variant_index: int
    variant_tag: str
    render_log_hash: str
    config_used: RendererConfig


def _core_line(
    *,
    zone: str,
    frame_id: str,
    turn: int,
    coord_post_snap: float,
    variant_tag: str,
) -> str:
    return (
        f"[JANET] zone={zone} frame={frame_id} turn={turn} "
        f"coord={coord_post_snap} var={variant_tag}"
    )


def _persona_verbosity_lines(persona_id: str, verbosity: int) -> list[str]:
    """Affective / stylistic modifiers — suppressed entirely under §5.4."""
    lines: list[str] = []
    if persona_id == "analyst_plain":
        lines.append("SUBJECT: Analysis (neutral)")
        if verbosity >= 1:
            lines.append("DEPTH: standard")
        if verbosity >= 2:
            lines.append("DEPTH: extended|secondary=compliance")
    elif persona_id == "counsel_formal":
        lines.append("SUBJECT: Memorandum of law")
        if verbosity >= 1:
            lines.append("DEPTH: standard")
        if verbosity >= 2:
            lines.append("DEPTH: extended|secondary=citation-density")
    else:
        raise ValueError(f"unknown persona_id: {persona_id!r}")
    return lines


def load_persona_theme(path: str | Path | None) -> dict[str, Any] | None:
    """
    Load optional persona line templates from JSON (CLI / env path).

    Schema::

        {"personas": {"analyst_plain": {"v0": ["..."], "v1": ["..."], "v2": ["..."]}}}

    Unknown ``persona_id`` falls back to built-in templates.
    """
    if path is None:
        return None
    p = Path(path)
    if not p.is_file():
        return None
    raw = json.loads(p.read_text(encoding="utf-8"))
    return raw if isinstance(raw, dict) else None


def persona_theme_from_env() -> dict[str, Any] | None:
    """``JANET_PERSONA_THEME_JSON`` = path to theme file (optional)."""
    env = os.environ.get("JANET_PERSONA_THEME_JSON")
    return load_persona_theme(env) if env else None


def _persona_lines_resolved(
    persona_id: str,
    verbosity: int,
    theme: Mapping[str, Any] | None,
) -> list[str]:
    if theme:
        personas = theme.get("personas")
        if isinstance(personas, Mapping):
            pdata = personas.get(persona_id)
            if isinstance(pdata, Mapping):
                key = f"v{min(max(int(verbosity), 0), 2)}"
                lines = pdata.get(key)
                if isinstance(lines, list) and lines and all(isinstance(x, str) for x in lines):
                    return list(lines)
    return _persona_verbosity_lines(persona_id, verbosity)


def render_surface(
    inp: RenderInput,
    config: RendererConfig,
    *,
    affective_override: str | None = None,
    persona_theme: Mapping[str, Any] | None = None,
) -> RenderResult:
    """
    Build deterministic surface text.

    If ``persona_theme`` is set (or load via ``load_persona_theme`` / ``JANET_PERSONA_THEME_JSON``),
    persona lines come from JSON ``v0``/``v1``/``v2`` lists; otherwise built-in templates apply.

    If safety_54_active is True, no persona or verbosity modifiers are applied.
    If affective_override is non-None while safety_54_active is True, raises
    ValueError (safety gate cannot be overridden).
    """
    if config.safety_54_active and affective_override is not None:
        raise ValueError("§5.4 active: affective/persona override rejected")

    n = len(VARIANT_TAGS)
    vidx = variant_index(inp.frame_id, inp.session_id, inp.turn, n)
    tag = VARIANT_TAGS[vidx]

    if config.safety_54_active:
        surface = _core_line(
            zone=inp.zone,
            frame_id=inp.frame_id,
            turn=inp.turn,
            coord_post_snap=inp.coord_post_snap,
            variant_tag=tag,
        )
    else:
        parts = [
            _core_line(
                zone=inp.zone,
                frame_id=inp.frame_id,
                turn=inp.turn,
                coord_post_snap=inp.coord_post_snap,
                variant_tag=tag,
            )
        ]
        parts.extend(_persona_lines_resolved(config.persona_id, config.verbosity, persona_theme))
        surface = "\n".join(parts)

    # Under §5.4, applied surface ignores persona/verbosity; hash reflects *effective* config.
    if config.safety_54_active:
        cfg_map = {
            "persona_id": "anonymous",
            "safety_54_active": True,
            "verbosity": 0,
        }
    else:
        cfg_map = {
            "persona_id": config.persona_id,
            "safety_54_active": False,
            "verbosity": config.verbosity,
        }
    rhash = render_log_hash(inp.ledger_hash_hex, cfg_map)

    return RenderResult(
        surface_text=surface,
        variant_index=vidx,
        variant_tag=tag,
        render_log_hash=rhash,
        config_used=config,
    )
