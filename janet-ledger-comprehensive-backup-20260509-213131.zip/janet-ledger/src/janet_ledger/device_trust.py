"""
Multi-factor binding: device → user, user → family (passwordless design).

No memorized passwords are modeled here. The **user is protected by the device**
(screen lock, secure enclave, OS gate). The **service** stores only **public**
material (hashes of public keys / credential ids) and **explicit factor codes**
on the ledger.

WebAuthn / passkey **assertion verification** happens in the coordinator (outside
this package); payloads are canonical JSON suitable for ``entry_hash`` chaining.
"""

from __future__ import annotations

import json
import re
from typing import Any, Literal, Sequence

BindingRole = Literal["device_to_user", "user_to_family"]

FACTOR_DEVICE_PASSKEY_001 = "FACTOR-DEVICE-PASSKEY-001"
"""Client proved WebAuthn / passkey; coordinator verified assertion; ledger stores pubkey hash only."""

FACTOR_SCREEN_LOCK_002 = "FACTOR-SCREEN-LOCK-002"
"""Device attests local gate (PIN/biometric) satisfied for this action — trust boundary is the device OS."""

FACTOR_FAMILY_LEDGER_003 = "FACTOR-FAMILY-LEDGER-003"
"""Family-side approval: prior ledger row(s) or HITL token reference already on chain."""

_SCHEMA = "device_trust_binding_v1"

_HEX64 = re.compile(r"^[0-9a-f]{64}$")


def _sorted_parents(parents: Sequence[str]) -> list[str]:
    out = [p.lower() for p in parents]
    for p in out:
        if not _HEX64.match(p):
            raise ValueError("parent_entry_hashes must be 64-char lowercase hex")
    return sorted(out)


def identity_binding_canonical(
    role: BindingRole,
    *,
    device_pubkey_sha256_hex: str,
    factors_applied: Sequence[str],
    parent_entry_hashes: Sequence[str],
    user_pubkey_sha256_hex: str | None = None,
    family_ledger_anchor_hex: str | None = None,
    family_graph_n_index: int | None = None,
    hitl_token: str | None = None,
    note: str | None = None,
) -> str:
    """
    One canonical ledger row body for a multi-factor binding (sorted keys).

    - **device_to_user**: bind this device's passkey material to a logical user
      record (``user_pubkey_sha256_hex`` optional if same as device for single-key users).
    - **user_to_family**: bind that user into a family context using
      ``family_ledger_anchor_hex`` (64-hex tip or agreed anchor row) and optional
      ``family_graph_n_index`` when mapped onto the 217 ring.

    ``factors_applied`` is an **ordered** list of ``FACTOR-*`` codes (declaration order
    is preserved in JSON array order — use a tuple when calling for stability).
    """
    d = device_pubkey_sha256_hex.lower()
    if not _HEX64.match(d):
        raise ValueError("device_pubkey_sha256_hex must be 64 lowercase hex chars")
    up: str | None = None
    if user_pubkey_sha256_hex is not None:
        up = user_pubkey_sha256_hex.lower()
        if not _HEX64.match(up):
            raise ValueError("user_pubkey_sha256_hex must be 64 lowercase hex chars")
    fa: str | None = None
    if family_ledger_anchor_hex is not None:
        fa = family_ledger_anchor_hex.lower()
        if not _HEX64.match(fa):
            raise ValueError("family_ledger_anchor_hex must be 64 lowercase hex chars")
    if family_graph_n_index is not None and (
        not isinstance(family_graph_n_index, int) or family_graph_n_index < 0 or family_graph_n_index > 216
    ):
        raise ValueError("family_graph_n_index must be 0..216 or None")
    if not factors_applied:
        raise ValueError("factors_applied must be non-empty")
    obj: dict[str, Any] = {
        "device_pubkey_sha256_hex": d,
        "event_subtype": "identity_binding",
        "factors_applied": list(factors_applied),
        "parent_entry_hashes": _sorted_parents(parent_entry_hashes),
        "role": role,
        "schema": _SCHEMA,
    }
    if up is not None:
        obj["user_pubkey_sha256_hex"] = up
    if fa is not None:
        obj["family_ledger_anchor_hex"] = fa
    if family_graph_n_index is not None:
        obj["family_graph_n_index"] = int(family_graph_n_index)
    if hitl_token is not None and hitl_token.strip():
        obj["hitl_token"] = hitl_token.strip()
    if note is not None and note.strip():
        obj["note"] = note.strip()[:500]
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))
