"""JANET substrate constants (217-node line, δ = 100/108)."""

DELTA: float = 100.0 / 108.0

K_MIN = -108
K_MAX = 108


def k_index_from_coord(c: float) -> int:
    """Map a coordinate to nearest lattice index k (pre/post snap per manifest)."""
    return round(c / DELTA)
