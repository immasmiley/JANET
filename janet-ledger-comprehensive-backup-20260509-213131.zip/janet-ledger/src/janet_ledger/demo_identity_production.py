"""
Production demo identity — native coordinator contracts.

``janet_ledger`` cannot open Secure Enclave, TPM, or live WebSockets from this
package. This module defines **Protocols**, an **extended retirement step list**
including relay disconnect, and a **guard** against wiring the CI memory vault
into production builds.

Call ``assert_no_ci_memory_vault_in_production(vault)`` from your native bridge
after constructing the vault adapter.
"""

from __future__ import annotations

import os
from typing import Any, Protocol, runtime_checkable

from janet_ledger.demo_identity import RETIREMENT_STEP_ORDER, InMemoryDemoKeyVault

ALLOW_CI_DEMO_MEMORY_VAULT_ENV = "JANET_ALLOW_CI_DEMO_MEMORY_VAULT"


def assert_no_ci_memory_vault_in_production(vault: object) -> None:
    """
    Raises ``TypeError`` if the vault is ``InMemoryDemoKeyVault`` unless
    ``JANET_ALLOW_CI_DEMO_MEMORY_VAULT=1`` (unit tests only).
    """
    if isinstance(vault, InMemoryDemoKeyVault) and os.environ.get(ALLOW_CI_DEMO_MEMORY_VAULT_ENV) != "1":
        raise TypeError(
            "InMemoryDemoKeyVault is forbidden in production demo paths; "
            "use platform HardwareDemoSigning + secure keystore, or set "
            f"{ALLOW_CI_DEMO_MEMORY_VAULT_ENV}=1 only in CI unit tests"
        )


RETIREMENT_STEP_ORDER_LIVE: tuple[str, ...] = RETIREMENT_STEP_ORDER + (
    "await_relay_propagation_optional",
    "disconnect_relay_pool",
)


@runtime_checkable
class HardwareDemoSigning(Protocol):
    """
    Platform-native demo signing (SecKey / Android Keystore / CNG-TPM / TPM2).

    Implementations MUST keep private material non-exportable; return only
    signatures and public key material for Nostr wire format assembly elsewhere.
    """

    def demo_sign_event_id(self, demo_key_handle_id: str, event_id_hex: str) -> str:
        """Return 128-char hex Schnorr signature for Nostr event id (wire format)."""
        ...

    def delete_demo_key(self, demo_key_handle_id: str) -> None:
        """Irreversible hardware deletion of the demo private key."""
        ...

    def demo_pubkey_hex_for_handle(self, demo_key_handle_id: str) -> str:
        """Return 64-char lowercase x-only pubkey hex for payloads."""
        ...


@runtime_checkable
class LiveNostrRelayPool(Protocol):
    """
    Live WebSocket pool restricted to demo traffic (separate object from real pool).
    """

    def connect_and_handshake(self, *, ok_timeout_s: float, auth_policy: str) -> None:
        """NIP-01 ``OK`` and optional NIP-42 ``AUTH`` until healthy or raise."""
        ...

    def publish_signed_event(self, signed_event: dict[str, Any]) -> str:
        """Send EVENT; return assigned event id from relay response / local id."""
        ...

    def subscribe_demo_namespace(self, filters: list[dict[str, Any]]) -> None:
        """REQ with ``#d`` / author filters scoped to ``demo_`` keys only."""
        ...

    def disconnect_all(self) -> None:
        """Clean close after retirement; do not touch real identity sockets."""
        ...


@runtime_checkable
class DemoHardwareAttestation(Protocol):
    """Optional: DeviceCheck / Play Integrity / TPM quote before first demo publish."""

    def assert_demo_environment_ok(self) -> None:
        """Raise if jailbreak / debugger / integrity failure (product policy)."""
        ...
