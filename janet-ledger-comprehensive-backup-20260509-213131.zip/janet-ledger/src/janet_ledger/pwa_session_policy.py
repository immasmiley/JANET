"""
Desktop root + volatile PWA: delegation offer (NIP-26 handoff envelope) and
session revocation (NIP-33) as **canonical sorted JSON** for JANET audit mirroring.

Wire signing (NIP-01 / NIP-26 / NIP-44) is native / browser; this module only
defines **policy-coded payloads** and **capability constants**.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Literal, Sequence

from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001

SESSION_DELEGATE_001 = "SESSION-DELEGATE-001"
"""Desktop-issued scoped delegation metadata bound to PWA ephemeral material."""

SESSION_REVOKE_001 = "SESSION-REVOKE-001"
"""NIP-33 ``d: session-revoke-pwa`` — forces PWA wipe; monotonic per desktop author."""

# PWA may only use these Nostr kinds for publish/subscribe (relay + client deny).
ALLOWED_PWA_KINDS: frozenset[int] = frozenset((1, 4, 29))

# NIP-26 gap-only delegation: PWA may publish **only** this kind for gap proposals (no bind/reward).
PWA_GAP_PROPOSAL_KIND = 38822
ALLOWED_PWA_GAP_DELEGATION_KINDS: frozenset[int] = frozenset((PWA_GAP_PROPOSAL_KIND,))

_SCHEMA_DELEGATION_OFFER = "janet_pwa_delegation_offer_v1"
_SCHEMA_SESSION_REVOKE = "nip33_janet_session_revoke_pwa_v1"

_HEX64 = re.compile(r"^[0-9a-f]{64}$")


def _hex64(name: str, value: str) -> str:
    v = value.lower()
    if not _HEX64.match(v):
        raise ValueError(f"{name} must be 64 lowercase hex chars")
    return v


def _sorted_policies(codes: Sequence[str]) -> list[str]:
    if not codes:
        raise ValueError("janet_policy_codes must be non-empty")
    out = sorted({str(c).strip() for c in codes if str(c).strip()})
    if not out:
        raise ValueError("janet_policy_codes must be non-empty")
    return out


def _sorted_kinds(
    kinds: Sequence[int],
    *,
    permitted: frozenset[int] = ALLOWED_PWA_KINDS,
) -> list[int]:
    u = sorted({int(k) for k in kinds})
    if not u:
        raise ValueError("allowed_kinds must be non-empty")
    for k in u:
        if k not in permitted:
            raise ValueError(f"kind {k} not permitted for this delegation (allowed: {sorted(permitted)})")
    return u


def delegation_session_offer_canonical(
    *,
    pwa_ephemeral_pubkey_hex: str,
    allowed_kinds: Sequence[int],
    until_unix: int,
    janet_policy_codes: Sequence[str],
    nip44_session_pubkey_hex: str | None = None,
    desktop_audit_prev_hash_hex: str | None = None,
    permitted_publish_kinds: frozenset[int] | None = None,
) -> str:
    """
    QR / local-WebSocket **inner JSON** shipped Desktop→PWA before NIP-26 wire
    assembly. ``until_unix`` is hard wall; PWA MUST refuse use after expiry.

    ``nip44_session_pubkey_hex`` optional 64-hex X25519 (or product-chosen) pubkey
    for NIP-44 session layer binding.

    ``permitted_publish_kinds`` defaults to ``ALLOWED_PWA_KINDS``. Pass
    ``ALLOWED_PWA_GAP_DELEGATION_KINDS`` to restrict NIP-26 to kind ``38822`` only
    (gap proposal bridge; see ``janet_ledger.pwa_gap_bridge``).
    """
    pol = _sorted_policies(janet_policy_codes)
    for req in (SESSION_DELEGATE_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if not isinstance(until_unix, int) or until_unix < 0:
        raise ValueError("until_unix must be int >= 0")
    permitted = permitted_publish_kinds or ALLOWED_PWA_KINDS
    kinds = _sorted_kinds(allowed_kinds, permitted=permitted)
    obj: dict[str, Any] = {
        "allowed_kinds": kinds,
        "janet_policy_codes": pol,
        "pwa_ephemeral_pubkey_hex": _hex64("pwa_ephemeral_pubkey_hex", pwa_ephemeral_pubkey_hex),
        "schema": _SCHEMA_DELEGATION_OFFER,
        "until_unix": int(until_unix),
    }
    if nip44_session_pubkey_hex is not None:
        obj["nip44_session_pubkey_hex"] = _hex64("nip44_session_pubkey_hex", nip44_session_pubkey_hex)
    if desktop_audit_prev_hash_hex is not None:
        obj["desktop_audit_prev_hash_hex"] = _hex64(
            "desktop_audit_prev_hash_hex", desktop_audit_prev_hash_hex
        )
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def delegation_offer_fingerprint_hex(offer_canonical_utf8: str) -> str:
    """SHA-256 hex of offer canonical string; bind revoke row to one delegation."""
    return hashlib.sha256(offer_canonical_utf8.encode("utf-8")).hexdigest()


def nip33_session_revoke_pwa_payload_canonical(
    *,
    chain_prev_event_id_hex: str,
    delegate_fingerprint_hex: str,
    epoch: int,
    monotonic_counter: int,
    janet_policy_codes: Sequence[str],
    d_tag: Literal["session-revoke-pwa"] = "session-revoke-pwa",
) -> str:
    """
    Desktop-signed NIP-33 replaceable **content** for PWA session kill.

    ``delegate_fingerprint_hex`` SHOULD equal ``delegation_offer_fingerprint_hex``
    for the offer being revoked.
    """
    pol = _sorted_policies(janet_policy_codes)
    for req in (SESSION_REVOKE_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if d_tag != "session-revoke-pwa":
        raise ValueError("d_tag must be 'session-revoke-pwa'")
    if not isinstance(epoch, int) or epoch < 0:
        raise ValueError("epoch must be int >= 0")
    if not isinstance(monotonic_counter, int) or monotonic_counter < 0:
        raise ValueError("monotonic_counter must be int >= 0")
    obj: dict[str, Any] = {
        "chain_prev_event_id_hex": _hex64("chain_prev_event_id_hex", chain_prev_event_id_hex),
        "d_tag": d_tag,
        "delegate_fingerprint_hex": _hex64("delegate_fingerprint_hex", delegate_fingerprint_hex),
        "epoch": int(epoch),
        "janet_policy_codes": pol,
        "monotonic_counter": int(monotonic_counter),
        "schema": _SCHEMA_SESSION_REVOKE,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def pwa_relay_req_filter_capsule_canonical(
    *,
    authors_hex: Sequence[str],
    kinds: Sequence[int],
    permitted_publish_kinds: frozenset[int] | None = None,
) -> str:
    """
    Deterministic REQ filter capsule for **PWA-only** pools (subset enforcement).

    ``kinds`` must be non-empty subset of ``permitted_publish_kinds`` (default
    ``ALLOWED_PWA_KINDS``). ``authors_hex`` sorted for set semantics.
    """
    permitted = permitted_publish_kinds or ALLOWED_PWA_KINDS
    ks = _sorted_kinds(kinds, permitted=permitted)
    if not authors_hex:
        raise ValueError("authors_hex must be non-empty")
    auths = sorted({_hex64("authors_hex", a) for a in authors_hex})
    obj: dict[str, Any] = {"authors_hex": auths, "kinds": ks, "schema": "janet_pwa_req_filter_v1"}
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))
