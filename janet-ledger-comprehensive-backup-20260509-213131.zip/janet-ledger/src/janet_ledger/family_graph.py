"""Family graph addressing: 7×31 ring, BAT tiers, validation (Family Graph2 / family-graph.js)."""

from __future__ import annotations

from typing import TypedDict, cast

from janet_ledger.family_taxonomy import RelationshipType, is_valid_rel_type
from janet_ledger.lattice217 import HALF_IDX, N_NODES, USER_N_INDEX

RESERVED_BAND_START = 186
RESERVED_BAND_END = 216
FAMILY_SLOTS = 186


class SelfDegreeType(TypedDict):
    degree: int
    rel_type: int
    self: bool


class ReservedInfo(TypedDict):
    reserved: bool
    n_index: int


class ValidateOk(TypedDict, total=False):
    ok: bool
    n_index: int
    degree: int
    rel_type: int
    janet_n: int
    tier: str
    polling: int
    vouches: int


class ValidateErr(TypedDict, total=False):
    ok: bool
    error: str
    expected: int
    got: int


SELF_ANCHOR: dict[str, int] = {
    "n_index": USER_N_INDEX,
    "janet_n": HALF_IDX,
    "degree": 4,
    "rel_type": int(RelationshipType.ADOPTIVE_CHILD),
}


class SlotBinding(TypedDict):
    degree: int
    rel_type: int


def degree_and_type_for(n_index: int) -> SelfDegreeType | ReservedInfo | SlotBinding:
    if not isinstance(n_index, int) or n_index < 0 or n_index >= N_NODES:
        raise ValueError(f"n_index out of range: {n_index}")
    if n_index == USER_N_INDEX:
        return {
            "degree": SELF_ANCHOR["degree"],
            "rel_type": SELF_ANCHOR["rel_type"],
            "self": True,
        }
    if n_index >= RESERVED_BAND_START:
        return {"reserved": True, "n_index": n_index}
    degree = n_index // 31 + 1
    rel_type = n_index % 31 + 1
    return SlotBinding(degree=degree, rel_type=rel_type)


def n_index_for(degree: int, rel_type: int) -> int:
    if not isinstance(degree, int) or degree < 1 or degree > 6:
        raise ValueError(f"degree must be 1..6: {degree}")
    if not is_valid_rel_type(rel_type):
        raise ValueError(f"rel_type must be 1..31: {rel_type}")
    return (degree - 1) * 31 + (rel_type - 1)


def is_reserved(n_index: int) -> bool:
    return RESERVED_BAND_START <= n_index <= RESERVED_BAND_END


def bat_tier_for_degree(degree: int) -> str:
    if degree in (1, 2):
        return "hot"
    if degree in (3, 4):
        return "warm"
    if degree in (5, 6):
        return "cold"
    raise ValueError(f"degree must be 1..6: {degree}")


def polling_steps_for_degree(degree: int) -> int:
    tier = bat_tier_for_degree(degree)
    if tier == "hot":
        return 27
    if tier == "warm":
        return 54
    return 108


def vouch_threshold_for_degree(degree: int) -> int:
    tier = bat_tier_for_degree(degree)
    if tier == "hot":
        return 0
    if tier == "warm":
        return 1
    return 2


def reserved_bridge_index(bridge_key_hex: str) -> int:
    h = 0
    for ch in bridge_key_hex:
        h = (h * 31 + ord(ch)) & 0xFFFFFFFF
    span = RESERVED_BAND_END - RESERVED_BAND_START + 1
    return RESERVED_BAND_START + (h % span)


def validate_member(
    *,
    n_index: int,
    rel_type: int | None = None,
    degree: int | None = None,
) -> ValidateOk | ValidateErr:
    if n_index == USER_N_INDEX:
        d = SELF_ANCHOR["degree"]
        return {
            "ok": True,
            "n_index": USER_N_INDEX,
            "janet_n": HALF_IDX,
            "degree": d,
            "rel_type": int(RelationshipType.ADOPTIVE_CHILD),
            "tier": bat_tier_for_degree(d),
            "polling": polling_steps_for_degree(d),
            "vouches": vouch_threshold_for_degree(d),
        }
    dt = degree_and_type_for(n_index)
    if dt.get("reserved"):
        return {"ok": False, "error": "reserved_band"}
    slot = cast(SlotBinding, dt)
    if rel_type is not None and rel_type != slot["rel_type"]:
        return {
            "ok": False,
            "error": "rel_type_mismatch",
            "expected": slot["rel_type"],
            "got": rel_type,
        }
    if degree is not None and degree != slot["degree"]:
        return {
            "ok": False,
            "error": "degree_mismatch",
            "expected": slot["degree"],
            "got": degree,
        }
    d = slot["degree"]
    rt = slot["rel_type"]
    return {
        "ok": True,
        "n_index": n_index,
        "degree": d,
        "rel_type": rt,
        "tier": bat_tier_for_degree(d),
        "polling": polling_steps_for_degree(d),
        "vouches": vouch_threshold_for_degree(d),
    }


def assert_mandates() -> None:
    sd = degree_and_type_for(USER_N_INDEX)
    if sd.get("degree") != 4 or sd.get("rel_type") != int(RelationshipType.ADOPTIVE_CHILD):
        raise RuntimeError(
            f"MANDATE FAIL: degree_and_type_for(0) must be (4, ADOPTIVE_CHILD), got "
            f"({sd.get('degree')}, {sd.get('rel_type')})"
        )
    if FAMILY_SLOTS + (RESERVED_BAND_END - RESERVED_BAND_START + 1) != N_NODES:
        raise RuntimeError("MANDATE FAIL: 7×31=217 factorisation broken")
    if 6 * 31 != FAMILY_SLOTS:
        raise RuntimeError("MANDATE FAIL: family slot count mismatch")
