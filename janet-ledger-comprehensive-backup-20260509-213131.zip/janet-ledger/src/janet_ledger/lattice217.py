"""217-node JANET line in family-app indexing (n = 0..216), rational δ = 25/27."""

from __future__ import annotations

from fractions import Fraction

# Aligns with janet_ledger.constants.DELTA == 100/108 == 25/27
DELTA_NUM = 25
DELTA_DEN = 27
N_NODES = 217
HALF_IDX = 108  # equilibrium: x_108 = 0
USER_N_INDEX = 0
RANGE_MIN = Fraction(-100)
RANGE_MAX = Fraction(100)
FRACTAL_SEED_RATIO = Fraction(3, 216)


def delta_frac() -> Fraction:
    return Fraction(DELTA_NUM, DELTA_DEN)


def x_at(n: int) -> float:
    """x_n = -100 + n * (25/27), materialised as float for interop."""
    if not isinstance(n, int) or n < 0 or n >= N_NODES:
        raise ValueError(f"n out of [0, {N_NODES - 1}]: {n}")
    return float(RANGE_MIN + Fraction(n) * delta_frac())


def x_at_frac(n: int) -> Fraction:
    if not isinstance(n, int) or n < 0 or n >= N_NODES:
        raise ValueError(f"n out of [0, {N_NODES - 1}]: {n}")
    return RANGE_MIN + Fraction(n) * delta_frac()


def nearest_n(x: float) -> int:
    """Nearest lattice index for x in [-100, 100]."""
    if not isinstance(x, (int, float)) or x != x:
        raise TypeError("x must be finite")
    xc = max(float(RANGE_MIN), min(float(RANGE_MAX), float(x)))
    n = round((Fraction(xc) - RANGE_MIN) * Fraction(DELTA_DEN, DELTA_NUM))
    return max(0, min(N_NODES - 1, int(n)))


def janet_index_for(n_index: int) -> int:
    """Map external user-space family index to wrapped JANET ring index 0..216."""
    return ((n_index + HALF_IDX) % N_NODES + N_NODES) % N_NODES


def antisymmetric_n(n: int) -> int:
    return (N_NODES - 1) - n


def is_equilibrium(n: int) -> bool:
    return n == HALF_IDX


def step_toward_equilibrium(n: int) -> int:
    if n == HALF_IDX:
        return HALF_IDX
    return n + 1 if n < HALF_IDX else n - 1


def trajectory_to_equilibrium(n: int) -> list[int]:
    path = [n]
    cur = n
    guard = N_NODES + 1
    while cur != HALF_IDX and guard > 0:
        cur = step_toward_equilibrium(cur)
        path.append(cur)
        guard -= 1
    return path


def family_n_to_janet_k(n: int) -> int:
    """k in [-108, 108] such that k * δ equals x_n (no wrap for n in 0..216)."""
    return n - HALF_IDX
