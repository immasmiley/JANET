"""
Desktop ↔ PWA **gap_reward bridge**: proposals (PWA), verify/bind/reward (Desktop only), audit chain, settlement dispatch.

- PWA **never** builds ``GAP-REWARD-001`` / ``BINDER-001`` payloads; NIP-26 may scope to kind ``38822`` only.
- Desktop signs vouchers and POSTs **dispatch envelopes** to settlement (see ``settlement_stub``).
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from janet_ledger.gap_reward import GAP_REWARD_001, verify_gap_reward_voucher_canonical
from janet_ledger.ledger import entry_hash
from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001
from janet_ledger.pwa_session_policy import PWA_GAP_PROPOSAL_KIND, delegation_offer_fingerprint_hex

VERIFIER_JANET_001 = "VERIFIER-JANET-001"
"""Desktop verifier gate before bind / reward."""

BINDER_001 = "BINDER-001"
"""Root identity bind step; **Desktop-only** (hardware nsec)."""

PWA_GAP_PROPOSE_001 = "PWA-GAP-PROPOSE-001"
"""PWA-originated gap **proposal** (kind ``38822`` content or bridge mirror); no bind/reward."""

SETTLEMENT_DISPATCH_001 = "SETTLEMENT-DISPATCH-001"
"""Desktop-issued envelope binding voucher + audit head + settlement URL before POST."""

_SCHEMA_PROPOSAL = "janet_pwa_gap_proposal_v1"
_SCHEMA_STATUS = "janet_desktop_gap_bridge_status_v1"
_SCHEMA_MIRROR = "janet_desktop_audit_mirror_pwa_v1"
_SCHEMA_DISPATCH = "janet_desktop_settlement_dispatch_v1"

_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_HEX128 = re.compile(r"^[0-9a-f]{128}$")

_FORBIDDEN_IN_PWA_PROPOSAL = frozenset(
    {
        "binder_pubkey_hex",
        "gap_id",
        "quorum_sigs",
        "verifier_result",
        "badge_slug",
        "triad_hash",
        "janet_gap_reward_badge_v1",
    }
)

BridgePhase = Literal[
    "proposed",
    "verifier_pass",
    "bound",
    "voucher_signed",
    "settlement_posted",
    "rejected",
]


def _hex64(name: str, value: str) -> str:
    v = value.lower()
    if not _HEX64.match(v):
        raise ValueError(f"{name} must be 64 lowercase hex chars")
    return v


def _sorted_policies(codes: Sequence[str]) -> list[str]:
    if not codes:
        raise ValueError("janet_policy_codes must be non-empty")
    out = sorted({str(c).strip() for c in codes if str(c).strip()})
    if not out:
        raise ValueError("janet_policy_codes must be non-empty")
    return out


def assert_pwa_gap_proposal_field_allowlist(obj: Mapping[str, Any]) -> None:
    """Reject PWA payloads that smuggle bind/reward keys (static guard)."""
    for k in obj:
        if k in _FORBIDDEN_IN_PWA_PROPOSAL:
            raise ValueError(f"PWA gap proposal must not contain key {k!r}")


def desktop_audit_chain_append(*, prev_hash_hex: str, row_payload_canonical_utf8: str) -> str:
    """``entry_hash`` wrapper — Desktop JANET audit log (64-hex ASCII ``prev`` || UTF-8 row)."""
    return entry_hash(prev_hash_hex, row_payload_canonical_utf8)


def desktop_audit_mirror_pwa_event_row_canonical(
    *,
    prev_hash_hex: str,
    pwa_nostr_event_id_hex: str,
    pwa_event_kind: int,
    proposal_payload_digest_hex: str,
    delegate_offer_fingerprint_hex: str,
    janet_policy_codes: Sequence[str] | None = None,
) -> tuple[str, str]:
    """
    Append mirror row: returns ``(row_canonical, next_hash)``.

    ``proposal_payload_digest_hex`` SHOULD be ``SHA-256(canonical_proposal_utf8).hexdigest()``.
    """
    pol = _sorted_policies(
        janet_policy_codes or (PWA_GAP_PROPOSE_001, NIP33_JANET_CONTENT_001)
    )
    for req in (PWA_GAP_PROPOSE_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if int(pwa_event_kind) != PWA_GAP_PROPOSAL_KIND:
        raise ValueError(f"pwa_event_kind must be {PWA_GAP_PROPOSAL_KIND}")
    row = json.dumps(
        {
            "delegate_offer_fingerprint_hex": _hex64(
                "delegate_offer_fingerprint_hex", delegate_offer_fingerprint_hex
            ),
            "janet_policy_codes": pol,
            "proposal_payload_digest_hex": _hex64(
                "proposal_payload_digest_hex", proposal_payload_digest_hex
            ),
            "pwa_event_kind": int(pwa_event_kind),
            "pwa_nostr_event_id_hex": _hex64("pwa_nostr_event_id_hex", pwa_nostr_event_id_hex),
            "schema": _SCHEMA_MIRROR,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    nxt = desktop_audit_chain_append(prev_hash_hex=prev_hash_hex, row_payload_canonical_utf8=row)
    return row, nxt


def pwa_gap_proposal_payload_canonical(
    *,
    gap_claim_digest_hex: str,
    delegate_offer_fingerprint_hex: str,
    pwa_delegate_pubkey_hex: str,
    proposed_at_unix: int,
    janet_policy_codes: Sequence[str] | None = None,
    evidence_ref_digests_hex: Sequence[str] | None = None,
) -> str:
    """
    PWA → Desktop bridge body (QR/WSS/local). **No** binder / triad / reward fields.

    Publish on Nostr as kind ``38822`` **content** = this string (product choice).
    """
    pol = _sorted_policies(janet_policy_codes or (PWA_GAP_PROPOSE_001, NIP33_JANET_CONTENT_001))
    for req in (PWA_GAP_PROPOSE_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    if not isinstance(proposed_at_unix, int) or proposed_at_unix < 0:
        raise ValueError("proposed_at_unix must be int >= 0")
    obj: dict[str, Any] = {
        "delegate_offer_fingerprint_hex": _hex64(
            "delegate_offer_fingerprint_hex", delegate_offer_fingerprint_hex
        ),
        "gap_claim_digest_hex": _hex64("gap_claim_digest_hex", gap_claim_digest_hex),
        "janet_policy_codes": pol,
        "proposal_kind": PWA_GAP_PROPOSAL_KIND,
        "proposed_at_unix": int(proposed_at_unix),
        "pwa_delegate_pubkey_hex": _hex64("pwa_delegate_pubkey_hex", pwa_delegate_pubkey_hex),
        "schema": _SCHEMA_PROPOSAL,
    }
    if evidence_ref_digests_hex:
        digs = sorted({_hex64("evidence_ref_digests_hex", x) for x in evidence_ref_digests_hex})
        obj["evidence_ref_digests_hex"] = digs
    assert_pwa_gap_proposal_field_allowlist(obj)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def verify_pwa_gap_proposal_canonical(canonical_json: str) -> dict[str, Any]:
    raw = canonical_json.strip()
    obj = json.loads(raw)
    if not isinstance(obj, Mapping):
        raise ValueError("proposal must be a JSON object")
    assert_pwa_gap_proposal_field_allowlist(obj)
    if obj.get("schema") != _SCHEMA_PROPOSAL:
        raise ValueError(f"schema must be {_SCHEMA_PROPOSAL!r}")
    try:
        ev = obj.get("evidence_ref_digests_hex")
        rebuilt = pwa_gap_proposal_payload_canonical(
            gap_claim_digest_hex=str(obj["gap_claim_digest_hex"]),
            delegate_offer_fingerprint_hex=str(obj["delegate_offer_fingerprint_hex"]),
            pwa_delegate_pubkey_hex=str(obj["pwa_delegate_pubkey_hex"]),
            proposed_at_unix=int(obj["proposed_at_unix"]),
            janet_policy_codes=list(obj["janet_policy_codes"]),
            evidence_ref_digests_hex=list(ev) if ev is not None else None,
        )
    except (KeyError, TypeError, ValueError) as e:
        raise ValueError(f"invalid PWA gap proposal: {e}") from e
    if rebuilt != raw:
        raise ValueError("canonical JSON mismatch")
    return dict(obj)


def desktop_gap_bind_row_canonical(
    *,
    gap_id_hex: str,
    triad_hash_hex: str,
    desktop_root_pubkey_hex: str,
    verifier_result: Literal["PASS", "FAIL"],
    proposal_fingerprint_hex: str,
    janet_policy_codes: Sequence[str] | None = None,
) -> str:
    """Desktop-only bind row (append to audit before voucher)."""
    pol = _sorted_policies(
        janet_policy_codes or (VERIFIER_JANET_001, BINDER_001, NIP33_JANET_CONTENT_001)
    )
    for req in (VERIFIER_JANET_001, BINDER_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    obj: dict[str, Any] = {
        "binder_pubkey_hex": _hex64("desktop_root_pubkey_hex", desktop_root_pubkey_hex),
        "gap_id": _hex64("gap_id_hex", gap_id_hex),
        "janet_policy_codes": pol,
        "proposal_fingerprint_hex": _hex64("proposal_fingerprint_hex", proposal_fingerprint_hex),
        "schema": "janet_desktop_gap_bind_v1",
        "triad_hash": _hex64("triad_hash_hex", triad_hash_hex),
        "verifier_result": verifier_result,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def desktop_gap_bridge_status_canonical(
    *,
    phase: BridgePhase,
    last_audit_hash_hex: str,
    proposal_fingerprint_hex: str,
    gap_id_hex: str | None,
    janet_policy_codes: Sequence[str] | None = None,
) -> str:
    """Desktop → PWA poll payload (unsigned)."""
    pol = _sorted_policies(janet_policy_codes or (PWA_GAP_PROPOSE_001, NIP33_JANET_CONTENT_001))
    for req in (PWA_GAP_PROPOSE_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    obj: dict[str, Any] = {
        "janet_policy_codes": pol,
        "last_audit_hash_hex": _hex64("last_audit_hash_hex", last_audit_hash_hex),
        "phase": phase,
        "proposal_fingerprint_hex": _hex64("proposal_fingerprint_hex", proposal_fingerprint_hex),
        "schema": _SCHEMA_STATUS,
    }
    if gap_id_hex is not None:
        obj["gap_id_hex"] = _hex64("gap_id_hex", gap_id_hex)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def nip01_challenge_hash_for_desktop_utf8(*, tagged_payload_utf8: str) -> str:
    """
    Double-SHA-256 over UTF-8 bytes (Nostr-style id preimage pattern).

    Native: ``msg32 = bytes.fromhex(nip01_challenge_hash_for_desktop_utf8(...))`` for Schnorr.
    """
    h1 = hashlib.sha256(tagged_payload_utf8.encode("utf-8")).digest()
    return hashlib.sha256(h1).hexdigest()


def desktop_settlement_dispatch_envelope_canonical(
    *,
    voucher_canonical: str,
    settlement_post_url: str,
    audit_row_hash_after_voucher_hex: str,
    desktop_root_pubkey_hex: str,
    janet_policy_codes: Sequence[str] | None = None,
) -> str:
    """
    Canonical JSON Desktop signs (challenge via :func:`nip01_challenge_hash_for_desktop_utf8`)
    before POST to settlement. **PWA must never** POST this envelope.
    """
    verify_gap_reward_voucher_canonical(voucher_canonical)
    pol = _sorted_policies(
        janet_policy_codes
        or (SETTLEMENT_DISPATCH_001, GAP_REWARD_001, NIP33_JANET_CONTENT_001)
    )
    for req in (SETTLEMENT_DISPATCH_001, GAP_REWARD_001, NIP33_JANET_CONTENT_001):
        if req not in pol:
            raise ValueError(f"janet_policy_codes must include {req!r}")
    url = settlement_post_url.strip()
    if not url or len(url) > 512:
        raise ValueError("settlement_post_url must be 1..512 chars after strip")
    obj: dict[str, Any] = {
        "audit_row_hash_after_voucher_hex": _hex64(
            "audit_row_hash_after_voucher_hex", audit_row_hash_after_voucher_hex
        ),
        "desktop_root_pubkey_hex": _hex64("desktop_root_pubkey_hex", desktop_root_pubkey_hex),
        "janet_policy_codes": pol,
        "schema": _SCHEMA_DISPATCH,
        "settlement_post_url": url,
        "voucher_canonical": voucher_canonical,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def verify_desktop_settlement_dispatch_canonical(canonical_json: str) -> dict[str, Any]:
    raw = canonical_json.strip()
    obj = json.loads(raw)
    if not isinstance(obj, Mapping):
        raise ValueError("dispatch must be a JSON object")
    if obj.get("schema") != _SCHEMA_DISPATCH:
        raise ValueError(f"schema must be {_SCHEMA_DISPATCH!r}")
    try:
        vc = str(obj["voucher_canonical"])
        rebuilt = desktop_settlement_dispatch_envelope_canonical(
            voucher_canonical=vc,
            settlement_post_url=str(obj["settlement_post_url"]),
            audit_row_hash_after_voucher_hex=str(obj["audit_row_hash_after_voucher_hex"]),
            desktop_root_pubkey_hex=str(obj["desktop_root_pubkey_hex"]),
            janet_policy_codes=list(obj["janet_policy_codes"]),
        )
    except (KeyError, TypeError, ValueError) as e:
        raise ValueError(f"invalid settlement dispatch: {e}") from e
    if rebuilt != raw:
        raise ValueError("canonical JSON mismatch")
    return dict(obj)


def parse_desktop_settlement_http_body(body: bytes) -> tuple[str, str | None]:
    """
    POST body: raw ``voucher_canonical`` **or**
    ``{"settlement_dispatch_canonical": "<dispatch>", "desktop_schnorr_sig_hex": "<128hex|null>"}``.
    Returns ``(voucher_canonical, optional_sig_hex)``.
    """
    text = body.decode("utf-8").strip()
    if not text:
        raise ValueError("empty body")
    if not text.startswith("{"):
        return text, None
    outer = json.loads(text)
    if not isinstance(outer, dict):
        raise ValueError("JSON body must be an object")
    if "settlement_dispatch_canonical" in outer:
        dispatch = str(outer["settlement_dispatch_canonical"])
        verify_desktop_settlement_dispatch_canonical(dispatch)
        d = json.loads(dispatch)
        sig = outer.get("desktop_schnorr_sig_hex")
        if sig is not None:
            s = str(sig).lower().strip()
            if s and not _HEX128.match(s):
                raise ValueError("desktop_schnorr_sig_hex must be 128 lowercase hex or empty")
            return str(d["voucher_canonical"]), s or None
        return str(d["voucher_canonical"]), None
    return text, None


def proposal_fingerprint_from_canonical(proposal_canonical_utf8: str) -> str:
    """SHA-256 hex of canonical proposal (binds bind-row to one proposal)."""
    return delegation_offer_fingerprint_hex(proposal_canonical_utf8)
