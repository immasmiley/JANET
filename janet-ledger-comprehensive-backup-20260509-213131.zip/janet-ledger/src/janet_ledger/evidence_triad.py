"""
Deterministic evidence → JANET triadic parent indices (policy JANET-EVTRIAD-001).

Location: only **GEO-PROJ-001** (fixed grid → canonical cell → SHA-256 → mod 217 → k).
Language: only **LANG-MATCH-001** (user-confirmed ISO 639-1 tag → hash → mod 217 → k).
No raw floats in the lattice core; no free-text language; no inference/fallback on tags.

See docs/EVIDENCE_TRIAD.md.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any, Literal, Sequence

from janet_ledger.constants import K_MAX, K_MIN
from janet_ledger.lattice217 import (
    HALF_IDX,
    N_NODES,
    RANGE_MAX,
    RANGE_MIN,
    family_n_to_janet_k,
    nearest_n,
    x_at_frac,
)

TRIPLEX_POLICY_BUNDLE = "JANET-EVTRIAD-001"

# --- GEO-PROJ-001 (normative grid in WGS84 × 1e7 integer space) ---
# Cell width 0.01°; indices i = lat_e7 // step, lon_e7 // step (toward −∞).
GEO_PROJ_GRID_STEP_E7 = 100_000

_LAT_E7_MIN = -900_000_000
_LAT_E7_MAX = 900_000_000
_LON_E7_MIN = -1_800_000_000
_LON_E7_MAX = 1_800_000_000

# --- LANG-MATCH-001 ---
_ISO639_1_RE = re.compile(r"^[a-z]{2}$")


def _clamp_k(k: int) -> int:
    return max(K_MIN, min(K_MAX, int(k)))


def _n_from_sha256_digest(digest: bytes) -> int:
    """First 8 bytes of digest → residue mod 217 (δ-ring index n)."""
    return int.from_bytes(digest[:8], "big", signed=False) % N_NODES


@dataclass(frozen=True)
class GeoCellOverlay:
    """Lattice-safe location overlay: only cells produced under GEO-PROJ-001."""

    policy_id: Literal["GEO-PROJ-001"]
    grid_step_e7: int
    cell_i_lat: int
    cell_i_lon: int
    cell_canonical_utf8: str
    cell_sha256_hex: str
    n_ring: int
    k_location: int


def geo_cell_overlay_from_wgs84_e7(
    lat_e7: int,
    lon_e7: int,
    *,
    policy_id: Literal["GEO-PROJ-001"] = "GEO-PROJ-001",
    grid_step_e7: int = GEO_PROJ_GRID_STEP_E7,
) -> GeoCellOverlay:
    """
    **Single documented ingress** for coordinates: WGS84 quantized to integers
    ``lat_e7 = round(lat_deg * 1e7)``, ``lon_e7 = round(lon_deg * 1e7)`` done **outside**
    this package; this function maps those ints → grid cell → hash → mod 217 → ``k``.

    Raw floats must never be passed in. Triadic ranking must use the returned overlay only.
    """
    if policy_id != "GEO-PROJ-001":
        raise ValueError(f"unsupported geo policy: {policy_id}")
    if grid_step_e7 != GEO_PROJ_GRID_STEP_E7:
        raise ValueError(
            f"grid_step_e7 must equal normative GEO_PROJ_GRID_STEP_E7={GEO_PROJ_GRID_STEP_E7}: "
            f"got {grid_step_e7}"
        )
    if not isinstance(lat_e7, int) or not isinstance(lon_e7, int):
        raise TypeError("lat_e7 and lon_e7 must be int (WGS84 × 1e7); never float")
    if not (_LAT_E7_MIN <= lat_e7 <= _LAT_E7_MAX):
        raise ValueError(f"lat_e7 out of WGS84 range [{_LAT_E7_MIN}, {_LAT_E7_MAX}]: {lat_e7}")
    if not (_LON_E7_MIN <= lon_e7 <= _LON_E7_MAX):
        raise ValueError(f"lon_e7 out of WGS84 range [{_LON_E7_MIN}, {_LON_E7_MAX}]: {lon_e7}")
    if grid_step_e7 <= 0:
        raise ValueError("grid_step_e7 must be positive")

    cell_i_lat = lat_e7 // grid_step_e7
    cell_i_lon = lon_e7 // grid_step_e7
    cell_obj: dict[str, Any] = {
        "geo_policy": policy_id,
        "grid_step_e7": grid_step_e7,
        "i_lat": cell_i_lat,
        "i_lon": cell_i_lon,
    }
    cell_canonical = json.dumps(cell_obj, sort_keys=True, separators=(",", ":"))
    h_cell = hashlib.sha256(cell_canonical.encode("utf-8"))
    digest = h_cell.digest()
    cell_hex = h_cell.hexdigest()
    n_ring = _n_from_sha256_digest(digest)
    k_location = _clamp_k(family_n_to_janet_k(n_ring))
    return GeoCellOverlay(
        policy_id=policy_id,
        grid_step_e7=grid_step_e7,
        cell_i_lat=cell_i_lat,
        cell_i_lon=cell_i_lon,
        cell_canonical_utf8=cell_canonical,
        cell_sha256_hex=cell_hex,
        n_ring=n_ring,
        k_location=k_location,
    )


@dataclass(frozen=True)
class LanguageOverlay:
    """User-confirmed ISO 639-1 only; hash snap under LANG-MATCH-001 (no inference)."""

    policy_id: Literal["LANG-MATCH-001"]
    iso639_1: str
    tag_canonical_utf8: str
    tag_sha256_hex: str
    n_ring: int
    k_language: int


def language_overlay_from_confirmed_iso639_1(
    iso639_1: str,
    *,
    policy_id: Literal["LANG-MATCH-001"] = "LANG-MATCH-001",
) -> LanguageOverlay:
    """
    **Onboarding rule:** pass only the tag the user explicitly selected (two-letter
    ISO 639-1). No leading/trailing whitespace, no interior whitespace, no free-text,
    no locale inference, no fallback.
    """
    if policy_id != "LANG-MATCH-001":
        raise ValueError(f"unsupported language policy: {policy_id}")
    if iso639_1 != iso639_1.strip():
        raise ValueError("LANG-MATCH-001: iso639_1 must have no leading or trailing whitespace")
    if any(ch.isspace() for ch in iso639_1):
        raise ValueError("LANG-MATCH-001: interior whitespace is not allowed in ISO tag")
    s = iso639_1.lower()
    if not _ISO639_1_RE.match(s):
        raise ValueError(
            "LANG-MATCH-001: require user-confirmed ISO 639-1 (exactly two letters a-z); "
            "no free-text or extended tags"
        )
    tag_obj: dict[str, Any] = {"iso639_1": s, "lang_policy": policy_id}
    tag_canonical = json.dumps(tag_obj, sort_keys=True, separators=(",", ":"))
    h_tag = hashlib.sha256(tag_canonical.encode("utf-8"))
    digest = h_tag.digest()
    tag_hex = h_tag.hexdigest()
    n_ring = _n_from_sha256_digest(digest)
    k_language = _clamp_k(family_n_to_janet_k(n_ring))
    return LanguageOverlay(
        policy_id=policy_id,
        iso639_1=s,
        tag_canonical_utf8=tag_canonical,
        tag_sha256_hex=tag_hex,
        n_ring=n_ring,
        k_language=k_language,
    )


# --- BAT-ANC-001 (unchanged) ---
_BAT_ANCHORS: dict[str, int] = {
    "hot": 36,
    "warm": 0,
    "cold": -36,
}


def k_from_bat_tier(tier: Literal["hot", "warm", "cold"], *, policy_id: str = "BAT-ANC-001") -> int:
    if policy_id != "BAT-ANC-001":
        raise ValueError(f"unsupported BAT policy: {policy_id}")
    if tier not in _BAT_ANCHORS:
        raise ValueError(f"tier must be hot|warm|cold: {tier}")
    return _clamp_k(_BAT_ANCHORS[tier])


@dataclass(frozen=True)
class EvidenceTriadResult:
    """Semantic order TRIAD-ORDER-001: A=location overlay, B=BAT, C=language overlay."""

    policy_bundle: str
    geo_overlay: GeoCellOverlay
    lang_overlay: LanguageOverlay
    k_a: int
    k_b: int
    k_c: int
    k_child: int
    k_rank: int
    evidence_fingerprint: int
    policies_applied: tuple[str, ...]


def canonical_evidence_payload(
    *,
    geo: GeoCellOverlay,
    bat_tier: Literal["hot", "warm", "cold"],
    lang: LanguageOverlay,
) -> str:
    """Sorted-key compact JSON for SHA-256 fingerprinting (audit / boosts)."""
    obj: dict[str, Any] = {
        "bat_tier": bat_tier,
        "geo_cell_hash": geo.cell_sha256_hex,
        "geo_cell_i_lat": geo.cell_i_lat,
        "geo_cell_i_lon": geo.cell_i_lon,
        "geo_grid_step_e7": geo.grid_step_e7,
        "geo_policy": geo.policy_id,
        "iso639_1": lang.iso639_1,
        "lang_policy": lang.policy_id,
        "lang_tag_hash": lang.tag_sha256_hex,
        "policy_bundle": TRIPLEX_POLICY_BUNDLE,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def evidence_fingerprint_from_payload(payload_canonical_utf8: str) -> int:
    d = hashlib.sha256(payload_canonical_utf8.encode("utf-8")).digest()
    return int.from_bytes(d[:8], "big", signed=False)


def audit_evidence_binding(result: EvidenceTriadResult) -> dict[str, Any]:
    """JSON-friendly provenance for ledger / HITL (no floats; hashes are hex)."""
    g = result.geo_overlay
    lang = result.lang_overlay
    return {
        "evidence_fingerprint": result.evidence_fingerprint,
        "geo": {
            "cell_canonical_utf8": g.cell_canonical_utf8,
            "cell_sha256_hex": g.cell_sha256_hex,
            "grid_step_e7": g.grid_step_e7,
            "i_lat": g.cell_i_lat,
            "i_lon": g.cell_i_lon,
            "k_location": g.k_location,
            "n_ring": g.n_ring,
            "policy_id": g.policy_id,
        },
        "k_a": result.k_a,
        "k_b": result.k_b,
        "k_c": result.k_c,
        "k_child": result.k_child,
        "k_rank": result.k_rank,
        "lang": {
            "iso639_1": lang.iso639_1,
            "k_language": lang.k_language,
            "n_ring": lang.n_ring,
            "policy_id": lang.policy_id,
            "tag_canonical_utf8": lang.tag_canonical_utf8,
            "tag_sha256_hex": lang.tag_sha256_hex,
        },
        "policies_applied": list(result.policies_applied),
        "policy_bundle": result.policy_bundle,
    }


def triadic_child_k(k_a: int, k_b: int, k_c: int, *, policy_id: str = "TRIAD-CHILD-001") -> int:
    """
    TRIAD-CHILD-001 + TR-SNAP-FLOAT-001: x_sum = x(k_A)+x(k_B)+x(k_C) on the n-ring,
    clamp to [-100,100], then nearest lattice n → k.
    """
    if policy_id != "TRIAD-CHILD-001":
        raise ValueError(f"unsupported triad-child policy: {policy_id}")
    na = k_a + HALF_IDX
    nb = k_b + HALF_IDX
    nc = k_c + HALF_IDX
    x_sum = x_at_frac(na) + x_at_frac(nb) + x_at_frac(nc)
    x_clamped = max(RANGE_MIN, min(RANGE_MAX, x_sum))
    n_child = nearest_n(float(x_clamped))
    return _clamp_k(family_n_to_janet_k(n_child))


def proximity_delta_k(policy_code: str, fingerprint: int) -> int:
    """Integer δ-step boosts only (documented)."""
    if policy_code == "PBOOST-000":
        return 0
    if policy_code == "PBOOST-COHORT-001":
        return (fingerprint % 5) - 2
    raise ValueError(f"unsupported proximity policy: {policy_code}")


def apply_proximity_boosts(
    k_child: int,
    fingerprint: int,
    boost_policies: Sequence[str],
) -> int:
    """Sum Δk from policies in order; clamp to valid k."""
    total = int(k_child)
    for code in boost_policies:
        total += proximity_delta_k(code, fingerprint)
    return _clamp_k(total)


def triadic_parents_from_bound_evidence(
    *,
    geo: GeoCellOverlay,
    bat_tier: Literal["hot", "warm", "cold"],
    iso639_1_confirmed: str,
    boost_policies: Sequence[str] = ("PBOOST-000",),
    bat_policy: str = "BAT-ANC-001",
) -> EvidenceTriadResult:
    """
    Full pipeline after **GEO-PROJ-001** overlay and user-confirmed ISO tag.

    ``iso639_1_confirmed`` must be the exact onboarding selection (validated under
    LANG-MATCH-001). ``geo`` must be produced by ``geo_cell_overlay_from_wgs84_e7``
    (or equivalent test fixture with same invariants).
    """
    if geo.policy_id != "GEO-PROJ-001":
        raise ValueError(f"geo overlay policy must be GEO-PROJ-001: {geo.policy_id}")
    if geo.grid_step_e7 != GEO_PROJ_GRID_STEP_E7:
        raise ValueError("geo overlay grid_step_e7 does not match normative constant")

    lang = language_overlay_from_confirmed_iso639_1(iso639_1_confirmed)

    payload = canonical_evidence_payload(geo=geo, bat_tier=bat_tier, lang=lang)
    fp = evidence_fingerprint_from_payload(payload)

    k_a = geo.k_location
    k_b = k_from_bat_tier(bat_tier, policy_id=bat_policy)
    k_c = lang.k_language

    k_child = triadic_child_k(k_a, k_b, k_c, policy_id="TRIAD-CHILD-001")
    k_rank = apply_proximity_boosts(k_child, fp, boost_policies)

    policies = (
        geo.policy_id,
        bat_policy,
        lang.policy_id,
        "TRIAD-ORDER-001",
        "TRIAD-CHILD-001",
        "TR-SNAP-FLOAT-001",
        *tuple(boost_policies),
    )
    return EvidenceTriadResult(
        policy_bundle=TRIPLEX_POLICY_BUNDLE,
        geo_overlay=geo,
        lang_overlay=lang,
        k_a=k_a,
        k_b=k_b,
        k_c=k_c,
        k_child=k_child,
        k_rank=k_rank,
        evidence_fingerprint=fp,
        policies_applied=policies,
    )
