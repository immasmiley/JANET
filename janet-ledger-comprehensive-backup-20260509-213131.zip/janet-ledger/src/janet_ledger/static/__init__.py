"""Static assets bundled with ``janet_ledger`` (settlement stub test UI)."""
