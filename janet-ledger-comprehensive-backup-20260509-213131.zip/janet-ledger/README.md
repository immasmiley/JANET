# janet-ledger

Manifest-driven reference implementation for:

- **Ledger chain step**: `SHA-256( (prev_hash || payload_canonical).encode("utf-8") )`
- **Zone routing**: FINAL spec intervals + `ZONE-TIE-001` at `c = -25`
- **EQ-NULL-001**: two consecutive turns with `|c_t| < δ`
- **Convergence**: strict equality vs `CONV-ADJ-001` (median `k` within 1)
- **Surface renderer**: deterministic variant selection — *use SHA-256 digest in place of `hash()` for PYTHONHASHSEED-independent determinism*; §5.4 safety strip; `render_log_hash` auxiliary chain

### §4 Ledger continuity (normative)

`Note: prev_hash in the hash input is the 64-character ASCII hex digest, not the 32-byte binary form. This preserves plain-text auditability across HITL logs.`

The reference implementation matches `TEST_MANIFEST.json` golden vectors on this basis. A binary-chaining variant (`entry_hash_binary_prev` in `ledger.py`) exists only for alternate deployments and is not covered by the current goldens.

## Run tests

```bash
cd janet-ledger
pip install -e ".[dev]"
pytest -q
# with coverage (same gate as CI):
pytest -q --cov=janet_ledger --cov-fail-under=85
```

Golden vectors and probes live in `TEST_MANIFEST.json` at the repo root.

## Family graph (JANET Family Chat / Family Graph2 parity)

Python port of the **217-node** kinship ring: **7×31** factorisation, **186** family slots (`0..185`, with **`USER_N_INDEX = 0`** self-anchor), **31** reserved bridge indices (`186..216`), **BAT** tiers (hot/warm/cold), polling steps, vouch thresholds, `reserved_bridge_index`, and `validate_member`.

- **`janet_ledger.family_graph`**: `n_index_for`, `degree_and_type_for`, `assert_mandates`, etc.
- **`janet_ledger.family_taxonomy`**: `RelationshipType` (31 IDs), categories, labels.
- **`janet_ledger.lattice217`**: rational **δ = 25/27** (`x_at`, `nearest_n`, `janet_index_for`, …). **Same step** as `constants.DELTA` (**100/108**). Mapping **`k = n − 108`** links family index `n` to the symmetric **k** line used elsewhere.

Call **`assert_mandates()`** once at coordinator startup (or rely on tests) to pin invariants.

Capability map (mediation, drift, sandboxing, audit, gating, cross-tradition, compliance): **[docs/217_CAPABILITY_MATRIX.md](docs/217_CAPABILITY_MATRIX.md)**. Verified gap closure as a **badge voucher** on the audit chain: **[docs/GAP_REWARD_BADGE.md](docs/GAP_REWARD_BADGE.md)** (`GAP-REWARD-001`).

**Settlement stub (dev):** after `pip install -e .`, run `janet-settlement-stub` or `python -m janet_ledger.settlement_stub` — POST canonical vouchers to `/webhooks/gap-reward`; see [docs/GAP_REWARD_BADGE.md](docs/GAP_REWARD_BADGE.md) §4.

**NIP-29 validators:** `janet-validators` roster + reputation-weighted quorum helpers — [docs/NIP29_VALIDATORS.md](docs/NIP29_VALIDATORS.md).

## Evidence → triadic parents (**JANET-EVTRIAD-001**)

**Location:** WGS84 integers `lat_e7`/`lon_e7` → **`geo_cell_overlay_from_wgs84_e7`** (**`GEO-PROJ-001`**) → fixed **0.01°** grid cell → SHA-256 → mod 217 → **`kδ`** overlay. Raw floats never enter the triadic path.

**Language:** User-confirmed **ISO 639-1** only → **`language_overlay_from_confirmed_iso639_1`** (**`LANG-MATCH-001`**) → hash → mod 217 → **`kδ`**. No free-text or inference. Use **`audit_evidence_binding`** for ledger-ready provenance.

Normative spec: **[docs/EVIDENCE_TRIAD.md](docs/EVIDENCE_TRIAD.md)**. Entrypoint: **`triadic_parents_from_bound_evidence`**.

## HITL pattern knowledge (`hitl_knowledge_v1`)

Log **HITL-validated** coordinate→frame overrides as **`pattern_observation`**; when **≥ 3 distinct sessions** agree on the same **`coord_frame_v1`** key, append **`pattern_confirmed`**. DAG edges = sorted **`parent_entry_hashes`** / **`parent_observation_entry_hashes`** (64-hex ledger hashes). Optional **`sub_lattice_path`** (default **`"0"`**) for recursive overlay addressing without changing δ. Deterministic **`audit_bundle_canonical`** for exports. Spec: **[docs/HITL_KNOWLEDGE.md](docs/HITL_KNOWLEDGE.md)**.

## Device trust (passwordless, multi-factor)

**Device → user** and **user → family** use explicit **`FACTOR-*`** codes plus SHA-256 pubkey material on the ledger; private keys stay on the device. The user relies on **device security** (screen lock, OS gate) and **passkeys**. Normative spec: **[docs/DEVICE_TRUST_MODEL.md](docs/DEVICE_TRUST_MODEL.md)**. Payload builder: **`identity_binding_canonical`** in **`janet_ledger.device_trust`**.

**Nostr NIP-33 inner payloads (rotation / recovery / delegation):** versioned **`ROTATION-EPOCH-001`**, **`RECOVERY-THRESHOLD-001`**, etc., in sorted `janet_policy_codes` — **[docs/NOSTR_JANET_POLICY.md](docs/NOSTR_JANET_POLICY.md)**; builders in **`janet_ledger.nostr_janet_policy`**.

**Desktop + PWA split:** **[docs/DESKTOP_PWA_SPLIT.md](docs/DESKTOP_PWA_SPLIT.md)** — root of trust vs volatile delegate; **`janet_ledger.pwa_session_policy`** (`SESSION-DELEGATE-001`, `SESSION-REVOKE-001`, `ALLOWED_PWA_KINDS`). **Gap bridge (PWA propose → Desktop reward → settlement):** **[docs/BRIDGE_GAP_REWARD.md](docs/BRIDGE_GAP_REWARD.md)** — `janet_ledger.pwa_gap_bridge`. **Native handoff (keystore + relays):** **[docs/NATIVE_INTEGRATION_GUIDE.md](docs/NATIVE_INTEGRATION_GUIDE.md)**.

**Demo identity (canonical payloads + CI state machine):** **[docs/DEMO_IDENTITY.md](docs/DEMO_IDENTITY.md)** — **`janet_ledger.demo_identity`**.

**Demo identity (live hardware + relays):** **[docs/DEMO_IDENTITY_LIVE.md](docs/DEMO_IDENTITY_LIVE.md)** — native coordinator spec; ``HardwareDemoSigning`` / ``LiveNostrRelayPool`` in **`janet_ledger.demo_identity_production`**.

## Toolbox (minimal helpers)

**Audit export:** ``audit_session_bundle_canonical`` — one sorted JSON string combining ``audit_evidence_binding``-style dicts, ledger payload strings, and zone outcome dicts (glue only; persist with your I/O).

**Cache / dedup:** ``cache_key_evidence_fingerprint`` — stable key from an existing fingerprint (no new crypto).

**Replay:** ``diff_manifest_convergence_scenarios`` (two manifest paths), ``diff_canonical_jsonl_lines`` (multiset diff on canonical JSON lines).

**Prefetch / UI:** ``neighbor_n_ring``, ``neighbor_ks_for_k`` — ring adjacency for ``n`` or ``k``.

**Coherence:** ``coherence_binding_vs_zone`` — routed zone vs explicit claim + triadic fingerprint (validation only).

**Kin card:** ``member_ring_snapshot`` — BAT tier, degree, rel_type, polling, vouch for ``n_index``.

**What-if convergence (no storage):** ``python -m janet_ledger.whatif --scenario-json '...'`` or ``whatif_convergence_json`` from code.

**CI policy BOM:** ``python scripts/policy_bom.py -o policy-bom.md`` (lists ``janet_ledger.__all__`` and backtick policy codes from selected ``docs/*.md`` including ``EVIDENCE_TRIAD``, ``HITL_KNOWLEDGE``, ``DEVICE_TRUST_MODEL``, ``NOSTR_JANET_POLICY``, ``DEMO_IDENTITY*``, ``DESKTOP_PWA_SPLIT``, ``GAP_REWARD_BADGE``, ``NIP29_VALIDATORS``, ``BRIDGE_GAP_REWARD``, ``NATIVE_INTEGRATION_GUIDE``).

## Policy-as-config, domain libraries, compliance exports

- **Manifest `policy_config`:** optional ``zone_router.tie_break_coord`` (defaults ``-25``) passed through ``policy_config_from_manifest`` → ``route_zone(..., tie_coord=...)``. Optional ``convergence.default_active_policy`` (e.g. ``CONV-ADJ-001``) applied when a scenario omits ``active_policy`` (see ``evaluate_scenario(..., policy_config)``).
- **Domain scenario libraries:** ``TEST_MANIFEST.json`` includes ``domain_libraries.clinical`` and ``.legal`` for replay with the same ``evaluate_scenario`` machinery.
- **Static UI / audit serialization:** ``static_ui_bundle_dict``, ``zone_map_export_dict``, ``ledger_golden_vectors_to_jsonl_lines`` in ``janet_ledger.export_bundle``; CI runs ``scripts/export_compliance_artifacts.py`` after tests and uploads ``artifacts/`` (``zone_map.json``, ``static_ui_bundle.json``, ``ledger_golden_vectors.jsonl``) plus existing **coverage.xml** and **policy-bom.md**.
- **CDN / Redis keys:** ``cache_key_ledger_row``, ``cache_key_render_log`` (reuse ``entry_hash`` / ``render_log_hash``).
- **Persona themes:** JSON file + ``load_persona_theme`` / env ``JANET_PERSONA_THEME_JSON``; pass ``persona_theme=`` into ``render_surface`` (see ``fixtures/persona_theme.example.json``).
- **HITL templates:** ``docs/templates/HITL_OVERRIDE_CHECKLIST.md``, ``docs/templates/HITL_ESCALATION_CLEARANCE.md``.
- **Sample policy JSON:** ``fixtures/policy_config.sample.json``.

## Surface renderer

`render_surface()` selects a template variant with **SHA-256** over `frame_id|session_id|turn` (not Python `hash()`, so runs are **PYTHONHASHSEED**-independent). Optional **persona theme JSON** (`persona_theme=` or env `JANET_PERSONA_THEME_JSON` via `load_persona_theme`) overrides the built-in persona lines without changing core hashes for the same effective §5.4 config. Under **§5.4** (`safety_54_active`), persona and verbosity modifiers are stripped; `affective_override` raises `ValueError`. Auxiliary audit: `render_log_hash = SHA-256(ledger_hash_hex || canonical_renderer_config)` as UTF-8 (same 64-char hex string style as ledger). When §5.4 is active, the config hashed is the **effective** applied config (`anonymous`, `verbosity` 0) so identical stripped surfaces share one auxiliary hash.

Goldens: `tests/fixtures/renderer_goldens.json`.

## Deployment

See **[DEPLOYMENT.md](DEPLOYMENT.md)** for remote sync, tagging, PyPI build, HITL token flow, rollback, and production hardening.
