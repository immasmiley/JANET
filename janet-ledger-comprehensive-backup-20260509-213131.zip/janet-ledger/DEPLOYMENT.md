# Deployment guide — `janet-ledger`

This document describes supervised rollout of the **reference library** (`janet-ledger`): deterministic ledger hashing, zone routing, equilibrium checks, convergence predicates, and the **surface renderer** with §5.4 gating. It does **not** replace jurisdiction-specific legal, clinical, or security review.

## 1. Prerequisites

- Python **3.10+** on coordinator hosts and CI runners.
- `TEST_MANIFEST.json` pinned at repo root (or copied next to the process) for golden-vector CI parity.
- A supervisor process (HITL dashboard, shell, or service) that owns **tokens** `[HITL_APPROVED]` / `[HITL_OVERRIDE: …]` and **never** trusts model-generated hex or drift values.

## 2. Install

**From a built wheel/sdist (registry):**

```bash
pip install janet-ledger==<version>
```

**From a git tag (internal):**

```bash
pip install "git+https://example.com/org/janet-ledger.git@v1.0.0-rc.1#egg=janet-ledger"
```

**Editable (development):**

```bash
cd janet-ledger
pip install -e ".[dev]"
```

Build artifacts for PyPI or an internal index:

```bash
pip install build twine
python -m build
twine upload dist/*
```

## 3. Environment variables

| Variable | Recommended | Notes |
|----------|-------------|--------|
| `PYTHONHASHSEED` | `0` or unset | **Optional:** built-in `hash()` is **not** used for variant selection; **SHA-256** is used everywhere critical. Setting `0` makes any accidental `hash()` use stable in a given interpreter. |
| `JANET_MANIFEST_PATH` | *(optional)* | If set, tests or tools may resolve `TEST_MANIFEST.json` from this path instead of cwd (your wrapper can implement this). |
| `LOG_LEVEL` | `INFO` (prod), `DEBUG` (staging) | Disable debug noise in production; avoid logging full payloads if they contain PHI. |

**TLS:** Ledger exports and HITL callbacks should use **HTTPS** only; treat ledger JSONL as sensitive data at rest (encrypted volume, access controls).

## 4. Python API (coordinator integration)

There is **no** `janet_ledger.ledger.run()` entrypoint. Integrate explicitly:

### 4.1 Ledger step (ASCII `prev_hash` + canonical payload)

```python
from janet_ledger import entry_hash

prev = "0" * 64  # genesis or prior entry_hash (64-char hex string)
payload = '{"coord_post_snap":-85.18,...}'  # canonical JSON from your serializer
digest = entry_hash(prev, payload)
```

Normative rule (§4): **`prev_hash` in the hash input is the 64-character ASCII hex digest**, concatenated with the payload string, then UTF-8 encoded and SHA-256 hashed. See `README.md`.

### 4.2 Zone routing and substrate helpers

```python
from janet_ledger import route_zone, route_zone_with_tie_meta, DELTA, k_index_from_coord
from janet_ledger import equilibrium_null_fires, evaluate_scenario
```

Use `route_zone_with_tie_meta` when you must log `tie_break_applied` for **ZONE-TIE-001** at `c == -25`.

### 4.3 Family graph (217 kinship ring)

For **JANET Family Chat**–style addressing (parity with `family-graph.js` / `family-taxonomy.js`):

```python
from janet_ledger import (
    RelationshipType,
    assert_mandates,
    degree_and_type_for,
    family_n_to_janet_k,
    janet_index_for,
    n_index_for,
    reserved_bridge_index,
    validate_member,
    x_at,
)

assert_mandates()
n = n_index_for(degree=4, rel_type=int(RelationshipType.ADOPTIVE_CHILD))  # 93
meta = validate_member(n_index=0)  # self anchor → warm tier / polling / vouches
```

Bind **Ed25519 pubkeys** and display fields in your store; keep **`n_index`**, **`rel_type`**, and **`degree`** consistent — `validate_member` rejects reserved band occupancy and degree/`rel_type` mismatches.

### 4.4 Surface renderer (after coordinator supplies `entry_hash`)

```python
from janet_ledger import RenderInput, RendererConfig, render_surface

inp = RenderInput(
    frame_id="fundamental_boundary",
    session_id="sess-1",
    turn=1,
    zone="Fundamental",
    coord_post_snap=-85.1851851852,
    ledger_hash_hex=digest,  # echo coordinator value only
)
cfg = RendererConfig(persona_id="analyst_plain", verbosity=1, safety_54_active=False)
out = render_surface(inp, cfg)
# out.surface_text, out.render_log_hash, out.variant_index
```

Under **§5.4** (`safety_54_active=True`), persona/verbosity modifiers are stripped; `affective_override` raises `ValueError`. Auxiliary audit: `out.render_log_hash` chains **ledger hash** + **effective** renderer config (see `README.md`).

### 4.5 Dashboard / stdout JSON

The library returns **Python values**. For a dashboard, your coordinator should:

1. Serialize **one JSON object per line** (JSONL) or one JSON document per response.
2. Include fields: `entry_hash`, `coord_post_snap`, `zone`, `frame_id`, `render_log_hash`, `hitl_status`, `expert_id`, `utc_timestamp` (you supply timestamps and expert IDs from OIDC or audit handles).
3. Never pass model-generated `entry_hash` through without recomputing or verifying with `entry_hash()`.

Example envelope (your schema may differ):

```json
{
  "coordinator_version": "janet-ledger-cli v2.1.0",
  "build_digest": "<64 lowercase hex>",
  "ledger": { "prev_hash": "…", "entry_hash": "…", "payload_canonical": "…" },
  "render": { "surface_text": "…", "render_log_hash": "…", "variant_index": 2 },
  "hitl": { "status": "PENDING", "expert_id": "…", "utc_timestamp": "…" }
}
```

## 5. HITL token flow (supervisor responsibility)

The **library does not** parse `[HITL_APPROVED]`; that belongs in your orchestration layer.

1. Coordinator emits ledger row + proposed render with `hitl_status: PENDING`.
2. Supervisor UI shows diff; expert issues **`[HITL_APPROVED]`** or **`[HITL_OVERRIDE: rationale]`**.
3. Your service appends an auditable row (new `entry_hash` chain) recording the token, `expert_id`, and ISO8601 timestamp.
4. Only then advance phase (KK→KU→UK→UU) in your state machine.

Store overrides immutably (append-only log), not in-place edits.

## 6. Rollback protocol

| Step | Action |
|------|--------|
| 1 | **Pin:** Record `git` tag or wheel version + `BUILD_DIGEST` that passed CI. |
| 2 | **Stop** accepting new ledger appends on the bad build; switch traffic to last good coordinator image. |
| 3 | **Replay:** From last known-good `prev_hash`, replay canonical payloads; verify `entry_hash` chain matches golden expectations for `TEST_MANIFEST.json`. |
| 4 | **Manifest:** If `TEST_MANIFEST.json` changes, treat as a **new protocol version**; bump semver and re-run full CI. |
| 5 | **Data:** Restore ledger JSONL from backup if corruption occurred; never “edit” hashes in place. |

## 7. Production hardening checklist

- [ ] CI green on tagged commit (mypy, bandit, pytest, coverage ≥ 85%).
- [ ] `PYTHONHASHSEED=0` set on hosts if policy requires (defense in depth).
- [ ] Debug logging off; structured logs without raw payloads if sensitive.
- [ ] TLS for all ledger export and HITL API calls; mTLS optional for internal mesh.
- [ ] Secrets (API keys, OIDC) via vault/env injection, not repo.
- [ ] Runbook linking this doc + `README.md` + `TEST_MANIFEST.json` revision.

## 8. Remote sync and version tags

```bash
git remote add origin <your-repo-url>
git push -u origin master

git tag -a v1.0.0-rc.1 -m "Release Candidate 1: Deterministic ledger + renderer + CI"
git push origin v1.0.0-rc.1
```

## 9. Support and scope

This package implements **geometry, hashing, routing, rendering, and tests** aligned with your FINAL protocol text. Multi-agent consensus, clinical IRB, and org-specific dashboards remain **out of scope** for this repository.

For questions, open issues on the project remote after push.
