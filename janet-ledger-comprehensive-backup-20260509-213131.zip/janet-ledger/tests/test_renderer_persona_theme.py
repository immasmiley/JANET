"""Renderer persona theme JSON."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from janet_ledger import RenderInput, RendererConfig, render_surface


def test_persona_theme_overrides_lines(tmp_path: Path) -> None:
    theme_path = tmp_path / "theme.json"
    theme_path.write_text(
        json.dumps(
            {
                "personas": {
                    "analyst_plain": {
                        "v0": ["CUSTOM-A"],
                        "v1": ["CUSTOM-B"],
                        "v2": ["CUSTOM-C"],
                    }
                }
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    theme = json.loads(theme_path.read_text(encoding="utf-8"))
    inp = RenderInput(
        frame_id="f",
        session_id="s",
        turn=1,
        zone="Definitional",
        coord_post_snap=0.0,
        ledger_hash_hex="0" * 64,
    )
    cfg = RendererConfig(persona_id="analyst_plain", verbosity=0, safety_54_active=False)
    r = render_surface(inp, cfg, persona_theme=theme)
    assert "CUSTOM-A" in r.surface_text
    assert "SUBJECT: Analysis" not in r.surface_text
