"""Load TEST_MANIFEST.json from repo root."""

from __future__ import annotations

import json
from pathlib import Path


def load_manifest() -> dict:
    root = Path(__file__).resolve().parents[1]
    path = root / "TEST_MANIFEST.json"
    if not path.is_file():
        raise FileNotFoundError(f"Missing {path}")
    return json.loads(path.read_text(encoding="utf-8"))
