"""Demo identity lifecycle, payloads, retirement order, audit chain."""

from __future__ import annotations

import json

import pytest

from janet_ledger.demo_identity import (
    DEMO_IDENTITY_001,
    DEMO_RETIRE_001,
    DemoIdentitySession,
    DemoLifecycleState,
    InMemoryDemoKeyVault,
    NIP17_DEMO_SESSION_001,
    advance_demo_active,
    advance_demo_relay_ping,
    advance_real_init,
    auto_provision_demo_session,
    demo_retired_audit_row_canonical,
    execute_demo_retirement,
    nip17_demo_session_payload_canonical,
    nip29_demo_leave_payload_canonical,
    simulate_nostr_event_id,
)
from janet_ledger.ledger import entry_hash
from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001


def test_auto_provision_and_state_gates():
    s = DemoIdentitySession()
    v = InMemoryDemoKeyVault()
    pk = "e" * 64
    h = "demo_handle_1"
    gid = "demo_group_ci"
    body, eid = auto_provision_demo_session(s, v, demo_key_handle_id=h, demo_pubkey_hex=pk, nip29_group_id=gid)
    assert s.state == DemoLifecycleState.demo_provision
    assert v.has_demo_key(h)
    assert simulate_nostr_event_id(body) == eid
    assert s.last_demo_event_id_hex == eid
    d = json.loads(body)
    assert d["monotonic_counter"] >= 1
    assert DEMO_IDENTITY_001 in d["janet_policy_codes"]

    advance_demo_relay_ping(s)
    advance_demo_active(s)
    assert s.state == DemoLifecycleState.demo_active

    prev = "0" * 64
    ex = execute_demo_retirement(s, v, trigger="CREATE_REAL_ACCOUNT", audit_ledger_prev_hash_hex=prev)
    assert not v.has_demo_key(h)
    assert s.demo_key_handle_id is None
    assert s.retired_irreversibly
    assert s.state == DemoLifecycleState.retired_final

    final = entry_hash(prev, ex.audit_row_canonical)
    assert ex.final_ledger_hash_hex == final

    with pytest.raises(RuntimeError):
        execute_demo_retirement(s, v, trigger="CREATE_REAL_ACCOUNT", audit_ledger_prev_hash_hex=prev)

    advance_real_init(s)
    assert s.state == DemoLifecycleState.real_init


def test_monotonic_counter_provision_then_retire():
    s = DemoIdentitySession()
    v = InMemoryDemoKeyVault()
    pk = "a" * 64
    body, _ = auto_provision_demo_session(
        s, v, demo_key_handle_id="h", demo_pubkey_hex=pk, nip29_group_id="demo_x"
    )
    mc_p = json.loads(body)["monotonic_counter"]
    advance_demo_relay_ping(s)
    advance_demo_active(s)
    ex = execute_demo_retirement(s, v, trigger="ACCEPT_FAMILY_INVITE", audit_ledger_prev_hash_hex="f" * 64)
    mc_r = json.loads(ex.retire_content_canonical)["monotonic_counter"]
    assert mc_r > mc_p


def test_nip17_nip29_roundtrip_payloads():
    pk = "c" * 64
    peer = "d" * 64
    pol_n17 = (DEMO_IDENTITY_001, NIP17_DEMO_SESSION_001, NIP33_JANET_CONTENT_001)
    n17 = nip17_demo_session_payload_canonical(peer_pubkey_hex=peer, session_epoch=0, janet_policy_codes=pol_n17)
    assert "demo_" in n17
    pol_leave = (DEMO_RETIRE_001, NIP33_JANET_CONTENT_001)

    leave = nip29_demo_leave_payload_canonical(nip29_group_id="demo_leave", janet_policy_codes=pol_leave)
    assert json.loads(leave)["action"] == "leave"


def test_wrong_state_retire():
    s = DemoIdentitySession()
    v = InMemoryDemoKeyVault()
    with pytest.raises(ValueError, match="demo_active"):
        execute_demo_retirement(s, v, trigger="CREATE_REAL_ACCOUNT", audit_ledger_prev_hash_hex="0" * 64)


def test_audit_row_fields():
    row = demo_retired_audit_row_canonical(
        retire_event_id_hex="1" * 64,
        prior_demo_chain_tip_hex="2" * 64,
        audit_ledger_prev_hash_hex="3" * 64,
        reason="user_promoted",
        phase="post_teardown",
    )
    d = json.loads(row)
    assert d["event"] == "demo_retired"
    assert d["schema"] == "janet_audit_demo_retired_v1"
