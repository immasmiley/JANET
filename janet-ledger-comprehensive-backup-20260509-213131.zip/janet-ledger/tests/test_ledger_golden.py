from janet_ledger import entry_hash

from conftest import load_manifest


def test_ledger_golden_vectors():
    manifest = load_manifest()
    for vec in manifest["ledger_golden_vectors"]:
        got = entry_hash(vec["prev_hash"], vec["payload_canonical"])
        assert got == vec["entry_hash"], vec["id"]
