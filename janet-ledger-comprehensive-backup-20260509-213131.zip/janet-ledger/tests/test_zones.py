from janet_ledger import policy_config_from_manifest, route_zone, route_zone_with_tie_meta

from conftest import load_manifest


def test_zone_router_probes():
    manifest = load_manifest()
    pc = policy_config_from_manifest(manifest)
    tie = pc.zone_tie_break_coord
    for row in manifest["zone_router_probes"]:
        c = float(row["coord"])
        assert route_zone(c, tie_coord=tie) == row["expected_zone"], row.get("note", c)


def test_zone_tie_001_metadata():
    manifest = load_manifest()
    tie = policy_config_from_manifest(manifest).zone_tie_break_coord
    z, tmeta = route_zone_with_tie_meta(-25.0, tie_coord=tie)
    assert z == "Attributive"
    assert tmeta is True