"""Golden and determinism tests for evidence → triadic parent mapping."""

from __future__ import annotations

import pytest

from janet_ledger.evidence_triad import (
    GEO_PROJ_GRID_STEP_E7,
    GeoCellOverlay,
    audit_evidence_binding,
    canonical_evidence_payload,
    evidence_fingerprint_from_payload,
    geo_cell_overlay_from_wgs84_e7,
    k_from_bat_tier,
    language_overlay_from_confirmed_iso639_1,
    triadic_child_k,
    triadic_parents_from_bound_evidence,
)


def _nyc_geo() -> GeoCellOverlay:
    return geo_cell_overlay_from_wgs84_e7(407_128_000, -740_060_000)


def test_fingerprint_determinism():
    geo = _nyc_geo()
    lang = language_overlay_from_confirmed_iso639_1("en")
    p = canonical_evidence_payload(geo=geo, bat_tier="warm", lang=lang)
    assert evidence_fingerprint_from_payload(p) == evidence_fingerprint_from_payload(p)


def test_triadic_pipeline_deterministic():
    geo = _nyc_geo()
    a = triadic_parents_from_bound_evidence(
        geo=geo,
        bat_tier="warm",
        iso639_1_confirmed="en",
        boost_policies=("PBOOST-000",),
    )
    b = triadic_parents_from_bound_evidence(
        geo=geo,
        bat_tier="warm",
        iso639_1_confirmed="en",
        boost_policies=("PBOOST-000",),
    )
    assert a == b


def test_only_documented_boost_policies():
    with pytest.raises(ValueError, match="unsupported proximity policy"):
        triadic_parents_from_bound_evidence(
            geo=_nyc_geo(),
            bat_tier="hot",
            iso639_1_confirmed="en",
            boost_policies=("PBOOST-UNKNOWN",),  # type: ignore[list-item]
        )


def test_cohort_boost_is_bounded_integer():
    r = triadic_parents_from_bound_evidence(
        geo=geo_cell_overlay_from_wgs84_e7(0, 0),
        bat_tier="cold",
        iso639_1_confirmed="es",
        boost_policies=("PBOOST-COHORT-001",),
    )
    assert -108 <= r.k_rank <= 108
    delta = r.k_rank - r.k_child
    assert -2 <= delta <= 2


def test_triadic_child_respects_closure_ring():
    """Sum of three parent x-coordinates snaps back to a valid k on the 217-line."""
    geo = geo_cell_overlay_from_wgs84_e7(100_000, 200_000)
    k_a = geo.k_location
    k_b = k_from_bat_tier("warm")
    k_c = language_overlay_from_confirmed_iso639_1("en").k_language
    k_star = triadic_child_k(k_a, k_b, k_c)
    assert -108 <= k_star <= 108


def test_geo_rejects_float():
    with pytest.raises(TypeError, match="int"):
        geo_cell_overlay_from_wgs84_e7(40.7, -74.0)  # type: ignore[arg-type]


def test_lang_rejects_freetext():
    with pytest.raises(ValueError, match="LANG-MATCH-001"):
        language_overlay_from_confirmed_iso639_1("English")


def test_lang_rejects_padded_tag():
    with pytest.raises(ValueError, match="whitespace"):
        language_overlay_from_confirmed_iso639_1(" en")


def test_audit_binding_contains_provenance():
    r = triadic_parents_from_bound_evidence(
        geo=_nyc_geo(),
        bat_tier="warm",
        iso639_1_confirmed="en",
    )
    log = audit_evidence_binding(r)
    assert log["geo"]["policy_id"] == "GEO-PROJ-001"
    assert log["lang"]["policy_id"] == "LANG-MATCH-001"
    assert log["geo"]["cell_sha256_hex"] == r.geo_overlay.cell_sha256_hex
    assert log["lang"]["tag_sha256_hex"] == r.lang_overlay.tag_sha256_hex
    assert len(log["geo"]["cell_sha256_hex"]) == 64


def test_geo_overlay_grid_constant():
    g = _nyc_geo()
    assert g.grid_step_e7 == GEO_PROJ_GRID_STEP_E7
    assert g.policy_id == "GEO-PROJ-001"
