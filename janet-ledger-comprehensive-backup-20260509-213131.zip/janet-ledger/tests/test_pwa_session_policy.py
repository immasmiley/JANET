"""Canonical PWA delegation and session-revoke payloads."""

from __future__ import annotations

import json

import pytest

from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001
from janet_ledger.pwa_session_policy import (
    SESSION_DELEGATE_001,
    SESSION_REVOKE_001,
    ALLOWED_PWA_KINDS,
    delegation_offer_fingerprint_hex,
    delegation_session_offer_canonical,
    nip33_session_revoke_pwa_payload_canonical,
    pwa_relay_req_filter_capsule_canonical,
)


def _pol_del() -> tuple[str, ...]:
    return (SESSION_DELEGATE_001, NIP33_JANET_CONTENT_001)


def _pol_rev() -> tuple[str, ...]:
    return (SESSION_REVOKE_001, NIP33_JANET_CONTENT_001)


def test_delegation_offer_sorted_and_fingerprint():
    o = delegation_session_offer_canonical(
        pwa_ephemeral_pubkey_hex="a" * 64,
        allowed_kinds=(29, 1, 4),
        until_unix=1700000000,
        janet_policy_codes=_pol_del(),
    )
    d = json.loads(o)
    assert d["allowed_kinds"] == [1, 4, 29]
    fp = delegation_offer_fingerprint_hex(o)
    assert len(fp) == 64


def test_reject_disallowed_kind():
    with pytest.raises(ValueError, match="not permitted"):
        delegation_session_offer_canonical(
            pwa_ephemeral_pubkey_hex="a" * 64,
            allowed_kinds=(1, 3),
            until_unix=1,
            janet_policy_codes=_pol_del(),
        )


def test_revoke_binds_fingerprint():
    offer = delegation_session_offer_canonical(
        pwa_ephemeral_pubkey_hex="b" * 64,
        allowed_kinds=(1,),
        until_unix=2,
        janet_policy_codes=_pol_del(),
    )
    fp = delegation_offer_fingerprint_hex(offer)
    rev = nip33_session_revoke_pwa_payload_canonical(
        chain_prev_event_id_hex="c" * 64,
        delegate_fingerprint_hex=fp,
        epoch=0,
        monotonic_counter=1,
        janet_policy_codes=_pol_rev(),
    )
    assert json.loads(rev)["delegate_fingerprint_hex"] == fp


def test_req_capsule_sorted_authors():
    s = pwa_relay_req_filter_capsule_canonical(
        authors_hex=("f" * 64, "e" * 64),
        kinds=(29, 1),
    )
    d = json.loads(s)
    assert d["authors_hex"] == ["e" * 64, "f" * 64]


def test_allowed_pwa_kinds_frozen():
    assert ALLOWED_PWA_KINDS == frozenset((1, 4, 29))
