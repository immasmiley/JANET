from janet_ledger import evaluate_scenario, policy_config_from_manifest

from conftest import load_manifest

def test_convergence_scenarios():
    manifest = load_manifest()
    pc = policy_config_from_manifest(manifest)
    for sc in manifest["convergence_tests"]["scenarios"]:
        got = evaluate_scenario(sc, pc)
        assert got == sc["expected_result"], sc["id"]
