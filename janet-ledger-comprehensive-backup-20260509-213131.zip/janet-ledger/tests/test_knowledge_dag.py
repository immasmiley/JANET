"""HITL pattern events, convergence, and audit bundles."""

from __future__ import annotations

import json

import pytest

from janet_ledger.evidence_triad import geo_cell_overlay_from_wgs84_e7, triadic_parents_from_bound_evidence
from janet_ledger.knowledge_dag import (
    EVENT_PATTERN_CONFIRMED,
    EVENT_PATTERN_OBSERVATION,
    audit_bundle_canonical,
    coord_frame_mapping_canonical,
    mapping_key_digest,
    pattern_confirmed_payload,
    pattern_observation_payload,
    pattern_state_after_observation,
    pattern_state_initial,
)
from janet_ledger.ledger import entry_hash

_GENESIS = "0" * 64
_GEO = "a" * 64


def _obs_payload(session_id: str, hitl: str = "HITL-OK-1") -> str:
    return pattern_observation_payload(
        hitl_token=hitl,
        session_id=session_id,
        frame_id="frame_alpha",
        geo_cell_sha256_hex=_GEO,
        triad_evidence_fingerprint=42,
        k_a=1,
        k_b=0,
        k_c=-1,
        k_rank=2,
        parent_entry_hashes=(_GENESIS,),
        sub_lattice_path="0",
    )


def test_coord_frame_mapping_stable():
    k1 = coord_frame_mapping_canonical(frame_id="f", geo_cell_sha256_hex=_GEO)
    k2 = coord_frame_mapping_canonical(frame_id="f", geo_cell_sha256_hex=_GEO.upper())
    assert k1 == k2
    assert mapping_key_digest(k1) == mapping_key_digest(k2)


def test_observation_payload_shape():
    p = _obs_payload("sess-a")
    d = json.loads(p)
    assert d["event_type"] == EVENT_PATTERN_OBSERVATION
    assert d["mapping_key_sha256"] == mapping_key_digest(d["mapping_key_canonical"])
    assert d["parent_entry_hashes"] == sorted([_GENESIS])


def test_convergence_emits_once_for_three_distinct_sessions():
    mk = coord_frame_mapping_canonical(frame_id="frame_alpha", geo_cell_sha256_hex=_GEO)
    st = pattern_state_initial()

    h1 = entry_hash(_GENESIS, _obs_payload("s1"))
    st, c1 = pattern_state_after_observation(
        st,
        mapping_key_canonical=mk,
        session_id="s1",
        observation_entry_hash=h1,
        triad_evidence_fingerprint=1,
        k_rank=0,
    )
    assert c1 is None

    h2 = entry_hash(h1, _obs_payload("s2"))
    st, c2 = pattern_state_after_observation(
        st,
        mapping_key_canonical=mk,
        session_id="s2",
        observation_entry_hash=h2,
        triad_evidence_fingerprint=2,
        k_rank=0,
    )
    assert c2 is None

    h3 = entry_hash(h2, _obs_payload("s3"))
    st, c3 = pattern_state_after_observation(
        st,
        mapping_key_canonical=mk,
        session_id="s3",
        observation_entry_hash=h3,
        triad_evidence_fingerprint=99,
        k_rank=5,
    )
    assert c3 is not None
    conf = json.loads(c3)
    assert conf["event_type"] == EVENT_PATTERN_CONFIRMED
    assert conf["distinct_session_count"] == 3
    assert conf["session_ids"] == ["s1", "s2", "s3"]
    assert conf["triad_evidence_fingerprint"] == 99
    assert conf["k_rank"] == 5
    assert sorted(conf["parent_observation_entry_hashes"]) == sorted([h1, h2, h3])

    h4 = entry_hash(h3, _obs_payload("s1"))
    st, c4 = pattern_state_after_observation(
        st,
        mapping_key_canonical=mk,
        session_id="s1",
        observation_entry_hash=h4,
        triad_evidence_fingerprint=100,
        k_rank=1,
    )
    assert c4 is None


def test_same_session_three_times_no_confirm():
    mk = coord_frame_mapping_canonical(frame_id="frame_alpha", geo_cell_sha256_hex=_GEO)
    st = pattern_state_initial()
    prev = _GENESIS
    for _ in range(3):
        p = _obs_payload("lonely")
        h = entry_hash(prev, p)
        st, c = pattern_state_after_observation(
            st,
            mapping_key_canonical=mk,
            session_id="lonely",
            observation_entry_hash=h,
            triad_evidence_fingerprint=0,
            k_rank=0,
        )
        assert c is None
        prev = h


def test_audit_bundle_sorted():
    a = pattern_observation_payload(
        hitl_token="t",
        session_id="s1",
        frame_id="f1",
        geo_cell_sha256_hex=_GEO,
        triad_evidence_fingerprint=0,
        k_a=0,
        k_b=0,
        k_c=0,
        k_rank=0,
        parent_entry_hashes=(_GENESIS,),
    )
    b = pattern_observation_payload(
        hitl_token="t",
        session_id="s2",
        frame_id="f2",
        geo_cell_sha256_hex="b" * 64,
        triad_evidence_fingerprint=0,
        k_a=0,
        k_b=0,
        k_c=0,
        k_rank=0,
        parent_entry_hashes=(_GENESIS,),
    )
    u1 = audit_bundle_canonical(event_payload_json_strings=(b, a))
    u2 = audit_bundle_canonical(event_payload_json_strings=(a, b))
    assert u1 == u2


def test_pattern_confirmed_requires_three_sessions():
    mk = coord_frame_mapping_canonical(frame_id="f", geo_cell_sha256_hex=_GEO)
    with pytest.raises(ValueError, match="at least 3"):
        pattern_confirmed_payload(
            mapping_key_canonical=mk,
            session_ids=("a", "b"),
            parent_observation_entry_hashes=(_GENESIS, _GENESIS),
            triad_evidence_fingerprint=0,
            k_rank=0,
        )


def test_invalid_geo_hex():
    with pytest.raises(ValueError, match="64"):
        coord_frame_mapping_canonical(frame_id="f", geo_cell_sha256_hex="bad")


def test_observation_links_geo_hash_and_triad_fingerprint():
    geo = geo_cell_overlay_from_wgs84_e7(407_128_000, -740_060_000)
    tri = triadic_parents_from_bound_evidence(
        geo=geo,
        bat_tier="warm",
        iso639_1_confirmed="en",
    )
    mk = coord_frame_mapping_canonical(frame_id="frame_nyc", geo_cell_sha256_hex=geo.cell_sha256_hex)
    p = pattern_observation_payload(
        hitl_token="HITL-approve-1",
        session_id="sess-1",
        frame_id="frame_nyc",
        geo_cell_sha256_hex=geo.cell_sha256_hex,
        triad_evidence_fingerprint=tri.evidence_fingerprint,
        k_a=tri.k_a,
        k_b=tri.k_b,
        k_c=tri.k_c,
        k_rank=tri.k_rank,
        parent_entry_hashes=(_GENESIS,),
    )
    d = json.loads(p)
    assert d["geo_cell_sha256_hex"] == geo.cell_sha256_hex
    assert d["triad_evidence_fingerprint"] == tri.evidence_fingerprint
    assert d["mapping_key_canonical"] == mk
