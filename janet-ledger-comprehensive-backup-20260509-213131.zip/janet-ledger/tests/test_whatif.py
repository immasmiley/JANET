"""Coverage for ``python -m janet_ledger.whatif``."""

from __future__ import annotations

import pytest

from janet_ledger.whatif import main


def test_whatif_main_strict_convergence(capsys: pytest.CaptureFixture[str]) -> None:
    payload = (
        '[{"session_id":"A","k_final":17},'
        '{"session_id":"B","k_final":17},'
        '{"session_id":"C","k_final":17}]'
    )
    assert main(["--scenario-json", payload]) == 0
    out = capsys.readouterr().out.strip()
    assert '"converged": true' in out


def test_whatif_main_divergence(capsys: pytest.CaptureFixture[str]) -> None:
    payload = (
        '[{"session_id":"A","k_final":17},'
        '{"session_id":"B","k_final":20},'
        '{"session_id":"C","k_final":20}]'
    )
    assert main(["--scenario-json", payload]) == 0
    out = capsys.readouterr().out.strip()
    assert '"converged": false' in out


def test_whatif_with_policy_manifest(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    import json

    man = {"policy_config": {"convergence": {"default_active_policy": "CONV-ADJ-001"}}}
    p = tmp_path / "manifest.json"
    p.write_text(json.dumps(man), encoding="utf-8")
    payload = (
        '[{"session_id":"A","k_final":17},'
        '{"session_id":"B","k_final":16},'
        '{"session_id":"C","k_final":18}]'
    )
    assert main(["--scenario-json", payload, "--policy-manifest", str(p)]) == 0
    assert '"converged": true' in capsys.readouterr().out.strip()
