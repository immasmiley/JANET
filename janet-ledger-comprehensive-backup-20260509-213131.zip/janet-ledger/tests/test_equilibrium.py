from janet_ledger import equilibrium_null_fires

from conftest import load_manifest


def test_equilibrium_null_cases():
    manifest = load_manifest()
    block = manifest["equilibrium_null_logic"]
    assert block["rule_id"] == "EQ-NULL-001"
    for case in block["test_cases"]:
        seq = [float(x) for x in case["input_sequence"]]
        assert equilibrium_null_fires(seq), case["scenario"]
