"""Tests for janet_ledger.toolbox helpers."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from janet_ledger.evidence_triad import geo_cell_overlay_from_wgs84_e7, triadic_parents_from_bound_evidence
from janet_ledger.toolbox import (
    audit_session_bundle_canonical,
    cache_key_evidence_fingerprint,
    cache_key_ledger_row,
    cache_key_render_log,
    coherence_binding_vs_zone,
    diff_canonical_jsonl_lines,
    diff_manifest_convergence_scenarios,
    member_ring_snapshot,
    neighbor_ks_for_k,
    neighbor_n_ring,
    whatif_convergence_json,
)


def test_cache_key_stable():
    assert cache_key_evidence_fingerprint(123) == cache_key_evidence_fingerprint(123)


def test_audit_session_bundle_sorted():
    b1 = {"k_a": 1, "z": 9}
    b2 = {"k_a": 0, "z": 1}
    s = audit_session_bundle_canonical(
        evidence_bindings=(b1, b2),
        ledger_row_payloads=('{"a":1}', '{"a":0}'),
        zone_outcomes=({"coord": 0.0, "zone": "Definitional"},),
    )
    d = json.loads(s)
    assert d["ledger_row_payloads"] == ['{"a":0}', '{"a":1}']


def test_neighbor_n_ring_endpoints():
    assert neighbor_n_ring(0) == (None, 0, 1)
    assert neighbor_n_ring(216) == (215, 216, None)


def test_neighbor_ks_for_k():
    assert neighbor_ks_for_k(-108) == (None, -108, -107)
    assert neighbor_ks_for_k(108) == (107, 108, None)


def test_coherence_binding_vs_zone():
    geo = geo_cell_overlay_from_wgs84_e7(0, 0)
    tri = triadic_parents_from_bound_evidence(geo=geo, bat_tier="warm", iso639_1_confirmed="en")
    snap = coherence_binding_vs_zone(coord_post_snap=0.0, zone_claim="Definitional", triad=tri)
    assert snap["claim_matches_route"] is True
    bad = coherence_binding_vs_zone(coord_post_snap=0.0, zone_claim="Structural", triad=tri)
    assert bad["claim_matches_route"] is False


def test_member_ring_snapshot_self():
    s = member_ring_snapshot(0)
    assert s["self"] is True
    assert s["bat_tier"] == "warm"


def test_diff_manifest_same_file(tmp_path: Path):
    src = Path(__file__).resolve().parents[1] / "TEST_MANIFEST.json"
    p = tmp_path / "m.json"
    p.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    assert diff_manifest_convergence_scenarios(p, p) == []


def test_diff_canonical_jsonl():
    a = ['{"x":1}', '{"x":2}']
    b = ['{"x":1}', '{"x":1}']
    d = diff_canonical_jsonl_lines(a, b)
    assert any("count_mismatch" in x for x in d)


def test_whatif_convergence_json():
    assert whatif_convergence_json('[{"session_id":"A","k_final":17},{"session_id":"B","k_final":17},{"session_id":"C","k_final":17}]') is True
    assert whatif_convergence_json('[{"session_id":"A","k_final":17},{"session_id":"B","k_final":20},{"session_id":"C","k_final":20}]') is False


def test_cache_key_ledger_and_render():
    prev = "0" * 64
    payload = '{"a":1}'
    k1 = cache_key_ledger_row(prev, payload)
    k2 = cache_key_ledger_row(prev, payload)
    assert k1 == k2
    assert k1.startswith("janet:ledger:")
    rk = cache_key_render_log(prev, {"persona_id": "analyst_plain", "safety_54_active": False, "verbosity": 0})
    assert rk.startswith("janet:render_log:")
