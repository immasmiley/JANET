"""Canonical NIP-33 JANET policy payloads."""

from __future__ import annotations

import json

import pytest

from janet_ledger.nostr_janet_policy import (
    DELEGATION_CHAIN_001,
    NIP33_JANET_CONTENT_001,
    RECOVERY_CHALLENGE_BIND_001,
    RECOVERY_THRESHOLD_001,
    ROTATION_EPOCH_001,
    TAMPER_RESPONSE_001,
    nip33_delegation_snapshot_canonical,
    nip33_recovery_policy_payload_canonical,
    nip33_rotation_payload_canonical,
)


def _p() -> str:
    return "a" * 64


def _q() -> str:
    return "b" * 64


def _base_policies_rotation() -> tuple[str, ...]:
    return (ROTATION_EPOCH_001, NIP33_JANET_CONTENT_001)


def test_rotation_sorted_policies_and_stable():
    codes = (NIP33_JANET_CONTENT_001, ROTATION_EPOCH_001)
    s = nip33_rotation_payload_canonical(
        new_pubkey_hex=_p(),
        epoch=1,
        monotonic_counter=2,
        janet_policy_codes=codes,
        previous_event_id_hex=_q(),
    )
    d = json.loads(s)
    assert d["janet_policy_codes"] == sorted(codes)
    s2 = nip33_rotation_payload_canonical(
        new_pubkey_hex="A" * 64,
        epoch=1,
        monotonic_counter=2,
        janet_policy_codes=codes,
        previous_event_id_hex="B" * 64,
    )
    assert s == s2


def test_rotation_requires_challenge_bind_when_challenge_set():
    with pytest.raises(ValueError, match="RECOVERY-CHALLENGE-BIND-001"):
        nip33_rotation_payload_canonical(
            new_pubkey_hex=_p(),
            epoch=0,
            monotonic_counter=0,
            janet_policy_codes=_base_policies_rotation(),
            recovery_challenge_id_hex=_q(),
        )


def test_rotation_with_challenge_and_wipe():
    pol = (
        ROTATION_EPOCH_001,
        NIP33_JANET_CONTENT_001,
        RECOVERY_CHALLENGE_BIND_001,
        TAMPER_RESPONSE_001,
    )
    s = nip33_rotation_payload_canonical(
        new_pubkey_hex=_p(),
        epoch=3,
        monotonic_counter=9,
        janet_policy_codes=pol,
        recovery_challenge_id_hex=_q(),
        wipe_reason="tamper",
    )
    d = json.loads(s)
    assert d["wipe_reason"] == "tamper"
    assert d["recovery_challenge_id_hex"] == _q()


def test_recovery_policy_trustees_sorted():
    t1, t2 = "c" * 64, "d" * 64
    pol = (RECOVERY_THRESHOLD_001, NIP33_JANET_CONTENT_001)
    s = nip33_recovery_policy_payload_canonical(
        threshold=2,
        trustee_pubkey_hex=(t2, t1),
        janet_policy_codes=pol,
        policy_epoch=0,
    )
    d = json.loads(s)
    assert d["trustee_pubkey_hex"] == sorted([t1, t2])


def test_delegation_requires_codes():
    pol = (DELEGATION_CHAIN_001, NIP33_JANET_CONTENT_001)
    s = nip33_delegation_snapshot_canonical(
        delegator_pubkey_hex=_p(),
        successor_pubkey_hash_hex=_q(),
        janet_policy_codes=pol,
        delegation_epoch=1,
    )
    assert "nip33_janet_delegation_v1" in s


def test_rotation_wipe_requires_tamper_policy():
    with pytest.raises(ValueError, match="TAMPER-RESPONSE-001"):
        nip33_rotation_payload_canonical(
            new_pubkey_hex=_p(),
            epoch=0,
            monotonic_counter=0,
            janet_policy_codes=_base_policies_rotation(),
            wipe_reason="tamper",
        )


def test_missing_rotation_epoch_raises():
    with pytest.raises(ValueError, match="ROTATION-EPOCH-001"):
        nip33_rotation_payload_canonical(
            new_pubkey_hex=_p(),
            epoch=0,
            monotonic_counter=0,
            janet_policy_codes=(NIP33_JANET_CONTENT_001,),
        )
