"""Local settlement stub: chain, dedup, HTTP surface."""

from __future__ import annotations

import json
import threading
import urllib.request
from pathlib import Path

import pytest

from janet_ledger.gap_reward import (
    BADGE_ATTEST_001,
    GAP_REWARD_001,
    gap_reward_badge_payload_canonical,
)
from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001
from janet_ledger.settlement_stub import (
    STUB_ROOT_PREV,
    parse_settlement_post_body,
    run_stub_server,
    settle_gap_reward_voucher,
)


def _sig() -> str:
    return "a" * 128


def _pol() -> tuple[str, str, str]:
    return (BADGE_ATTEST_001, GAP_REWARD_001, NIP33_JANET_CONTENT_001)


def _voucher(*, gap_digit: str, triad_digit: str, badge: str, prev: str) -> str:
    return gap_reward_badge_payload_canonical(
        gap_id=gap_digit * 64,
        triad_hash=triad_digit * 64,
        binder_pubkey_hex="3" * 64,
        badge_slug=badge,
        quorum_sigs=(_sig(),),
        verifier_result="PASS",
        epoch=0,
        prev_event_id=prev,
        janet_policy_codes=_pol(),
    )


def test_settle_genesis_then_chain_and_dedup(tmp_path: Path) -> None:
    v1 = _voucher(gap_digit="1", triad_digit="2", badge="alpha", prev=STUB_ROOT_PREV)
    d1 = settle_gap_reward_voucher(voucher_canonical=v1, out_dir=tmp_path)
    assert d1.http_status == 200
    h1 = d1.payload["voucher_content_hash"]
    assert (tmp_path / "badges").is_dir()

    d1b = settle_gap_reward_voucher(voucher_canonical=v1, out_dir=tmp_path)
    assert d1b.http_status == 409

    v2 = _voucher(gap_digit="5", triad_digit="2", badge="beta", prev=h1)
    d2 = settle_gap_reward_voucher(voucher_canonical=v2, out_dir=tmp_path)
    assert d2.http_status == 200

    bad_prev = _voucher(gap_digit="6", triad_digit="2", badge="gamma", prev="f" * 64)
    d3 = settle_gap_reward_voucher(voucher_canonical=bad_prev, out_dir=tmp_path)
    assert d3.http_status == 400


def test_parse_post_wrapper() -> None:
    inner = _voucher(gap_digit="1", triad_digit="2", badge="w", prev=STUB_ROOT_PREV)
    wrapped = json.dumps({"voucher_canonical": inner})
    assert parse_settlement_post_body(wrapped.encode()) == inner


def test_http_get_test_page(tmp_path: Path) -> None:
    ev = threading.Event()
    srv = run_stub_server("127.0.0.1", 0, tmp_path, shutdown_event=ev)
    host, port = srv.server_address
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    try:
        url = f"http://{host}:{port}/test"
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=2) as resp:
            assert resp.status == 200
            assert "text/html" in resp.headers.get("Content-Type", "")
            html = resp.read().decode("utf-8")
        assert "JANET settlement stub" in html
        assert "/webhooks/gap-reward" in html
        assert "/static/qrcode.min.js" in html
        assert "Copy page link" in html
    finally:
        ev.set()
        srv.shutdown()
        th.join(timeout=5)


def test_http_get_qrcode_static(tmp_path: Path) -> None:
    ev = threading.Event()
    srv = run_stub_server("127.0.0.1", 0, tmp_path, shutdown_event=ev)
    host, port = srv.server_address
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    try:
        url = f"http://{host}:{port}/static/qrcode.min.js"
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=2) as resp:
            assert resp.status == 200
            ct = resp.headers.get("Content-Type", "")
            assert "javascript" in ct
            body = resp.read()
        assert len(body) > 1000
        assert b"QRCode" in body
    finally:
        ev.set()
        srv.shutdown()
        th.join(timeout=5)


def test_http_webhook(tmp_path: Path) -> None:
    ev = threading.Event()
    srv = run_stub_server("127.0.0.1", 0, tmp_path, shutdown_event=ev)
    host, port = srv.server_address
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    try:
        url = f"http://{host}:{port}/webhooks/gap-reward"
        v = _voucher(gap_digit="9", triad_digit="8", badge="http-badge", prev=STUB_ROOT_PREV)
        req = urllib.request.Request(
            url,
            data=json.dumps({"voucher_canonical": v}).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            assert resp.status == 200
            body = json.loads(resp.read().decode())
        assert body["ok"] is True
        assert "badge_path" in body
    finally:
        ev.set()
        srv.shutdown()
        th.join(timeout=5)
