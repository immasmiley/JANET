"""Optional live relay + hardware path (manual / workflow_dispatch CI)."""

from __future__ import annotations

import os

import pytest

pytestmark = pytest.mark.relay_live


def test_relay_live_placeholder_skipped_by_default() -> None:
    if os.environ.get("RELAY_LIVE") != "1":
        pytest.skip("RELAY_LIVE=1 not set; enable for fork relay + hardware attestation E2E")
