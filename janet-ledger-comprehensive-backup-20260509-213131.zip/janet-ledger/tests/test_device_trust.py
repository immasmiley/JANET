"""Canonical payloads for device / family binding (passwordless model)."""

from __future__ import annotations

import json

import pytest

from janet_ledger.device_trust import (
    FACTOR_DEVICE_PASSKEY_001,
    FACTOR_FAMILY_LEDGER_003,
    FACTOR_SCREEN_LOCK_002,
    identity_binding_canonical,
)


def _z() -> str:
    return "0" * 64


def test_device_to_user_deterministic():
    a = identity_binding_canonical(
        "device_to_user",
        device_pubkey_sha256_hex="a" * 64,
        factors_applied=(FACTOR_DEVICE_PASSKEY_001, FACTOR_SCREEN_LOCK_002),
        parent_entry_hashes=(_z(),),
        user_pubkey_sha256_hex="b" * 64,
    )
    b = identity_binding_canonical(
        "device_to_user",
        device_pubkey_sha256_hex="A" * 64,
        factors_applied=(FACTOR_DEVICE_PASSKEY_001, FACTOR_SCREEN_LOCK_002),
        parent_entry_hashes=(_z(),),
        user_pubkey_sha256_hex="B" * 64,
    )
    assert a == b


def test_user_to_family_includes_anchor():
    p = identity_binding_canonical(
        "user_to_family",
        device_pubkey_sha256_hex="c" * 64,
        factors_applied=(FACTOR_DEVICE_PASSKEY_001, FACTOR_FAMILY_LEDGER_003),
        parent_entry_hashes=(_z(), "f" * 64),
        family_ledger_anchor_hex="e" * 64,
        family_graph_n_index=42,
        hitl_token="HITL-family-ok",
    )
    d = json.loads(p)
    assert d["role"] == "user_to_family"
    assert d["family_graph_n_index"] == 42
    assert d["factors_applied"][1] == FACTOR_FAMILY_LEDGER_003


def test_requires_factors():
    with pytest.raises(ValueError, match="non-empty"):
        identity_binding_canonical(
            "device_to_user",
            device_pubkey_sha256_hex="a" * 64,
            factors_applied=(),
            parent_entry_hashes=(_z(),),
        )
