"""Renderer: goldens, determinism, persona isolation vs ledger, §5.4 gate."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from janet_ledger import entry_hash
from janet_ledger.renderer import (
    RenderInput,
    RendererConfig,
    render_log_hash,
    render_surface,
    variant_index,
)

FIXTURES = Path(__file__).resolve().parent / "fixtures" / "renderer_goldens.json"

MANIFEST_PAYLOAD = (
    '{"coord_post_snap":-85.1851851852,"event":"phase_1_ku","expert_id":"sys-gen-01",'
    '"frame_id":"fundamental_boundary","hitl_status":"PENDING",'
    '"parent_triple_hash":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",'
    '"turn":1,"zone":"Fundamental"}'
)


def _load_goldens() -> dict:
    return json.loads(FIXTURES.read_text(encoding="utf-8"))


def test_renderer_golden_matrix():
    data = _load_goldens()
    lh = data["ledger_hash_hex"]
    ri = data["render_input"]
    inp = RenderInput(
        frame_id=ri["frame_id"],
        session_id=ri["session_id"],
        turn=int(ri["turn"]),
        zone=ri["zone"],
        coord_post_snap=float(ri["coord_post_snap"]),
        ledger_hash_hex=lh,
    )
    for row in data["goldens"]:
        cfg = RendererConfig(
            persona_id=row["persona_id"],
            verbosity=int(row["verbosity"]),
            safety_54_active=bool(row["safety_54_active"]),
        )
        out = render_surface(inp, cfg)
        assert out.surface_text == row["expected_surface"], row
        assert out.render_log_hash == row["expected_render_log_hash"], row


def test_renderer_determinism_identical_runs():
    data = _load_goldens()
    lh = data["ledger_hash_hex"]
    ri = data["render_input"]
    inp = RenderInput(
        frame_id=ri["frame_id"],
        session_id=ri["session_id"],
        turn=int(ri["turn"]),
        zone=ri["zone"],
        coord_post_snap=float(ri["coord_post_snap"]),
        ledger_hash_hex=lh,
    )
    cfg = RendererConfig(persona_id="analyst_plain", verbosity=1, safety_54_active=False)
    a = render_surface(inp, cfg)
    b = render_surface(inp, cfg)
    assert a.surface_text == b.surface_text
    assert a.render_log_hash == b.render_log_hash
    assert a.variant_index == b.variant_index


def test_persona_isolation_does_not_change_ledger_identity():
    """Swapping persona must not alter coordinator-owned ledger fields."""
    prev = "0" * 64
    h_a = entry_hash(prev, MANIFEST_PAYLOAD)
    h_b = entry_hash(prev, MANIFEST_PAYLOAD)
    assert h_a == h_b

    data = _load_goldens()
    ri = data["render_input"]
    inp = RenderInput(
        frame_id=ri["frame_id"],
        session_id=ri["session_id"],
        turn=int(ri["turn"]),
        zone=ri["zone"],
        coord_post_snap=float(ri["coord_post_snap"]),
        ledger_hash_hex=h_a,
    )
    out_clinical = render_surface(
        inp, RendererConfig("analyst_plain", 2, safety_54_active=False)
    )
    out_counsel = render_surface(
        inp, RendererConfig("counsel_formal", 2, safety_54_active=False)
    )
    assert out_clinical.surface_text != out_counsel.surface_text
    assert str(inp.coord_post_snap) in out_clinical.surface_text
    assert str(inp.coord_post_snap) in out_counsel.surface_text


def test_render_log_hash_chains_ledger_and_config():
    lh = "0" * 64
    cfg = {"persona_id": "analyst_plain", "safety_54_active": False, "verbosity": 1}
    h1 = render_log_hash(lh, cfg)
    h2 = render_log_hash(lh, cfg)
    assert h1 == h2
    cfg2 = dict(cfg)
    cfg2["verbosity"] = 2
    assert render_log_hash(lh, cfg2) != h1


def test_variant_index_stable_not_builtin_hash():
    """Regression: must not use Python built-in hash() (PYTHONHASHSEED)."""
    assert variant_index("fundamental_boundary", "sess-1", 1, 4) == 2
    assert variant_index("fundamental_boundary", "sess-1", 1, 4) == 2


def test_safety_54_blocks_affective_override():
    data = _load_goldens()
    lh = data["ledger_hash_hex"]
    ri = data["render_input"]
    inp = RenderInput(
        frame_id=ri["frame_id"],
        session_id=ri["session_id"],
        turn=int(ri["turn"]),
        zone=ri["zone"],
        coord_post_snap=float(ri["coord_post_snap"]),
        ledger_hash_hex=lh,
    )
    cfg = RendererConfig(persona_id="analyst_plain", verbosity=2, safety_54_active=True)
    with pytest.raises(ValueError, match="§5\\.4 active"):
        render_surface(inp, cfg, affective_override="FORCE_WARM")


def test_safety_54_strips_persona_modifiers_same_output():
    data = _load_goldens()
    lh = data["ledger_hash_hex"]
    ri = data["render_input"]
    inp = RenderInput(
        frame_id=ri["frame_id"],
        session_id=ri["session_id"],
        turn=int(ri["turn"]),
        zone=ri["zone"],
        coord_post_snap=float(ri["coord_post_snap"]),
        ledger_hash_hex=lh,
    )
    hi = RendererConfig("analyst_plain", 2, safety_54_active=True)
    lo = RendererConfig("analyst_plain", 0, safety_54_active=True)
    assert render_surface(inp, hi).surface_text == render_surface(inp, lo).surface_text
