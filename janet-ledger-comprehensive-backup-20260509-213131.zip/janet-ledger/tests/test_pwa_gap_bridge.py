"""Desktop↔PWA gap bridge + settlement dispatch wiring."""

from __future__ import annotations

import json

import pytest

from janet_ledger.gap_reward import (
    BADGE_ATTEST_001,
    GAP_REWARD_001,
    gap_reward_badge_payload_canonical,
)
from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001
from janet_ledger.pwa_gap_bridge import (
    BINDER_001,
    SETTLEMENT_DISPATCH_001,
    VERIFIER_JANET_001,
    assert_pwa_gap_proposal_field_allowlist,
    desktop_audit_chain_append,
    desktop_audit_mirror_pwa_event_row_canonical,
    desktop_gap_bind_row_canonical,
    desktop_gap_bridge_status_canonical,
    desktop_settlement_dispatch_envelope_canonical,
    nip01_challenge_hash_for_desktop_utf8,
    proposal_fingerprint_from_canonical,
    pwa_gap_proposal_payload_canonical,
    verify_desktop_settlement_dispatch_canonical,
    verify_pwa_gap_proposal_canonical,
)
from janet_ledger.pwa_session_policy import (
    ALLOWED_PWA_GAP_DELEGATION_KINDS,
    PWA_GAP_PROPOSAL_KIND,
    delegation_session_offer_canonical,
)
from janet_ledger.settlement_stub import parse_settlement_post_body


def _sig128() -> str:
    return "c" * 128


def _pol_gap() -> tuple[str, ...]:
    return (BADGE_ATTEST_001, GAP_REWARD_001, NIP33_JANET_CONTENT_001)


def test_gap_only_delegation_offer_accepts_38822():
    o = delegation_session_offer_canonical(
        pwa_ephemeral_pubkey_hex="a" * 64,
        allowed_kinds=(PWA_GAP_PROPOSAL_KIND,),
        until_unix=1,
        janet_policy_codes=("SESSION-DELEGATE-001", NIP33_JANET_CONTENT_001),
        permitted_publish_kinds=ALLOWED_PWA_GAP_DELEGATION_KINDS,
    )
    assert json.loads(o)["allowed_kinds"] == [PWA_GAP_PROPOSAL_KIND]


def test_proposal_roundtrip_and_forbid_smuggle():
    p = pwa_gap_proposal_payload_canonical(
        gap_claim_digest_hex="1" * 64,
        delegate_offer_fingerprint_hex="2" * 64,
        pwa_delegate_pubkey_hex="3" * 64,
        proposed_at_unix=9,
        evidence_ref_digests_hex=("4" * 64, "5" * 64),
    )
    verify_pwa_gap_proposal_canonical(p)
    bad = json.loads(p)
    bad["binder_pubkey_hex"] = "f" * 64
    with pytest.raises(ValueError, match="must not contain"):
        assert_pwa_gap_proposal_field_allowlist(bad)


def test_audit_mirror_chain():
    row, nxt = desktop_audit_mirror_pwa_event_row_canonical(
        prev_hash_hex="0" * 64,
        pwa_nostr_event_id_hex="a" * 64,
        pwa_event_kind=PWA_GAP_PROPOSAL_KIND,
        proposal_payload_digest_hex="b" * 64,
        delegate_offer_fingerprint_hex="c" * 64,
    )
    assert len(nxt) == 64
    assert desktop_audit_chain_append(prev_hash_hex=nxt, row_payload_canonical_utf8=row) != nxt


def test_bind_row_and_status():
    br = desktop_gap_bind_row_canonical(
        gap_id_hex="1" * 64,
        triad_hash_hex="2" * 64,
        desktop_root_pubkey_hex="3" * 64,
        verifier_result="PASS",
        proposal_fingerprint_hex="4" * 64,
        janet_policy_codes=(VERIFIER_JANET_001, BINDER_001, NIP33_JANET_CONTENT_001),
    )
    assert "PASS" in br
    st = desktop_gap_bridge_status_canonical(
        phase="voucher_signed",
        last_audit_hash_hex="e" * 64,
        proposal_fingerprint_hex=proposal_fingerprint_from_canonical(
            pwa_gap_proposal_payload_canonical(
                gap_claim_digest_hex="1" * 64,
                delegate_offer_fingerprint_hex="2" * 64,
                pwa_delegate_pubkey_hex="3" * 64,
                proposed_at_unix=0,
            )
        ),
        gap_id_hex="1" * 64,
    )
    assert json.loads(st)["phase"] == "voucher_signed"


def test_dispatch_envelope_and_settlement_parse() -> None:
    prop = pwa_gap_proposal_payload_canonical(
        gap_claim_digest_hex="9" * 64,
        delegate_offer_fingerprint_hex="8" * 64,
        pwa_delegate_pubkey_hex="7" * 64,
        proposed_at_unix=1,
    )
    fp = proposal_fingerprint_from_canonical(prop)
    v = gap_reward_badge_payload_canonical(
        gap_id="1" * 64,
        triad_hash="2" * 64,
        binder_pubkey_hex="3" * 64,
        badge_slug="x",
        quorum_sigs=(_sig128(),),
        verifier_result="PASS",
        epoch=0,
        prev_event_id="0" * 64,
        janet_policy_codes=_pol_gap(),
    )
    audit_after = "a" * 64
    dispatch = desktop_settlement_dispatch_envelope_canonical(
        voucher_canonical=v,
        settlement_post_url="http://127.0.0.1:9/webhooks/gap-reward",
        audit_row_hash_after_voucher_hex=audit_after,
        desktop_root_pubkey_hex="3" * 64,
        janet_policy_codes=(
            SETTLEMENT_DISPATCH_001,
            GAP_REWARD_001,
            NIP33_JANET_CONTENT_001,
        ),
    )
    verify_desktop_settlement_dispatch_canonical(dispatch)
    h = nip01_challenge_hash_for_desktop_utf8(tagged_payload_utf8=dispatch)
    assert len(h) == 64
    outer = json.dumps(
        {"settlement_dispatch_canonical": dispatch, "desktop_schnorr_sig_hex": _sig128()}
    )
    vc = parse_settlement_post_body(outer.encode())
    assert vc == v


def test_parse_dispatch_missing_sig_raises():
    v = gap_reward_badge_payload_canonical(
        gap_id="1" * 64,
        triad_hash="2" * 64,
        binder_pubkey_hex="3" * 64,
        badge_slug="x",
        quorum_sigs=(_sig128(),),
        verifier_result="PASS",
        epoch=0,
        prev_event_id="0" * 64,
        janet_policy_codes=_pol_gap(),
    )
    dispatch = desktop_settlement_dispatch_envelope_canonical(
        voucher_canonical=v,
        settlement_post_url="http://localhost/x",
        audit_row_hash_after_voucher_hex="b" * 64,
        desktop_root_pubkey_hex="3" * 64,
    )
    outer = json.dumps({"settlement_dispatch_canonical": dispatch})
    with pytest.raises(ValueError, match="desktop_schnorr_sig_hex required"):
        parse_settlement_post_body(outer.encode())
