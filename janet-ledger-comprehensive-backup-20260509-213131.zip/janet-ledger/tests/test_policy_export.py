"""policy_config + export_bundle + domain_libraries replay."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from janet_ledger import (
    evaluate_scenario,
    k_delta_line_export_dict,
    ledger_golden_vectors_to_jsonl_lines,
    policy_config_from_manifest,
    static_ui_bundle_dict,
    zone_map_export_dict,
)

from conftest import load_manifest


def test_policy_config_default_convergence_policy():
    root = {
        "policy_config": {"convergence": {"default_active_policy": "CONV-ADJ-001"}},
    }
    pc = policy_config_from_manifest(root)
    scenario = {
        "sessions": [
            {"session_id": "A", "k_final": 17},
            {"session_id": "B", "k_final": 16},
            {"session_id": "C", "k_final": 18},
        ]
    }
    assert evaluate_scenario(scenario, pc) is True
    assert evaluate_scenario(scenario, None) is False


def test_domain_libraries_replay():
    m = load_manifest()
    for domain in ("clinical", "legal"):
        for sc in m["domain_libraries"][domain]:
            assert evaluate_scenario(sc, policy_config_from_manifest(m)) == sc["expected_result"]


def test_static_ui_bundle_has_k_line():
    m = load_manifest()
    b = static_ui_bundle_dict(m)
    assert b["static_ui_bundle_schema"] == "static_ui_v1"
    assert len(b["k_delta_line"]["nodes"]) == 217


def test_ledger_jsonl_roundtrip_single_row():
    m = load_manifest()
    lines = ledger_golden_vectors_to_jsonl_lines(m)
    assert len(lines) >= 1
    row = json.loads(lines[0])
    assert set(row.keys()) == {"entry_hash", "payload_canonical", "prev_hash"}


def test_zone_map_export():
    z = zone_map_export_dict(tie_coord=-25.0)
    assert z["zone_map_schema"] == "zone_map_v1"
    assert any(s["coord"] == -25.0 and s["tie_break_applied"] for s in z["samples"])


def test_export_compliance_script(tmp_path: Path) -> None:
    import subprocess
    import sys

    root = Path(__file__).resolve().parents[1]
    script = root / "scripts" / "export_compliance_artifacts.py"
    subprocess.run(
        [
            sys.executable,
            str(script),
            "--manifest",
            str(root / "TEST_MANIFEST.json"),
            "--out-dir",
            str(tmp_path),
        ],
        check=True,
    )
    assert (tmp_path / "zone_map.json").is_file()
    assert (tmp_path / "static_ui_bundle.json").is_file()
    assert (tmp_path / "ledger_golden_vectors.jsonl").is_file()
