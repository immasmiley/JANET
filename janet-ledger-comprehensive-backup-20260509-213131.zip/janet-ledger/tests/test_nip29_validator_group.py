"""NIP-29 janet-validators roster + weighted quorum."""

from __future__ import annotations

import json

import pytest

from janet_ledger.nip29_validator_group import (
    GROUP_SLUG_JANET_VALIDATORS,
    NIP29_VALIDATORS_GROUP_001,
    VALIDATOR_WEIGHT_QUORUM_001,
    ValidatorMember,
    accumulated_vote_weight,
    auto_provision_janet_validators_payload,
    janet_validators_group_address_v1,
    nip29_validators_provision_payload_canonical,
    roster_weights_from_provision_dict,
    sort_validators_for_round,
    verify_nip29_validators_provision_canonical,
    weighted_quorum_met,
)
from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001


def _pk(n: str) -> str:
    return (n * 64)[:64]


def test_group_address_stable():
    a = janet_validators_group_address_v1()
    b = janet_validators_group_address_v1()
    assert a == b and len(a) == 64


def test_provision_sorted_members_and_verify():
    m = [
        ValidatorMember(pubkey_hex=_pk("b"), reputation_weight=2),
        ValidatorMember(pubkey_hex=_pk("a"), reputation_weight=5),
    ]
    raw = nip29_validators_provision_payload_canonical(
        epoch=1,
        monotonic_counter=0,
        members=m,
        quorum_weight_sum_required=4,
        relay_hints=("wss://b.example", "wss://a.example"),
    )
    d = json.loads(raw)
    assert d["members"][0]["pubkey_hex"] == _pk("a")
    assert d["relay_hints"] == ["wss://a.example", "wss://b.example"]
    assert d["group_slug"] == GROUP_SLUG_JANET_VALIDATORS
    assert d["group_address_hex"] == janet_validators_group_address_v1()
    v = verify_nip29_validators_provision_canonical(raw)
    assert v["quorum_weight_sum_required"] == 4


def test_reject_duplicate_pubkey():
    p = _pk("c")
    with pytest.raises(ValueError, match="duplicate"):
        nip29_validators_provision_payload_canonical(
            epoch=0,
            monotonic_counter=0,
            members=(
                ValidatorMember(pubkey_hex=p, reputation_weight=1),
                ValidatorMember(pubkey_hex=p, reputation_weight=2),
            ),
            quorum_weight_sum_required=1,
        )


def test_reject_quorum_above_total_weight():
    with pytest.raises(ValueError, match="exceeds"):
        nip29_validators_provision_payload_canonical(
            epoch=0,
            monotonic_counter=0,
            members=(ValidatorMember(pubkey_hex=_pk("d"), reputation_weight=2),),
            quorum_weight_sum_required=3,
        )


def test_sort_validators_round_order_deterministic():
    p1, p2 = _pk("1"), _pk("2")
    a = ValidatorMember(pubkey_hex=p1, reputation_weight=10)
    b = ValidatorMember(pubkey_hex=p2, reputation_weight=1)
    prop = _pk("9")
    o1 = sort_validators_for_round(proposal_id_hex=prop, members=(a, b))
    o2 = sort_validators_for_round(proposal_id_hex=prop, members=(b, a))
    assert o1 == o2


def test_accumulated_weight_and_quorum():
    p1, p2 = _pk("4"), _pk("5")
    roster = {p1: 3, p2: 7}
    w = accumulated_vote_weight(approved_pubkeys=(p2, p1, p2), roster_weights_by_pubkey=roster)
    assert w == 10
    assert weighted_quorum_met(signed_weight=w, quorum_weight_sum_required=10)
    with pytest.raises(ValueError, match="not on roster"):
        accumulated_vote_weight(approved_pubkeys=(_pk("c"),), roster_weights_by_pubkey=roster)


def test_auto_provision_matches_explicit():
    p1, p2 = _pk("6"), _pk("7")
    auto_raw = auto_provision_janet_validators_payload(
        epoch=0,
        monotonic_counter=2,
        members=((p2, 1), (p1, 4)),
        quorum_weight_sum_required=3,
    )
    explicit = nip29_validators_provision_payload_canonical(
        epoch=0,
        monotonic_counter=2,
        members=(
            ValidatorMember(pubkey_hex=p1, reputation_weight=4),
            ValidatorMember(pubkey_hex=p2, reputation_weight=1),
        ),
        quorum_weight_sum_required=3,
    )
    assert auto_raw == explicit


def test_roster_weights_from_provision():
    raw = auto_provision_janet_validators_payload(
        epoch=0,
        monotonic_counter=0,
        members=((_pk("8"), 2),),
        quorum_weight_sum_required=1,
    )
    rw = roster_weights_from_provision_dict(json.loads(raw))
    assert rw[_pk("8")] == 2


def test_verify_rejects_tamper():
    raw = auto_provision_janet_validators_payload(
        epoch=0,
        monotonic_counter=0,
        members=((_pk("f"), 1),),
        quorum_weight_sum_required=1,
    )
    d = json.loads(raw)
    d["evil"] = True
    bad = json.dumps(d, sort_keys=True, separators=(",", ":"))
    with pytest.raises(ValueError, match="mismatch"):
        verify_nip29_validators_provision_canonical(bad)


def test_missing_policy_code():
    pol = (NIP33_JANET_CONTENT_001, VALIDATOR_WEIGHT_QUORUM_001)
    with pytest.raises(ValueError, match="NIP29-VALIDATORS-GROUP-001"):
        nip29_validators_provision_payload_canonical(
            epoch=0,
            monotonic_counter=0,
            members=(ValidatorMember(pubkey_hex=_pk("e"), reputation_weight=1),),
            quorum_weight_sum_required=1,
            janet_policy_codes=pol,
        )
