"""Tests for Family Graph protocol (217 ring, 7×31, BAT, mandates)."""

from __future__ import annotations

from janet_ledger.constants import DELTA
from janet_ledger.family_graph import (
    FAMILY_SLOTS,
    RESERVED_BAND_END,
    RESERVED_BAND_START,
    SELF_ANCHOR,
    assert_mandates,
    bat_tier_for_degree,
    degree_and_type_for,
    n_index_for,
    polling_steps_for_degree,
    reserved_bridge_index,
    validate_member,
    vouch_threshold_for_degree,
)
from janet_ledger.family_taxonomy import RelationshipType, category_of, is_valid_rel_type, types_in_category
from janet_ledger.lattice217 import (
    HALF_IDX,
    N_NODES,
    USER_N_INDEX,
    family_n_to_janet_k,
    janet_index_for,
    nearest_n,
    x_at,
    x_at_frac,
)


def test_assert_mandates_passes():
    assert_mandates()


def test_delta_matches_janet_ledger_constant():
    """25/27 == 100/108 (same δ-line as coordinator package)."""
    assert abs(float(x_at_frac(1) - x_at_frac(0)) - DELTA) < 1e-15


def test_family_n_aligns_with_k_index_line():
    for n in (0, 1, 31, 93, 108, 185, 216):
        k = family_n_to_janet_k(n)
        assert abs(x_at(n) - k * DELTA) < 1e-12


def test_janet_index_for_wraps():
    assert janet_index_for(0) == HALF_IDX
    assert janet_index_for(-1) == HALF_IDX - 1


def test_degree_and_type_for_self_and_bands():
    s = degree_and_type_for(0)
    assert s["degree"] == 4
    assert s["rel_type"] == RelationshipType.ADOPTIVE_CHILD
    assert s["self"] is True
    d1 = degree_and_type_for(1)
    assert d1["degree"] == 1 and d1["rel_type"] == 2
    r = degree_and_type_for(186)
    assert r["reserved"] is True


def test_n_index_for_roundtrip():
    for deg in range(1, 7):
        for rt in range(1, 32):
            ni = n_index_for(deg, rt)
            if ni == 0:
                continue
            dt = degree_and_type_for(ni)
            assert not dt.get("reserved")
            assert dt["degree"] == deg and dt["rel_type"] == rt


def test_self_anchor_constants():
    assert SELF_ANCHOR["n_index"] == USER_N_INDEX
    assert SELF_ANCHOR["janet_n"] == HALF_IDX
    assert SELF_ANCHOR["degree"] == 4
    assert SELF_ANCHOR["rel_type"] == RelationshipType.ADOPTIVE_CHILD


def test_bat_tiers():
    assert bat_tier_for_degree(1) == "hot" and polling_steps_for_degree(1) == 27
    assert vouch_threshold_for_degree(1) == 0
    assert bat_tier_for_degree(4) == "warm" and polling_steps_for_degree(4) == 54
    assert vouch_threshold_for_degree(4) == 1
    assert bat_tier_for_degree(6) == "cold" and polling_steps_for_degree(6) == 108
    assert vouch_threshold_for_degree(6) == 2


def test_reserved_band_validate():
    err = validate_member(n_index=190)
    assert err["ok"] is False
    assert err.get("error") == "reserved_band"


def test_validate_member_mismatch():
    bad = validate_member(n_index=1, rel_type=99)
    assert bad["ok"] is False
    assert bad.get("error") == "rel_type_mismatch"


def test_validate_member_self_ok():
    ok = validate_member(n_index=0)
    assert ok["ok"] is True
    assert ok["tier"] == "warm"


def test_reserved_bridge_index_deterministic():
    a = reserved_bridge_index("group-abc")
    b = reserved_bridge_index("group-abc")
    assert a == b
    assert RESERVED_BAND_START <= a <= RESERVED_BAND_END


def test_partition_7x31():
    assert FAMILY_SLOTS + (RESERVED_BAND_END - RESERVED_BAND_START + 1) == N_NODES == 217


def test_taxonomy_categories():
    assert category_of(1) == "ancestors"
    assert category_of(15) == "descendants"
    assert 21 in types_in_category("lateral")
    assert is_valid_rel_type(31) and not is_valid_rel_type(32)


def test_nearest_n_inverse_x_at():
    for n in (0, 54, 108, 200, 216):
        assert nearest_n(x_at(n)) == n
