"""GAP-REWARD-001 badge voucher canonical payloads."""

from __future__ import annotations

import json

import pytest

from janet_ledger.gap_reward import (
    BADGE_ATTEST_001,
    GAP_REWARD_001,
    assert_verifier_passed_before_reward,
    gap_reward_badge_payload_canonical,
    gap_reward_dedup_key,
    verify_gap_reward_voucher_canonical,
)
from janet_ledger.nostr_janet_policy import NIP33_JANET_CONTENT_001


def _sig() -> str:
    return "f" * 128


def _pol() -> tuple[str, str, str]:
    return (BADGE_ATTEST_001, GAP_REWARD_001, NIP33_JANET_CONTENT_001)


def test_gap_reward_sorted_and_stable():
    p = gap_reward_badge_payload_canonical(
        gap_id="1" * 64,
        triad_hash="2" * 64,
        binder_pubkey_hex="3" * 64,
        badge_slug="gap-hero",
        quorum_sigs=(_sig(), "e" * 128),
        verifier_result="PASS",
        epoch=7,
        prev_event_id="4" * 64,
        janet_policy_codes=_pol(),
    )
    d = json.loads(p)
    assert d["quorum_sigs"] == sorted(["e" * 128, _sig()])
    assert d["badge_slug"] == "gap-hero"
    p2 = gap_reward_badge_payload_canonical(
        gap_id="1" * 64,
        triad_hash="2" * 64,
        binder_pubkey_hex="3" * 64,
        badge_slug="gap-hero",
        quorum_sigs=("e" * 128, _sig()),
        verifier_result="PASS",
        epoch=7,
        prev_event_id="4" * 64,
        janet_policy_codes=_pol(),
    )
    assert p == p2


def test_reject_fail_verifier():
    with pytest.raises(ValueError, match="PASS"):
        assert_verifier_passed_before_reward("FAIL")


def test_dedup_key_stable():
    k1 = gap_reward_dedup_key(triad_hash_hex="a" * 64, badge_slug="x")
    k2 = gap_reward_dedup_key(triad_hash_hex="A" * 64, badge_slug="X")
    assert k1 == k2


def test_requires_policy_codes():
    with pytest.raises(ValueError, match="GAP-REWARD-001"):
        gap_reward_badge_payload_canonical(
            gap_id="1" * 64,
            triad_hash="2" * 64,
            binder_pubkey_hex="3" * 64,
            badge_slug="b",
            quorum_sigs=(_sig(),),
            verifier_result="PASS",
            epoch=0,
            prev_event_id="4" * 64,
            janet_policy_codes=(NIP33_JANET_CONTENT_001, BADGE_ATTEST_001),
        )


def test_verify_roundtrip_and_reject_tamper():
    raw = gap_reward_badge_payload_canonical(
        gap_id="1" * 64,
        triad_hash="2" * 64,
        binder_pubkey_hex="3" * 64,
        badge_slug="gap-hero",
        quorum_sigs=(_sig(),),
        verifier_result="PASS",
        epoch=1,
        prev_event_id="4" * 64,
        janet_policy_codes=_pol(),
    )
    v = verify_gap_reward_voucher_canonical(raw)
    assert v["badge_slug"] == "gap-hero"
    tampered = json.loads(raw)
    tampered["evil"] = True
    bad = json.dumps(tampered, sort_keys=True, separators=(",", ":"))
    with pytest.raises(ValueError, match="mismatch"):
        verify_gap_reward_voucher_canonical(bad)
