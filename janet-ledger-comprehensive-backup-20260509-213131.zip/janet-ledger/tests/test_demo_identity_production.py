"""Production guard and Protocol contracts for demo identity."""

from __future__ import annotations

import pytest

from janet_ledger.demo_identity import InMemoryDemoKeyVault
from janet_ledger.demo_identity_production import (
    RETIREMENT_STEP_ORDER_LIVE,
    ALLOW_CI_DEMO_MEMORY_VAULT_ENV,
    assert_no_ci_memory_vault_in_production,
)


def test_assert_rejects_memory_vault_without_env(monkeypatch):
    monkeypatch.delenv(ALLOW_CI_DEMO_MEMORY_VAULT_ENV, raising=False)
    v = InMemoryDemoKeyVault()
    with pytest.raises(TypeError, match="InMemoryDemoKeyVault"):
        assert_no_ci_memory_vault_in_production(v)


def test_assert_allows_memory_vault_with_ci_env(monkeypatch):
    monkeypatch.setenv(ALLOW_CI_DEMO_MEMORY_VAULT_ENV, "1")
    v = InMemoryDemoKeyVault()
    assert_no_ci_memory_vault_in_production(v)


def test_live_retirement_order_extends_base():
    assert "disconnect_relay_pool" in RETIREMENT_STEP_ORDER_LIVE
    assert RETIREMENT_STEP_ORDER_LIVE.index("disconnect_relay_pool") > RETIREMENT_STEP_ORDER_LIVE.index(
        "append_local_audit_demo_retired"
    )
